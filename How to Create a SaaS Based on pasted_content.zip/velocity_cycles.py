from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models import db, VelocityCycle

velocity_cycles_bp = Blueprint('velocity_cycles', __name__)

@velocity_cycles_bp.route('/', methods=['GET'])
@jwt_required()
def get_velocity_cycles():
    """Get user's velocity banking cycles."""
    try:
        current_user_id = get_jwt_identity()
        status = request.args.get('status')
        limit = int(request.args.get('limit', 20))
        offset = int(request.args.get('offset', 0))
        
        cycles = VelocityCycle.get_user_cycles(current_user_id, status, limit, offset)
        total_interest_saved = VelocityCycle.calculate_total_interest_saved(current_user_id)
        
        return jsonify({
            'success': True,
            'data': {
                'cycles': [cycle.to_dict() for cycle in cycles],
                'total_count': len(cycles),
                'total_interest_saved': float(total_interest_saved)
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred retrieving velocity cycles'
            }
        }), 500

@velocity_cycles_bp.route('/', methods=['POST'])
@jwt_required()
def create_velocity_cycle():
    """Start a new velocity banking cycle."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        cycle = VelocityCycle.create_new_cycle(
            user_id=current_user_id,
            paycheck_amount=data['paycheck_amount'],
            start_date=data.get('start_date'),
            notes=data.get('notes')
        )
        
        return jsonify({
            'success': True,
            'message': 'Velocity cycle started successfully',
            'data': cycle.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred creating velocity cycle'
            }
        }), 500

