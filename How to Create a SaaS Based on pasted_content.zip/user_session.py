import uuid
from datetime import datetime, timezone
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Text, Boolean
from . import db

class UserSession(db.Model):
    __tablename__ = 'user_sessions'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    
    # Session tokens
    session_token = db.Column(String(255), unique=True, nullable=False)
    refresh_token = db.Column(String(255), unique=True, nullable=False)
    
    # Session metadata
    ip_address = db.Column(String(45))  # IPv6 compatible
    user_agent = db.Column(Text)
    
    # Session timing
    expires_at = db.Column(DateTime(timezone=True), nullable=False)
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    last_accessed = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    
    # Session status
    is_active = db.Column(Boolean, default=True)
    
    def __repr__(self):
        return f'<UserSession {self.user_id}>'
    
    def to_dict(self):
        """Convert user session to dictionary."""
        return {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'expires_at': self.expires_at.isoformat(),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_accessed': self.last_accessed.isoformat() if self.last_accessed else None,
            'is_active': self.is_active
        }

