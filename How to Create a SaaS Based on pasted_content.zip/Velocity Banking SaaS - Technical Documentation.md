# Velocity Banking SaaS - Technical Documentation

**Version 1.0**  
**Author: Manus AI**  
**Date: July 29, 2025**

---

## Table of Contents

1. [System Architecture Overview](#system-architecture-overview)
2. [Backend API Documentation](#backend-api-documentation)
3. [Frontend Architecture](#frontend-architecture)
4. [Database Schema](#database-schema)
5. [Financial Calculation Engine](#financial-calculation-engine)
6. [Security Implementation](#security-implementation)
7. [Deployment Guide](#deployment-guide)
8. [Development Setup](#development-setup)
9. [Testing Framework](#testing-framework)
10. [Performance Optimization](#performance-optimization)
11. [Monitoring and Logging](#monitoring-and-logging)
12. [API Reference](#api-reference)

---

## System Architecture Overview

The Velocity Banking SaaS application follows a modern, scalable architecture pattern with clear separation of concerns between the frontend user interface, backend API services, and data persistence layers.

### High-Level Architecture

The system is built using a three-tier architecture consisting of:

**Presentation Layer (Frontend)**
- React.js application with modern UI components
- Responsive design supporting desktop and mobile devices
- Real-time data visualization and interactive dashboards
- Client-side routing and state management
- Progressive Web App (PWA) capabilities for offline functionality

**Application Layer (Backend)**
- Flask-based REST API with comprehensive endpoint coverage
- JWT-based authentication and authorization
- Sophisticated financial calculation engine
- Data validation and business logic enforcement
- Integration capabilities for external financial services

**Data Layer (Database)**
- SQLite database for development and small deployments
- PostgreSQL support for production environments
- Comprehensive data model supporting complex financial relationships
- Audit logging and data integrity constraints
- Backup and recovery mechanisms

### Technology Stack

**Backend Technologies:**
- Python 3.11+ with Flask web framework
- SQLAlchemy ORM for database abstraction
- Flask-JWT-Extended for authentication
- Flask-CORS for cross-origin resource sharing
- Werkzeug for security utilities
- Decimal precision arithmetic for financial calculations

**Frontend Technologies:**
- React 19.1.0 with modern hooks and functional components
- Vite build system for fast development and optimized production builds
- Tailwind CSS for utility-first styling
- Radix UI components for accessible, customizable interface elements
- Lucide React for consistent iconography
- React Router for client-side navigation

**Development and Deployment:**
- Git version control with comprehensive branching strategy
- Automated testing with pytest for backend and Jest for frontend
- Docker containerization for consistent deployment environments
- CI/CD pipeline integration for automated testing and deployment
- Environment-specific configuration management

### Scalability Considerations

The architecture is designed to support horizontal scaling as user base and data volume grow:

**Database Scaling:**
- Read replica support for query performance optimization
- Database sharding strategies for large user bases
- Caching layers using Redis for frequently accessed data
- Connection pooling for efficient database resource utilization

**Application Scaling:**
- Stateless API design enabling horizontal scaling
- Load balancer support for distributing traffic across multiple instances
- Microservices migration path for component-specific scaling
- Asynchronous task processing for computationally intensive operations

**Frontend Scaling:**
- Content Delivery Network (CDN) integration for global performance
- Code splitting and lazy loading for optimal bundle sizes
- Service worker implementation for offline functionality
- Progressive enhancement for varying network conditions

---

## Backend API Documentation

The backend API provides comprehensive endpoints for managing all aspects of the velocity banking application, from user authentication to complex financial calculations.

### Authentication and Authorization

The API uses JWT (JSON Web Tokens) for stateless authentication, providing secure access control while maintaining scalability.

**Authentication Flow:**
1. User submits credentials to `/api/auth/login` endpoint
2. Server validates credentials and generates JWT access and refresh tokens
3. Client includes access token in Authorization header for subsequent requests
4. Server validates token and extracts user identity for request processing
5. Refresh tokens enable seamless token renewal without re-authentication

**Token Management:**
- Access tokens expire after 24 hours to limit exposure risk
- Refresh tokens remain valid for 30 days to balance security and usability
- Token blacklisting capability for immediate revocation when needed
- Automatic token refresh handling in frontend application

**Authorization Levels:**
- Standard users have access to their own financial data and calculations
- Premium users gain access to advanced analytics and scenario modeling
- Administrative users can access system-wide metrics and user management
- API rate limiting prevents abuse and ensures fair resource allocation

### Core API Endpoints

**User Management Endpoints:**
```
POST /api/auth/register - Create new user account
POST /api/auth/login - Authenticate user and return tokens
POST /api/auth/refresh - Refresh access token using refresh token
POST /api/auth/logout - Invalidate user session and tokens
GET /api/users/profile - Retrieve current user profile information
PUT /api/users/profile - Update user profile information
```

**Financial Profile Endpoints:**
```
GET /api/financial-profile - Retrieve user's financial profile
POST /api/financial-profile - Create initial financial profile
PUT /api/financial-profile - Update financial profile information
DELETE /api/financial-profile - Remove financial profile data
```

**Debt Management Endpoints:**
```
GET /api/debts - Retrieve all user debts with filtering options
POST /api/debts - Add new debt to user's portfolio
GET /api/debts/{id} - Retrieve specific debt details
PUT /api/debts/{id} - Update debt information
DELETE /api/debts/{id} - Remove debt from portfolio
POST /api/debts/{id}/payments - Record payment against specific debt
```

**Bank Account Endpoints:**
```
GET /api/bank-accounts - Retrieve connected bank accounts
POST /api/bank-accounts - Add new bank account connection
GET /api/bank-accounts/{id} - Retrieve specific account details
PUT /api/bank-accounts/{id} - Update account information
DELETE /api/bank-accounts/{id} - Remove account connection
POST /api/bank-accounts/{id}/sync - Trigger manual account synchronization
```

**Velocity Cycle Endpoints:**
```
GET /api/velocity-cycles - Retrieve velocity cycle history
POST /api/velocity-cycles - Create new velocity cycle
GET /api/velocity-cycles/{id} - Retrieve specific cycle details
PUT /api/velocity-cycles/{id} - Update cycle information
POST /api/velocity-cycles/{id}/complete - Mark cycle as completed
```

**Financial Calculation Endpoints:**
```
POST /api/calculations/debt-optimization - Calculate optimal debt payoff strategy
POST /api/calculations/scenario-comparison - Compare multiple financial scenarios
POST /api/calculations/velocity-cycle - Calculate cycle effectiveness metrics
GET /api/calculations/financial-metrics - Retrieve comprehensive financial metrics
POST /api/calculations/extra-payment-simulation - Simulate impact of extra payments
```

### Request and Response Formats

All API endpoints use JSON for request and response data, with consistent formatting and error handling across the entire API.

**Standard Response Format:**
```json
{
  "success": true,
  "data": {
    // Response data specific to endpoint
  },
  "message": "Optional success message",
  "timestamp": "2025-07-29T10:30:00Z"
}
```

**Error Response Format:**
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error description",
    "details": {
      // Additional error context when applicable
    }
  },
  "timestamp": "2025-07-29T10:30:00Z"
}
```

**Pagination Format:**
For endpoints returning lists of data, pagination is implemented using cursor-based pagination for optimal performance:
```json
{
  "success": true,
  "data": {
    "items": [
      // Array of data items
    ],
    "pagination": {
      "has_next": true,
      "has_previous": false,
      "next_cursor": "eyJpZCI6MTIzfQ==",
      "previous_cursor": null,
      "total_count": 150
    }
  }
}
```

### Data Validation and Error Handling

The API implements comprehensive data validation using Marshmallow schemas, ensuring data integrity and providing clear feedback for validation errors.

**Input Validation:**
- Required field validation with descriptive error messages
- Data type validation with automatic type coercion where appropriate
- Range validation for numerical fields (interest rates, amounts, dates)
- Format validation for structured data (email addresses, phone numbers)
- Business logic validation (debt balances, payment amounts, cycle dates)

**Error Categories:**
- **400 Bad Request:** Invalid input data or malformed requests
- **401 Unauthorized:** Missing or invalid authentication credentials
- **403 Forbidden:** Insufficient permissions for requested operation
- **404 Not Found:** Requested resource does not exist
- **409 Conflict:** Request conflicts with current resource state
- **422 Unprocessable Entity:** Valid format but business logic violations
- **429 Too Many Requests:** Rate limiting threshold exceeded
- **500 Internal Server Error:** Unexpected server-side errors

**Validation Error Response:**
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Input validation failed",
    "details": {
      "field_errors": {
        "interest_rate": ["Interest rate must be between 0 and 1"],
        "minimum_payment": ["Minimum payment must be greater than 0"]
      }
    }
  }
}
```

---

## Frontend Architecture

The frontend application is built using React with a modern component-based architecture that emphasizes reusability, maintainability, and performance.

### Component Architecture

**Atomic Design Principles:**
The frontend follows atomic design methodology, organizing components into a hierarchical structure:

- **Atoms:** Basic building blocks like buttons, inputs, and icons
- **Molecules:** Simple combinations of atoms like form fields with labels
- **Organisms:** Complex components like navigation bars and data tables
- **Templates:** Page-level layouts defining content structure
- **Pages:** Specific instances of templates with real content

**Component Organization:**
```
src/
├── components/
│   ├── ui/           # Reusable UI components (atoms/molecules)
│   ├── layout/       # Layout components (organisms)
│   ├── forms/        # Form-specific components
│   └── charts/       # Data visualization components
├── pages/            # Page components (templates/pages)
├── contexts/         # React context providers
├── hooks/            # Custom React hooks
├── utils/            # Utility functions
└── services/         # API service functions
```

### State Management

The application uses a combination of React's built-in state management and context API for global state, avoiding the complexity of external state management libraries while maintaining clean data flow.

**Local State Management:**
- Component-level state using useState hook for UI-specific data
- Form state management using controlled components
- Temporary state for user interactions and animations

**Global State Management:**
- Authentication context for user session and token management
- Theme context for dark/light mode and accessibility preferences
- Notification context for system-wide alerts and messages

**Data Fetching and Caching:**
- Custom hooks for API data fetching with built-in loading and error states
- Client-side caching for frequently accessed data
- Optimistic updates for improved user experience
- Background data refresh for real-time information

### Routing and Navigation

The application uses React Router for client-side routing with protected routes and dynamic navigation based on user authentication status.

**Route Structure:**
```
/                     # Landing page (redirects to login if not authenticated)
/login               # User authentication
/register            # User registration
/dashboard           # Main dashboard (protected)
/debts               # Debt management (protected)
/bank-accounts       # Account management (protected)
/velocity-cycles     # Cycle tracking (protected)
/transactions        # Transaction history (protected)
/scenarios           # Scenario planning (protected)
/profile             # User profile (protected)
```

**Route Protection:**
- Higher-order component for route authentication
- Automatic redirection to login for unauthenticated users
- Role-based access control for premium features
- Breadcrumb navigation for complex page hierarchies

### UI/UX Design System

The frontend implements a comprehensive design system ensuring consistency and accessibility across all user interfaces.

**Design Tokens:**
- Color palette with semantic naming (primary, secondary, success, warning, error)
- Typography scale with consistent font sizes and line heights
- Spacing system using rem units for scalability
- Border radius and shadow definitions for visual consistency

**Accessibility Features:**
- WCAG 2.1 AA compliance for color contrast and keyboard navigation
- Screen reader support with proper ARIA labels and descriptions
- Focus management for modal dialogs and complex interactions
- Responsive design supporting various screen sizes and orientations

**Interactive Elements:**
- Consistent hover and focus states across all interactive elements
- Loading states with skeleton screens for better perceived performance
- Error states with clear messaging and recovery options
- Success feedback for completed actions

### Performance Optimization

The frontend is optimized for performance across various network conditions and device capabilities.

**Code Splitting:**
- Route-based code splitting for smaller initial bundle sizes
- Component-level lazy loading for heavy features
- Dynamic imports for conditionally loaded functionality

**Asset Optimization:**
- Image optimization with responsive sizing and modern formats
- Icon optimization using SVG sprites and tree shaking
- Font optimization with subset loading and display swap

**Runtime Performance:**
- React.memo for preventing unnecessary re-renders
- useMemo and useCallback for expensive computations
- Virtual scrolling for large data sets
- Debounced input handling for search and filtering

---


## Database Schema

The database schema is designed to support complex financial relationships while maintaining data integrity and performance across large datasets.

### Core Entity Relationships

**User Management:**
The user entity serves as the central hub for all financial data, with comprehensive profile information and security features.

```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    subscription_tier VARCHAR(20) DEFAULT 'free',
    is_email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Financial Profiles:**
Each user has a detailed financial profile that captures income, employment, and financial goals necessary for accurate velocity banking calculations.

```sql
CREATE TABLE financial_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    annual_income DECIMAL(12,2),
    monthly_income DECIMAL(12,2),
    employment_status VARCHAR(50),
    employer_name VARCHAR(100),
    employment_start_date DATE,
    financial_goals TEXT,
    risk_tolerance VARCHAR(20),
    emergency_fund_target DECIMAL(12,2),
    current_emergency_fund DECIMAL(12,2),
    net_worth DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

### Financial Data Models

**Debt Management:**
The debt model captures all necessary information for velocity banking optimization, including payment history and priority settings.

```sql
CREATE TABLE debts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    debt_name VARCHAR(100) NOT NULL,
    debt_type VARCHAR(50) NOT NULL,
    original_balance DECIMAL(12,2) NOT NULL,
    current_balance DECIMAL(12,2) NOT NULL,
    interest_rate DECIMAL(5,4) NOT NULL,
    minimum_payment DECIMAL(10,2) NOT NULL,
    payment_due_date INTEGER,
    term_months INTEGER,
    priority_order INTEGER,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

**Bank Account Integration:**
Bank accounts are modeled to support various account types while maintaining security for sensitive financial information.

```sql
CREATE TABLE bank_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    account_name VARCHAR(100) NOT NULL,
    account_type VARCHAR(20) NOT NULL,
    institution_name VARCHAR(100),
    account_number_encrypted VARCHAR(255),
    routing_number_encrypted VARCHAR(255),
    current_balance DECIMAL(12,2) DEFAULT 0.00,
    available_balance DECIMAL(12,2),
    credit_limit DECIMAL(12,2),
    interest_rate DECIMAL(5,4),
    is_primary BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    last_sync_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

### Velocity Banking Specific Models

**Velocity Cycles:**
Velocity cycles track the effectiveness of each paycheck cycle in the velocity banking strategy.

```sql
CREATE TABLE velocity_cycles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    cycle_number INTEGER NOT NULL,
    paycheck_amount DECIMAL(10,2) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    total_debt_payments DECIMAL(10,2) DEFAULT 0.00,
    total_expenses DECIMAL(10,2) DEFAULT 0.00,
    cycle_effectiveness DECIMAL(5,4),
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

**Transaction Tracking:**
Comprehensive transaction tracking supports detailed cash flow analysis and velocity banking optimization.

```sql
CREATE TABLE transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    bank_account_id INTEGER,
    debt_id INTEGER,
    velocity_cycle_id INTEGER,
    transaction_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    category VARCHAR(50),
    description TEXT,
    merchant_name VARCHAR(100),
    is_recurring BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (bank_account_id) REFERENCES bank_accounts (id),
    FOREIGN KEY (debt_id) REFERENCES debts (id),
    FOREIGN KEY (velocity_cycle_id) REFERENCES velocity_cycles (id)
);
```

### Security and Audit Models

**Session Management:**
User sessions are tracked for security monitoring and concurrent session management.

```sql
CREATE TABLE user_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

**Audit Logging:**
Comprehensive audit logging tracks all significant actions for security and compliance purposes.

```sql
CREATE TABLE audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50),
    resource_id INTEGER,
    old_values TEXT,
    new_values TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

### Database Optimization Strategies

**Indexing Strategy:**
Strategic indexing improves query performance for common access patterns:

```sql
-- User lookup optimization
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_subscription ON users(subscription_tier);

-- Financial data access optimization
CREATE INDEX idx_debts_user_active ON debts(user_id, is_active);
CREATE INDEX idx_bank_accounts_user_primary ON bank_accounts(user_id, is_primary);
CREATE INDEX idx_transactions_user_date ON transactions(user_id, transaction_date);
CREATE INDEX idx_velocity_cycles_user_active ON velocity_cycles(user_id, is_active);

-- Security and audit optimization
CREATE INDEX idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_audit_logs_user_action ON audit_logs(user_id, action);
```

**Data Integrity Constraints:**
Business logic constraints ensure data consistency:

```sql
-- Ensure positive financial amounts
ALTER TABLE debts ADD CONSTRAINT chk_debt_positive_balance 
    CHECK (current_balance >= 0 AND original_balance >= 0);
ALTER TABLE debts ADD CONSTRAINT chk_debt_positive_payment 
    CHECK (minimum_payment > 0);

-- Ensure valid interest rates
ALTER TABLE debts ADD CONSTRAINT chk_debt_valid_interest 
    CHECK (interest_rate >= 0 AND interest_rate <= 1);

-- Ensure valid dates
ALTER TABLE velocity_cycles ADD CONSTRAINT chk_cycle_valid_dates 
    CHECK (end_date IS NULL OR end_date >= start_date);
```

---

## Financial Calculation Engine

The financial calculation engine is the core component that implements velocity banking algorithms and provides sophisticated financial analysis capabilities.

### Core Calculation Classes

**VelocityBankingCalculator:**
The main calculator class implements the primary velocity banking algorithms and optimization strategies.

```python
class VelocityBankingCalculator:
    """
    Core velocity banking calculation engine.
    
    This class implements sophisticated algorithms for optimizing debt payoff
    strategies using velocity banking principles.
    """
    
    def __init__(self):
        self.precision = Decimal('0.01')  # Financial precision to cents
        
    def calculate_velocity_banking_strategy(self, debts: List[Debt], 
                                          profile: FinancialProfile) -> PayoffResult:
        """
        Calculate optimal velocity banking strategy for given debts and profile.
        
        Args:
            debts: List of debt objects with current balances and terms
            profile: User's financial profile with income and expense data
            
        Returns:
            PayoffResult with timeline, interest savings, and payment schedule
        """
```

**Debt Optimization Algorithms:**
Multiple optimization strategies are implemented to provide comprehensive analysis:

```python
def calculate_debt_avalanche(self, debts: List[Debt], 
                           extra_payment: Decimal) -> PayoffResult:
    """
    Calculate debt avalanche strategy (highest interest first).
    
    This method implements the traditional debt avalanche approach,
    prioritizing debts by interest rate for mathematical optimization.
    """
    
def calculate_debt_snowball(self, debts: List[Debt], 
                          extra_payment: Decimal) -> PayoffResult:
    """
    Calculate debt snowball strategy (smallest balance first).
    
    This method implements the debt snowball approach, prioritizing
    psychological wins through quick debt elimination.
    """
    
def calculate_velocity_banking_optimization(self, debts: List[Debt], 
                                          profile: FinancialProfile) -> PayoffResult:
    """
    Calculate velocity banking optimization strategy.
    
    This method implements the core velocity banking algorithm,
    optimizing payment timing and cash flow for maximum efficiency.
    """
```

### Advanced Financial Modeling

**Interest Calculation Methods:**
The engine supports multiple interest calculation methods to accurately model different debt types:

```python
def calculate_daily_interest(self, balance: Decimal, annual_rate: Decimal, 
                           days: int) -> Decimal:
    """Calculate daily compound interest for credit cards and lines of credit."""
    daily_rate = annual_rate / Decimal('365')
    return balance * daily_rate * Decimal(str(days))

def calculate_monthly_interest(self, balance: Decimal, annual_rate: Decimal) -> Decimal:
    """Calculate monthly interest for installment loans."""
    monthly_rate = annual_rate / Decimal('12')
    return balance * monthly_rate

def calculate_amortized_payment(self, principal: Decimal, annual_rate: Decimal, 
                              term_months: int) -> Decimal:
    """Calculate fixed payment amount for amortized loans."""
    monthly_rate = annual_rate / Decimal('12')
    if monthly_rate == 0:
        return principal / Decimal(str(term_months))
    
    factor = (1 + monthly_rate) ** term_months
    return principal * (monthly_rate * factor) / (factor - 1)
```

**Cash Flow Optimization:**
Sophisticated cash flow modeling optimizes payment timing for maximum interest savings:

```python
def optimize_payment_timing(self, debts: List[Debt], income_schedule: List[IncomeEvent], 
                          expense_schedule: List[ExpenseEvent]) -> PaymentSchedule:
    """
    Optimize payment timing based on income and expense patterns.
    
    This method analyzes cash flow patterns to determine optimal payment
    timing that minimizes average daily balances and interest charges.
    """
    
def calculate_cycle_effectiveness(self, paycheck_amount: Decimal, 
                                debt_payments: Decimal, expenses: Decimal, 
                                cycle_days: int) -> Decimal:
    """
    Calculate the effectiveness of a velocity banking cycle.
    
    Effectiveness is measured as the percentage of the paycheck that
    effectively contributes to debt reduction after necessary expenses.
    """
```

### Scenario Analysis and Projections

**Scenario Comparison Engine:**
The engine provides comprehensive scenario comparison capabilities:

```python
def compare_strategies(self, debts: List[Debt], profile: FinancialProfile, 
                      extra_payment: Decimal = Decimal('0')) -> Dict[str, PayoffResult]:
    """
    Compare multiple debt payoff strategies.
    
    Returns:
        Dictionary mapping strategy names to PayoffResult objects
    """
    strategies = {}
    
    # Calculate minimum payments scenario
    strategies['minimum_payments'] = self.calculate_minimum_payments(debts)
    
    # Calculate debt avalanche scenario
    strategies['debt_avalanche'] = self.calculate_debt_avalanche(debts, extra_payment)
    
    # Calculate debt snowball scenario
    strategies['debt_snowball'] = self.calculate_debt_snowball(debts, extra_payment)
    
    # Calculate velocity banking scenario
    strategies['velocity_banking'] = self.calculate_velocity_banking_strategy(debts, profile)
    
    return strategies
```

**Sensitivity Analysis:**
The engine performs sensitivity analysis to understand the impact of variable changes:

```python
def perform_sensitivity_analysis(self, debts: List[Debt], profile: FinancialProfile, 
                               variables: Dict[str, List[Decimal]]) -> SensitivityResult:
    """
    Perform sensitivity analysis on key variables.
    
    Args:
        variables: Dictionary mapping variable names to lists of values to test
        
    Returns:
        SensitivityResult showing impact of variable changes on outcomes
    """
```

### Performance Optimization

**Calculation Caching:**
Expensive calculations are cached to improve performance:

```python
from functools import lru_cache

@lru_cache(maxsize=1000)
def _calculate_payment_schedule(self, debt_hash: str, strategy: str) -> PaymentSchedule:
    """
    Cached calculation of payment schedules for identical debt configurations.
    
    Uses LRU cache to store results of expensive calculations and avoid
    redundant computation for similar debt scenarios.
    """
```

**Parallel Processing:**
CPU-intensive calculations utilize parallel processing where appropriate:

```python
from concurrent.futures import ThreadPoolExecutor
import multiprocessing

def calculate_multiple_scenarios(self, scenario_configs: List[ScenarioConfig]) -> List[PayoffResult]:
    """
    Calculate multiple scenarios in parallel for improved performance.
    
    Uses thread pool executor to parallelize independent calculations
    across multiple CPU cores.
    """
    max_workers = min(len(scenario_configs), multiprocessing.cpu_count())
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(self._calculate_scenario, config) 
                  for config in scenario_configs]
        return [future.result() for future in futures]
```

### Data Models and Types

**Financial Data Types:**
Comprehensive data models ensure type safety and data integrity:

```python
from dataclasses import dataclass
from decimal import Decimal
from datetime import date
from enum import Enum

class DebtType(Enum):
    CREDIT_CARD = "credit_card"
    PERSONAL_LOAN = "personal_loan"
    AUTO_LOAN = "auto_loan"
    STUDENT_LOAN = "student_loan"
    MORTGAGE = "mortgage"
    OTHER = "other"

@dataclass
class Debt:
    id: str
    name: str
    debt_type: DebtType
    current_balance: Decimal
    interest_rate: Decimal
    minimum_payment: Decimal
    payment_due_date: int
    
@dataclass
class FinancialProfile:
    monthly_income: Decimal
    monthly_expenses: Decimal
    emergency_fund: Decimal
    available_cash_flow: Decimal
    
@dataclass
class PayoffResult:
    total_months: int
    total_interest_paid: Decimal
    interest_saved_vs_minimum: Decimal
    debt_free_date: date
    payment_schedule: List[PaymentEvent]
```

---

## Security Implementation

Security is paramount in a financial application, and the Velocity Banking SaaS implements multiple layers of protection to safeguard user data and prevent unauthorized access.

### Authentication Security

**Password Security:**
The application implements industry-standard password security practices:

```python
from werkzeug.security import generate_password_hash, check_password_hash
import secrets
import hashlib

class PasswordManager:
    @staticmethod
    def hash_password(password: str) -> str:
        """
        Generate secure password hash using PBKDF2 with SHA-256.
        
        Uses high iteration count and random salt for maximum security.
        """
        return generate_password_hash(password, method='pbkdf2:sha256:600000')
    
    @staticmethod
    def verify_password(password: str, password_hash: str) -> bool:
        """Verify password against stored hash."""
        return check_password_hash(password_hash, password)
    
    @staticmethod
    def generate_secure_token(length: int = 32) -> str:
        """Generate cryptographically secure random token."""
        return secrets.token_urlsafe(length)
```

**JWT Token Security:**
JSON Web Tokens are implemented with security best practices:

```python
from flask_jwt_extended import JWTManager, create_access_token, create_refresh_token
from datetime import timedelta

class TokenManager:
    def __init__(self, app):
        self.jwt = JWTManager(app)
        
        # Configure JWT settings
        app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY')
        app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
        app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)
        app.config['JWT_ALGORITHM'] = 'HS256'
        
        # Token blacklist for revocation
        self.blacklisted_tokens = set()
        
    def create_tokens(self, user_id: str) -> Dict[str, str]:
        """Create access and refresh tokens for user."""
        access_token = create_access_token(identity=user_id)
        refresh_token = create_refresh_token(identity=user_id)
        
        return {
            'access_token': access_token,
            'refresh_token': refresh_token
        }
```

### Data Encryption

**Sensitive Data Encryption:**
Financial account numbers and other sensitive data are encrypted at rest:

```python
from cryptography.fernet import Fernet
import os
import base64

class DataEncryption:
    def __init__(self):
        # Use environment variable for encryption key
        key = os.environ.get('ENCRYPTION_KEY')
        if not key:
            raise ValueError("ENCRYPTION_KEY environment variable not set")
        
        self.cipher_suite = Fernet(key.encode())
    
    def encrypt_data(self, data: str) -> str:
        """Encrypt sensitive data for storage."""
        if not data:
            return data
        
        encrypted_data = self.cipher_suite.encrypt(data.encode())
        return base64.b64encode(encrypted_data).decode()
    
    def decrypt_data(self, encrypted_data: str) -> str:
        """Decrypt sensitive data for use."""
        if not encrypted_data:
            return encrypted_data
        
        encrypted_bytes = base64.b64decode(encrypted_data.encode())
        decrypted_data = self.cipher_suite.decrypt(encrypted_bytes)
        return decrypted_data.decode()
```

### Input Validation and Sanitization

**Comprehensive Input Validation:**
All user inputs are validated and sanitized to prevent injection attacks:

```python
from marshmallow import Schema, fields, validate, ValidationError
from decimal import Decimal, InvalidOperation

class DebtSchema(Schema):
    debt_name = fields.Str(required=True, validate=validate.Length(min=1, max=100))
    debt_type = fields.Str(required=True, validate=validate.OneOf([
        'credit_card', 'personal_loan', 'auto_loan', 'student_loan', 'mortgage', 'other'
    ]))
    current_balance = fields.Decimal(required=True, validate=validate.Range(min=0))
    interest_rate = fields.Decimal(required=True, validate=validate.Range(min=0, max=1))
    minimum_payment = fields.Decimal(required=True, validate=validate.Range(min=0))
    
    def validate_financial_logic(self, data, **kwargs):
        """Custom validation for financial business logic."""
        if data.get('minimum_payment', 0) > data.get('current_balance', 0):
            raise ValidationError('Minimum payment cannot exceed current balance')
```

**SQL Injection Prevention:**
SQLAlchemy ORM provides protection against SQL injection, with additional safeguards:

```python
from sqlalchemy import text
from sqlalchemy.orm import Session

class SecureQueryBuilder:
    @staticmethod
    def build_user_debt_query(user_id: int, filters: Dict[str, Any]) -> str:
        """
        Build parameterized query for user debts with filters.
        
        All parameters are properly escaped to prevent SQL injection.
        """
        base_query = "SELECT * FROM debts WHERE user_id = :user_id"
        params = {'user_id': user_id}
        
        if filters.get('debt_type'):
            base_query += " AND debt_type = :debt_type"
            params['debt_type'] = filters['debt_type']
        
        if filters.get('is_active') is not None:
            base_query += " AND is_active = :is_active"
            params['is_active'] = filters['is_active']
        
        return text(base_query), params
```

### API Security

**Rate Limiting:**
API endpoints are protected with rate limiting to prevent abuse:

```python
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

class RateLimitManager:
    def __init__(self, app):
        self.limiter = Limiter(
            app,
            key_func=get_remote_address,
            default_limits=["1000 per hour", "100 per minute"]
        )
        
        # Specific limits for sensitive endpoints
        self.limiter.limit("5 per minute")(self.login_endpoint)
        self.limiter.limit("3 per minute")(self.password_reset_endpoint)
        self.limiter.limit("10 per minute")(self.calculation_endpoints)
```

**CORS Configuration:**
Cross-Origin Resource Sharing is configured securely:

```python
from flask_cors import CORS

class CORSManager:
    def __init__(self, app):
        # Configure CORS with specific origins for production
        allowed_origins = os.environ.get('ALLOWED_ORIGINS', '').split(',')
        
        CORS(app, 
             origins=allowed_origins,
             methods=['GET', 'POST', 'PUT', 'DELETE'],
             allow_headers=['Content-Type', 'Authorization'],
             supports_credentials=True)
```

### Security Monitoring and Logging

**Audit Logging:**
All security-relevant events are logged for monitoring and compliance:

```python
import logging
from datetime import datetime
from flask import request, g

class SecurityLogger:
    def __init__(self):
        self.logger = logging.getLogger('security')
        self.logger.setLevel(logging.INFO)
        
    def log_authentication_attempt(self, email: str, success: bool, ip_address: str):
        """Log authentication attempts for security monitoring."""
        self.logger.info(f"Authentication attempt: {email}, Success: {success}, IP: {ip_address}")
        
    def log_sensitive_data_access(self, user_id: int, resource_type: str, resource_id: int):
        """Log access to sensitive financial data."""
        self.logger.info(f"Sensitive data access: User {user_id}, {resource_type} {resource_id}")
        
    def log_security_violation(self, violation_type: str, details: Dict[str, Any]):
        """Log security violations for immediate attention."""
        self.logger.warning(f"Security violation: {violation_type}, Details: {details}")
```

**Intrusion Detection:**
Basic intrusion detection monitors for suspicious patterns:

```python
from collections import defaultdict
from datetime import datetime, timedelta

class IntrusionDetector:
    def __init__(self):
        self.failed_attempts = defaultdict(list)
        self.suspicious_patterns = defaultdict(int)
        
    def check_brute_force(self, ip_address: str) -> bool:
        """Check for brute force attack patterns."""
        now = datetime.utcnow()
        recent_attempts = [
            attempt for attempt in self.failed_attempts[ip_address]
            if now - attempt < timedelta(minutes=15)
        ]
        
        return len(recent_attempts) > 5
        
    def record_failed_attempt(self, ip_address: str):
        """Record failed authentication attempt."""
        self.failed_attempts[ip_address].append(datetime.utcnow())
        
        if self.check_brute_force(ip_address):
            self.trigger_security_alert(ip_address, "brute_force_detected")
```

---


## Deployment Guide

The Velocity Banking SaaS application supports multiple deployment strategies, from development environments to production-scale deployments with high availability and scalability.

### Development Environment Setup

**Prerequisites:**
- Python 3.11 or higher
- Node.js 18.0 or higher
- Git for version control
- SQLite for development database

**Backend Setup:**
```bash
# Clone the repository
git clone <repository-url>
cd velocity-banking-saas/backend/velocity-banking-api

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Initialize database
python create_db.py

# Run development server
cd src && python main.py
```

**Frontend Setup:**
```bash
# Navigate to frontend directory
cd velocity-banking-saas/frontend/velocity-banking-ui

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env.local
# Edit .env.local with your configuration

# Start development server
npm run dev
```

### Production Deployment

**Docker Containerization:**
The application includes Docker configurations for consistent deployment across environments.

**Backend Dockerfile:**
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY src/ ./src/
COPY create_db.py .

# Create non-root user
RUN useradd -m -u 1000 appuser && chown -R appuser:appuser /app
USER appuser

# Expose port
EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:5000/api/health || exit 1

# Start application
CMD ["python", "src/main.py"]
```

**Frontend Dockerfile:**
```dockerfile
# Build stage
FROM node:18-alpine AS builder

WORKDIR /app

# Copy package files
COPY package*.json ./
RUN npm ci --only=production

# Copy source code and build
COPY . .
RUN npm run build

# Production stage
FROM nginx:alpine

# Copy built application
COPY --from=builder /app/dist /usr/share/nginx/html

# Copy nginx configuration
COPY nginx.conf /etc/nginx/nginx.conf

# Expose port
EXPOSE 80

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD curl -f http://localhost/health || exit 1

CMD ["nginx", "-g", "daemon off;"]
```

**Docker Compose Configuration:**
```yaml
version: '3.8'

services:
  backend:
    build: ./backend/velocity-banking-api
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/velocity_banking
      - JWT_SECRET_KEY=${JWT_SECRET_KEY}
      - ENCRYPTION_KEY=${ENCRYPTION_KEY}
    depends_on:
      - db
      - redis
    volumes:
      - ./logs:/app/logs
    restart: unless-stopped

  frontend:
    build: ./frontend/velocity-banking-ui
    ports:
      - "80:80"
    depends_on:
      - backend
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=velocity_banking
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/init.sql:/docker-entrypoint-initdb.d/init.sql
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
```

### Cloud Deployment Strategies

**AWS Deployment:**
The application can be deployed on AWS using various services for different scalability requirements.

**ECS Fargate Deployment:**
```yaml
# task-definition.json
{
  "family": "velocity-banking-saas",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "arn:aws:iam::account:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::account:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "backend",
      "image": "your-account.dkr.ecr.region.amazonaws.com/velocity-banking-backend:latest",
      "portMappings": [
        {
          "containerPort": 5000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "DATABASE_URL",
          "value": "postgresql://user:password@rds-endpoint:5432/velocity_banking"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/velocity-banking-saas",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

**Kubernetes Deployment:**
```yaml
# kubernetes/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: velocity-banking-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: velocity-banking-backend
  template:
    metadata:
      labels:
        app: velocity-banking-backend
    spec:
      containers:
      - name: backend
        image: velocity-banking-backend:latest
        ports:
        - containerPort: 5000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: velocity-banking-secrets
              key: database-url
        - name: JWT_SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: velocity-banking-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/health
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5
```

### Environment Configuration

**Environment Variables:**
Comprehensive environment variable configuration for different deployment environments.

**Backend Environment Variables:**
```bash
# Database Configuration
DATABASE_URL=postgresql://user:password@localhost:5432/velocity_banking
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30

# Security Configuration
JWT_SECRET_KEY=your-super-secret-jwt-key-here
ENCRYPTION_KEY=your-encryption-key-for-sensitive-data
SESSION_SECRET_KEY=your-session-secret-key

# Application Configuration
FLASK_ENV=production
FLASK_DEBUG=False
API_VERSION=v1
CORS_ORIGINS=https://yourdomain.com,https://www.yourdomain.com

# External Service Configuration
REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/1

# Monitoring and Logging
LOG_LEVEL=INFO
SENTRY_DSN=your-sentry-dsn-for-error-tracking
NEW_RELIC_LICENSE_KEY=your-new-relic-license-key

# Email Configuration
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

**Frontend Environment Variables:**
```bash
# API Configuration
VITE_API_BASE_URL=https://api.yourdomain.com
VITE_API_VERSION=v1

# Application Configuration
VITE_APP_NAME=Velocity Banking SaaS
VITE_APP_VERSION=1.0.0
VITE_ENVIRONMENT=production

# Analytics and Monitoring
VITE_GOOGLE_ANALYTICS_ID=GA_MEASUREMENT_ID
VITE_SENTRY_DSN=your-frontend-sentry-dsn

# Feature Flags
VITE_ENABLE_ANALYTICS=true
VITE_ENABLE_CHAT_SUPPORT=true
VITE_ENABLE_BETA_FEATURES=false
```

### Database Migration and Backup

**Database Migration Strategy:**
```python
# migrations/migration_manager.py
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import os

class MigrationManager:
    def __init__(self, database_url: str):
        self.engine = create_engine(database_url)
        self.Session = sessionmaker(bind=self.engine)
        
    def run_migrations(self):
        """Run all pending database migrations."""
        migration_files = sorted([
            f for f in os.listdir('migrations/sql')
            if f.endswith('.sql')
        ])
        
        with self.Session() as session:
            for migration_file in migration_files:
                if not self._is_migration_applied(session, migration_file):
                    self._apply_migration(session, migration_file)
                    
    def _apply_migration(self, session, migration_file: str):
        """Apply a single migration file."""
        with open(f'migrations/sql/{migration_file}', 'r') as f:
            migration_sql = f.read()
            
        session.execute(text(migration_sql))
        session.commit()
        
        # Record migration as applied
        session.execute(text(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (:version, NOW())"
        ), {'version': migration_file})
        session.commit()
```

**Backup Strategy:**
```bash
#!/bin/bash
# scripts/backup_database.sh

# Database backup script for production environments
BACKUP_DIR="/backups/velocity-banking"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="velocity_banking_backup_${TIMESTAMP}.sql"

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Perform database backup
pg_dump $DATABASE_URL > "${BACKUP_DIR}/${BACKUP_FILE}"

# Compress backup
gzip "${BACKUP_DIR}/${BACKUP_FILE}"

# Upload to S3 for offsite storage
aws s3 cp "${BACKUP_DIR}/${BACKUP_FILE}.gz" s3://your-backup-bucket/database/

# Clean up old backups (keep last 30 days)
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete

echo "Database backup completed: ${BACKUP_FILE}.gz"
```

### Monitoring and Health Checks

**Application Health Checks:**
```python
# src/routes/health.py
from flask import Blueprint, jsonify
from sqlalchemy import text
from src.models import db
import redis
import os

health_bp = Blueprint('health', __name__)

@health_bp.route('/health', methods=['GET'])
def health_check():
    """Comprehensive health check endpoint."""
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': os.environ.get('APP_VERSION', '1.0.0'),
        'checks': {}
    }
    
    # Database health check
    try:
        db.session.execute(text('SELECT 1'))
        health_status['checks']['database'] = 'healthy'
    except Exception as e:
        health_status['checks']['database'] = f'unhealthy: {str(e)}'
        health_status['status'] = 'unhealthy'
    
    # Redis health check
    try:
        redis_client = redis.from_url(os.environ.get('REDIS_URL'))
        redis_client.ping()
        health_status['checks']['redis'] = 'healthy'
    except Exception as e:
        health_status['checks']['redis'] = f'unhealthy: {str(e)}'
        health_status['status'] = 'degraded'
    
    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code
```

**Monitoring Configuration:**
```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'velocity-banking-backend'
    static_configs:
      - targets: ['backend:5000']
    metrics_path: '/metrics'
    scrape_interval: 30s

  - job_name: 'velocity-banking-frontend'
    static_configs:
      - targets: ['frontend:80']
    metrics_path: '/metrics'
    scrape_interval: 30s

rule_files:
  - "alert_rules.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093
```

---

## API Reference

This section provides comprehensive documentation for all API endpoints, including request/response formats, authentication requirements, and example usage.

### Authentication Endpoints

**POST /api/auth/register**
Register a new user account.

*Request Body:*
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "first_name": "John",
  "last_name": "Doe",
  "phone": "+1 (555) 123-4567"
}
```

*Response (201 Created):*
```json
{
  "success": true,
  "data": {
    "user": {
      "id": 1,
      "email": "user@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "subscription_tier": "free",
      "is_email_verified": false
    },
    "tokens": {
      "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
      "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
    }
  },
  "message": "Account created successfully"
}
```

**POST /api/auth/login**
Authenticate user and return access tokens.

*Request Body:*
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
```

*Response (200 OK):*
```json
{
  "success": true,
  "data": {
    "user": {
      "id": 1,
      "email": "user@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "subscription_tier": "premium"
    },
    "tokens": {
      "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
      "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
    }
  },
  "message": "Login successful"
}
```

### Debt Management Endpoints

**GET /api/debts**
Retrieve all debts for the authenticated user.

*Headers:*
```
Authorization: Bearer <access_token>
```

*Query Parameters:*
- `debt_type` (optional): Filter by debt type
- `is_active` (optional): Filter by active status
- `sort_by` (optional): Sort field (balance, interest_rate, name)
- `sort_order` (optional): Sort direction (asc, desc)

*Response (200 OK):*
```json
{
  "success": true,
  "data": {
    "debts": [
      {
        "id": 1,
        "debt_name": "Chase Freedom Credit Card",
        "debt_type": "credit_card",
        "current_balance": 5000.00,
        "original_balance": 8000.00,
        "interest_rate": 0.18,
        "minimum_payment": 150.00,
        "payment_due_date": 15,
        "priority_order": 1,
        "is_active": true,
        "created_at": "2025-01-15T10:30:00Z",
        "updated_at": "2025-07-29T14:20:00Z"
      }
    ],
    "total_debt": 33000.00,
    "total_minimum_payments": 900.00,
    "average_interest_rate": 0.14
  }
}
```

**POST /api/debts**
Add a new debt to the user's portfolio.

*Headers:*
```
Authorization: Bearer <access_token>
```

*Request Body:*
```json
{
  "debt_name": "Personal Loan",
  "debt_type": "personal_loan",
  "current_balance": 10000.00,
  "interest_rate": 0.12,
  "minimum_payment": 300.00,
  "payment_due_date": 10,
  "term_months": 36,
  "notes": "Used for home improvement"
}
```

*Response (201 Created):*
```json
{
  "success": true,
  "data": {
    "debt": {
      "id": 5,
      "debt_name": "Personal Loan",
      "debt_type": "personal_loan",
      "current_balance": 10000.00,
      "original_balance": 10000.00,
      "interest_rate": 0.12,
      "minimum_payment": 300.00,
      "payment_due_date": 10,
      "term_months": 36,
      "priority_order": 5,
      "is_active": true,
      "notes": "Used for home improvement",
      "created_at": "2025-07-29T14:30:00Z"
    }
  },
  "message": "Debt added successfully"
}
```

### Financial Calculation Endpoints

**POST /api/calculations/debt-optimization**
Calculate optimal debt payoff strategy using velocity banking.

*Headers:*
```
Authorization: Bearer <access_token>
```

*Request Body:*
```json
{
  "strategy": "velocity_banking",
  "extra_payment": 500.00,
  "include_scenarios": ["debt_avalanche", "debt_snowball", "minimum_payments"]
}
```

*Response (200 OK):*
```json
{
  "success": true,
  "data": {
    "optimization_result": {
      "recommended_strategy": "velocity_banking",
      "total_months": 24,
      "total_interest_paid": 3250.75,
      "interest_saved_vs_minimum": 8749.25,
      "debt_free_date": "2027-07-29",
      "monthly_payment_schedule": [
        {
          "month": 1,
          "debt_payments": [
            {
              "debt_id": 1,
              "payment_amount": 650.00,
              "principal": 575.00,
              "interest": 75.00,
              "remaining_balance": 4425.00
            }
          ]
        }
      ]
    },
    "scenario_comparison": {
      "velocity_banking": {
        "total_months": 24,
        "total_interest": 3250.75
      },
      "debt_avalanche": {
        "total_months": 28,
        "total_interest": 4100.50
      },
      "debt_snowball": {
        "total_months": 30,
        "total_interest": 4500.25
      },
      "minimum_payments": {
        "total_months": 120,
        "total_interest": 12000.00
      }
    }
  }
}
```

**POST /api/calculations/velocity-cycle**
Calculate velocity cycle effectiveness and optimization.

*Headers:*
```
Authorization: Bearer <access_token>
```

*Request Body:*
```json
{
  "paycheck_amount": 3000.00,
  "cycle_expenses": 2000.00,
  "debt_allocation": 1000.00,
  "cycle_length_days": 14
}
```

*Response (200 OK):*
```json
{
  "success": true,
  "data": {
    "cycle_analysis": {
      "cycle_effectiveness": 0.567,
      "debt_payments": 1000.00,
      "interest_saved": 45.75,
      "cash_flow_optimization": 0.85,
      "recommendations": [
        {
          "type": "payment_timing",
          "description": "Make debt payments immediately upon receiving paycheck",
          "potential_savings": 15.25
        },
        {
          "type": "expense_timing",
          "description": "Delay non-urgent expenses to end of cycle",
          "potential_savings": 8.50
        }
      ]
    },
    "optimization_suggestions": {
      "optimal_debt_allocation": 1200.00,
      "projected_effectiveness": 0.642,
      "additional_interest_savings": 23.40
    }
  }
}
```

### Error Response Examples

**400 Bad Request - Validation Error:**
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Input validation failed",
    "details": {
      "field_errors": {
        "interest_rate": ["Interest rate must be between 0 and 1"],
        "current_balance": ["Current balance must be greater than 0"]
      }
    }
  },
  "timestamp": "2025-07-29T14:30:00Z"
}
```

**401 Unauthorized:**
```json
{
  "success": false,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Authentication required"
  },
  "timestamp": "2025-07-29T14:30:00Z"
}
```

**404 Not Found:**
```json
{
  "success": false,
  "error": {
    "code": "RESOURCE_NOT_FOUND",
    "message": "Debt with ID 999 not found"
  },
  "timestamp": "2025-07-29T14:30:00Z"
}
```

**429 Too Many Requests:**
```json
{
  "success": false,
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Too many requests. Please try again later.",
    "details": {
      "retry_after": 60,
      "limit": "100 requests per minute"
    }
  },
  "timestamp": "2025-07-29T14:30:00Z"
}
```

### Rate Limiting

All API endpoints are subject to rate limiting to ensure fair usage and system stability:

- **General endpoints:** 1000 requests per hour, 100 requests per minute
- **Authentication endpoints:** 5 requests per minute
- **Calculation endpoints:** 10 requests per minute
- **Data modification endpoints:** 50 requests per minute

Rate limit headers are included in all responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1690632000
```

### Pagination

List endpoints support cursor-based pagination for optimal performance:

*Query Parameters:*
- `limit`: Number of items per page (default: 20, max: 100)
- `cursor`: Pagination cursor for next/previous page

*Pagination Response:*
```json
{
  "pagination": {
    "has_next": true,
    "has_previous": false,
    "next_cursor": "eyJpZCI6MTIzfQ==",
    "previous_cursor": null,
    "total_count": 150
  }
}
```

---

## Conclusion

This technical documentation provides comprehensive coverage of the Velocity Banking SaaS application architecture, implementation details, and deployment strategies. The system is designed with scalability, security, and maintainability as core principles, utilizing modern technologies and best practices throughout.

The modular architecture enables independent scaling of components, while the comprehensive API design supports both current functionality and future feature expansion. Security measures are implemented at multiple layers to protect sensitive financial data, and the deployment strategies support various environments from development to enterprise-scale production.

For additional technical support or questions about implementation details, please refer to the inline code documentation or contact the development team.

**Document Version:** 1.0  
**Last Updated:** July 29, 2025  
**Author:** Manus AI  
**Application Version:** 1.0.0

