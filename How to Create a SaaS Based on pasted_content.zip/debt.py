import uuid
from datetime import datetime, timezone, date
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Text, Numeric, Boolean, Integer, Date
from . import db

class Debt(db.Model):
    __tablename__ = 'debts'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    bank_account_id = db.Column(UUID(as_uuid=True), db.ForeignKey('bank_accounts.id'))
    
    # Debt information
    debt_name = db.Column(String(200), nullable=False)
    debt_type = db.Column(String(50), nullable=False)  # credit_card, personal_loan, mortgage, auto_loan, student_loan, other
    
    # Balance information
    original_balance = db.Column(Numeric(12, 2), nullable=False)
    current_balance = db.Column(Numeric(12, 2), nullable=False)
    
    # Interest and payment information
    interest_rate = db.Column(Numeric(5, 4), nullable=False)  # Annual percentage rate
    minimum_payment = db.Column(Numeric(10, 2), nullable=False)
    payment_due_date = db.Column(Integer)  # Day of month (1-31)
    
    # Loan term information
    term_months = db.Column(Integer)  # Original loan term in months
    remaining_months = db.Column(Integer)  # Calculated remaining months
    
    # Status and priority
    is_active = db.Column(Boolean, default=True)
    priority_order = db.Column(Integer, default=0)  # User-defined priority
    optimization_order = db.Column(Integer)  # System-calculated optimal order
    
    # Target and notes
    payoff_target_date = db.Column(Date)
    notes = db.Column(Text)
    
    # Timestamps
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    debt_payments = db.relationship('DebtPayment', backref='debt', cascade='all, delete-orphan')
    transactions = db.relationship('Transaction', backref='debt')
    
    def __repr__(self):
        return f'<Debt {self.debt_name}>'
    
    def to_dict(self):
        """Convert debt to dictionary."""
        return {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'bank_account_id': str(self.bank_account_id) if self.bank_account_id else None,
            'debt_name': self.debt_name,
            'debt_type': self.debt_type,
            'original_balance': float(self.original_balance),
            'current_balance': float(self.current_balance),
            'interest_rate': float(self.interest_rate),
            'minimum_payment': float(self.minimum_payment),
            'payment_due_date': self.payment_due_date,
            'term_months': self.term_months,
            'remaining_months': self.remaining_months,
            'is_active': self.is_active,
            'priority_order': self.priority_order,
            'optimization_order': self.optimization_order,
            'payoff_target_date': self.payoff_target_date.isoformat() if self.payoff_target_date else None,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def calculate_monthly_interest(self):
        """Calculate monthly interest amount."""
        monthly_rate = float(self.interest_rate) / 12
        return float(self.current_balance) * monthly_rate
    
    def calculate_payoff_time_minimum_payments(self):
        """Calculate time to payoff with minimum payments only."""
        if self.current_balance <= 0 or self.minimum_payment <= 0:
            return 0
        
        balance = float(self.current_balance)
        monthly_payment = float(self.minimum_payment)
        monthly_rate = float(self.interest_rate) / 12
        
        if monthly_payment <= balance * monthly_rate:
            return float('inf')  # Never pays off
        
        months = 0
        while balance > 0.01 and months < 600:  # Cap at 50 years
            interest = balance * monthly_rate
            principal = monthly_payment - interest
            balance -= principal
            months += 1
        
        return months
    
    def calculate_total_interest_minimum_payments(self):
        """Calculate total interest paid with minimum payments."""
        months = self.calculate_payoff_time_minimum_payments()
        if months == float('inf'):
            return float('inf')
        
        total_payments = float(self.minimum_payment) * months
        return total_payments - float(self.current_balance)
    
    def calculate_payoff_with_extra_payment(self, extra_payment):
        """Calculate payoff time and interest with extra payment."""
        if self.current_balance <= 0:
            return {'months': 0, 'total_interest': 0, 'total_payments': 0}
        
        balance = float(self.current_balance)
        monthly_payment = float(self.minimum_payment) + extra_payment
        monthly_rate = float(self.interest_rate) / 12
        
        if monthly_payment <= balance * monthly_rate:
            return {'months': float('inf'), 'total_interest': float('inf'), 'total_payments': float('inf')}
        
        months = 0
        total_interest = 0
        
        while balance > 0.01 and months < 600:
            interest = balance * monthly_rate
            principal = min(monthly_payment - interest, balance)
            balance -= principal
            total_interest += interest
            months += 1
        
        total_payments = float(self.minimum_payment) * months + extra_payment * months
        
        return {
            'months': months,
            'total_interest': total_interest,
            'total_payments': total_payments
        }
    
    def update_balance(self, new_balance):
        """Update debt balance and recalculate remaining months."""
        self.current_balance = new_balance
        
        if new_balance <= 0:
            self.is_active = False
            self.remaining_months = 0
        else:
            self.remaining_months = self.calculate_payoff_time_minimum_payments()
        
        db.session.commit()
    
    def make_payment(self, payment_amount, payment_date=None):
        """Record a debt payment and update balance."""
        if payment_date is None:
            payment_date = date.today()
        
        # Calculate interest and principal portions
        monthly_interest = self.calculate_monthly_interest()
        interest_amount = min(monthly_interest, payment_amount)
        principal_amount = payment_amount - interest_amount
        
        # Update balance
        new_balance = max(0, float(self.current_balance) - principal_amount)
        self.update_balance(new_balance)
        
        # Create debt payment record
        from .debt_payment import DebtPayment
        debt_payment = DebtPayment(
            user_id=self.user_id,
            debt_id=self.id,
            payment_date=payment_date,
            payment_amount=payment_amount,
            principal_amount=principal_amount,
            interest_amount=interest_amount,
            remaining_balance=new_balance
        )
        
        db.session.add(debt_payment)
        db.session.commit()
        
        return debt_payment
    
    @classmethod
    def get_user_debts(cls, user_id, active_only=True, debt_type=None):
        """Get user's debts with optional filtering."""
        query = cls.query.filter_by(user_id=user_id)
        
        if active_only:
            query = query.filter_by(is_active=True)
        
        if debt_type:
            query = query.filter_by(debt_type=debt_type)
        
        return query.order_by(cls.priority_order, cls.interest_rate.desc()).all()
    
    @classmethod
    def calculate_total_debt(cls, user_id, active_only=True):
        """Calculate total debt for a user."""
        debts = cls.get_user_debts(user_id, active_only)
        return sum(float(debt.current_balance) for debt in debts)
    
    @classmethod
    def calculate_total_minimum_payments(cls, user_id, active_only=True):
        """Calculate total minimum payments for a user."""
        debts = cls.get_user_debts(user_id, active_only)
        return sum(float(debt.minimum_payment) for debt in debts)
    
    def get_debt_priority_score(self):
        """Calculate debt priority score for optimization (higher = pay first)."""
        # Avalanche method: prioritize by interest rate
        return float(self.interest_rate)

