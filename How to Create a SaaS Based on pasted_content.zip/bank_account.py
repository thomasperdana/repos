import uuid
from datetime import datetime, timezone
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Text, Numeric, Boolean, Integer
from . import db

class BankAccount(db.Model):
    __tablename__ = 'bank_accounts'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    
    # Account information
    account_name = db.Column(String(200), nullable=False)
    account_type = db.Column(String(50), nullable=False)  # checking, savings, credit_line, credit_card
    institution_name = db.Column(String(200))
    
    # Encrypted sensitive data (would be encrypted in production)
    account_number_encrypted = db.Column(Text)
    routing_number_encrypted = db.Column(Text)
    
    # Balance information
    current_balance = db.Column(Numeric(12, 2), default=0.00)
    available_balance = db.Column(Numeric(12, 2), default=0.00)
    
    # Credit account specific fields
    credit_limit = db.Column(Numeric(12, 2))
    interest_rate = db.Column(Numeric(5, 4))  # Annual percentage rate
    minimum_payment = db.Column(Numeric(10, 2))
    payment_due_date = db.Column(Integer)  # Day of month (1-31)
    
    # Account status
    is_primary = db.Column(Boolean, default=False)
    is_active = db.Column(Boolean, default=True)
    
    # External integration
    plaid_account_id = db.Column(String(255))
    plaid_access_token_encrypted = db.Column(Text)
    last_sync = db.Column(DateTime(timezone=True))
    sync_status = db.Column(String(20), default='pending')  # pending, synced, error
    
    # Timestamps
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    transactions = db.relationship('Transaction', backref='bank_account', cascade='all, delete-orphan')
    debts = db.relationship('Debt', backref='bank_account')
    
    def __repr__(self):
        return f'<BankAccount {self.account_name}>'
    
    def to_dict(self, include_sensitive=False):
        """Convert bank account to dictionary."""
        data = {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'account_name': self.account_name,
            'account_type': self.account_type,
            'institution_name': self.institution_name,
            'current_balance': float(self.current_balance) if self.current_balance else 0.0,
            'available_balance': float(self.available_balance) if self.available_balance else 0.0,
            'credit_limit': float(self.credit_limit) if self.credit_limit else None,
            'interest_rate': float(self.interest_rate) if self.interest_rate else None,
            'minimum_payment': float(self.minimum_payment) if self.minimum_payment else None,
            'payment_due_date': self.payment_due_date,
            'is_primary': self.is_primary,
            'is_active': self.is_active,
            'last_sync': self.last_sync.isoformat() if self.last_sync else None,
            'sync_status': self.sync_status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
        if include_sensitive:
            data.update({
                'account_number_encrypted': self.account_number_encrypted,
                'routing_number_encrypted': self.routing_number_encrypted,
                'plaid_account_id': self.plaid_account_id,
                'plaid_access_token_encrypted': self.plaid_access_token_encrypted
            })
        
        return data
    
    def is_credit_account(self):
        """Check if this is a credit account (credit card or line of credit)."""
        return self.account_type in ['credit_card', 'credit_line']
    
    def get_available_credit(self):
        """Get available credit for credit accounts."""
        if not self.is_credit_account() or not self.credit_limit:
            return 0
        return float(self.credit_limit) - float(self.current_balance)
    
    def calculate_utilization_ratio(self):
        """Calculate credit utilization ratio for credit accounts."""
        if not self.is_credit_account() or not self.credit_limit or self.credit_limit == 0:
            return 0
        return float(self.current_balance) / float(self.credit_limit)
    
    def update_balance(self, new_balance, available_balance=None):
        """Update account balance and sync timestamp."""
        self.current_balance = new_balance
        if available_balance is not None:
            self.available_balance = available_balance
        else:
            self.available_balance = new_balance
        
        self.last_sync = datetime.now(timezone.utc)
        self.sync_status = 'synced'
        db.session.commit()
    
    @classmethod
    def get_user_accounts(cls, user_id, account_type=None, active_only=True):
        """Get user's bank accounts with optional filtering."""
        query = cls.query.filter_by(user_id=user_id)
        
        if account_type:
            query = query.filter_by(account_type=account_type)
        
        if active_only:
            query = query.filter_by(is_active=True)
        
        return query.all()
    
    @classmethod
    def get_primary_account(cls, user_id):
        """Get user's primary bank account."""
        return cls.query.filter_by(user_id=user_id, is_primary=True, is_active=True).first()
    
    def set_as_primary(self):
        """Set this account as the primary account and unset others."""
        # Unset all other primary accounts for this user
        cls = self.__class__
        cls.query.filter_by(user_id=self.user_id, is_primary=True).update({'is_primary': False})
        
        # Set this account as primary
        self.is_primary = True
        db.session.commit()

