import uuid
from datetime import datetime, timezone, date
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Text, Numeric, Boolean, Date
from . import db

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    bank_account_id = db.Column(UUID(as_uuid=True), db.ForeignKey('bank_accounts.id'))
    debt_id = db.Column(UUID(as_uuid=True), db.ForeignKey('debts.id'))
    velocity_cycle_id = db.Column(UUID(as_uuid=True), db.ForeignKey('velocity_cycles.id'))
    
    # Transaction details
    transaction_date = db.Column(Date, nullable=False)
    amount = db.Column(Numeric(12, 2), nullable=False)
    transaction_type = db.Column(String(50), nullable=False)  # income, expense, debt_payment, transfer, interest
    category = db.Column(String(100))
    subcategory = db.Column(String(100))
    description = db.Column(Text)
    merchant_name = db.Column(String(200))
    
    # Transaction flags
    is_recurring = db.Column(Boolean, default=False)
    is_automated = db.Column(Boolean, default=False)
    
    # External integration
    plaid_transaction_id = db.Column(String(255))
    
    # Timestamps
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    def __repr__(self):
        return f'<Transaction {self.description} - {self.amount}>'
    
    def to_dict(self):
        """Convert transaction to dictionary."""
        return {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'bank_account_id': str(self.bank_account_id) if self.bank_account_id else None,
            'debt_id': str(self.debt_id) if self.debt_id else None,
            'velocity_cycle_id': str(self.velocity_cycle_id) if self.velocity_cycle_id else None,
            'transaction_date': self.transaction_date.isoformat(),
            'amount': float(self.amount),
            'transaction_type': self.transaction_type,
            'category': self.category,
            'subcategory': self.subcategory,
            'description': self.description,
            'merchant_name': self.merchant_name,
            'is_recurring': self.is_recurring,
            'is_automated': self.is_automated,
            'plaid_transaction_id': self.plaid_transaction_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def get_user_transactions(cls, user_id, start_date=None, end_date=None, transaction_type=None, limit=50, offset=0):
        """Get user's transactions with optional filtering."""
        query = cls.query.filter_by(user_id=user_id)
        
        if start_date:
            query = query.filter(cls.transaction_date >= start_date)
        
        if end_date:
            query = query.filter(cls.transaction_date <= end_date)
        
        if transaction_type:
            query = query.filter_by(transaction_type=transaction_type)
        
        return query.order_by(cls.transaction_date.desc()).offset(offset).limit(limit).all()
    
    @classmethod
    def calculate_cash_flow_summary(cls, user_id, start_date=None, end_date=None):
        """Calculate cash flow summary for a user."""
        query = cls.query.filter_by(user_id=user_id)
        
        if start_date:
            query = query.filter(cls.transaction_date >= start_date)
        
        if end_date:
            query = query.filter(cls.transaction_date <= end_date)
        
        transactions = query.all()
        
        summary = {
            'total_income': 0,
            'total_expenses': 0,
            'total_debt_payments': 0,
            'net_cash_flow': 0
        }
        
        for transaction in transactions:
            amount = float(transaction.amount)
            
            if transaction.transaction_type == 'income':
                summary['total_income'] += amount
            elif transaction.transaction_type == 'expense':
                summary['total_expenses'] += abs(amount)  # Expenses are typically negative
            elif transaction.transaction_type == 'debt_payment':
                summary['total_debt_payments'] += abs(amount)
        
        summary['net_cash_flow'] = summary['total_income'] - summary['total_expenses'] - summary['total_debt_payments']
        
        return summary

