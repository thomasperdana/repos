from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

db = SQLAlchemy()
bcrypt = Bcrypt()

# Import all models to ensure they are registered with SQLAlchemy
from .user import User
from .financial_profile import FinancialProfile
from .bank_account import BankAccount
from .debt import Debt
from .transaction import Transaction
from .velocity_cycle import VelocityCycle
from .debt_payment import DebtPayment
from .financial_scenario import FinancialScenario
from .user_session import UserSession
from .audit_log import AuditLog

__all__ = [
    'db', 'bcrypt',
    'User', 'FinancialProfile', 'BankAccount', 'Debt', 
    'Transaction', 'VelocityCycle', 'DebtPayment', 
    'FinancialScenario', 'UserSession', 'AuditLog'
]

