import uuid
from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, Boolean, DateTime, Text
from . import db, bcrypt

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = db.Column(String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(String(255), nullable=False)
    first_name = db.Column(String(100), nullable=False)
    last_name = db.Column(String(100), nullable=False)
    phone = db.Column(String(20))
    date_of_birth = db.Column(db.Date)
    
    # Account status
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    last_login = db.Column(DateTime(timezone=True))
    is_active = db.Column(Boolean, default=True)
    is_verified = db.Column(Boolean, default=False)
    
    # Security
    verification_token = db.Column(String(255))
    password_reset_token = db.Column(String(255))
    password_reset_expires = db.Column(DateTime(timezone=True))
    
    # Subscription
    subscription_tier = db.Column(String(20), default='free')  # free, pro, coach
    subscription_expires = db.Column(DateTime(timezone=True))
    
    # Preferences
    timezone = db.Column(String(50), default='UTC')
    preferences = db.Column(db.JSON, default=dict)
    
    # Relationships
    financial_profile = db.relationship('FinancialProfile', backref='user', uselist=False, cascade='all, delete-orphan')
    bank_accounts = db.relationship('BankAccount', backref='user', cascade='all, delete-orphan')
    debts = db.relationship('Debt', backref='user', cascade='all, delete-orphan')
    transactions = db.relationship('Transaction', backref='user', cascade='all, delete-orphan')
    velocity_cycles = db.relationship('VelocityCycle', backref='user', cascade='all, delete-orphan')
    debt_payments = db.relationship('DebtPayment', backref='user', cascade='all, delete-orphan')
    financial_scenarios = db.relationship('FinancialScenario', backref='user', cascade='all, delete-orphan')
    user_sessions = db.relationship('UserSession', backref='user', cascade='all, delete-orphan')
    audit_logs = db.relationship('AuditLog', backref='user', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<User {self.email}>'
    
    def set_password(self, password):
        """Hash and set the user's password."""
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
    
    def check_password(self, password):
        """Check if the provided password matches the user's password."""
        return bcrypt.check_password_hash(self.password_hash, password)
    
    def to_dict(self, include_sensitive=False):
        """Convert user object to dictionary."""
        data = {
            'id': str(self.id),
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'phone': self.phone,
            'date_of_birth': self.date_of_birth.isoformat() if self.date_of_birth else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'subscription_tier': self.subscription_tier,
            'subscription_expires': self.subscription_expires.isoformat() if self.subscription_expires else None,
            'timezone': self.timezone,
            'preferences': self.preferences or {}
        }
        
        if include_sensitive:
            data.update({
                'verification_token': self.verification_token,
                'password_reset_token': self.password_reset_token,
                'password_reset_expires': self.password_reset_expires.isoformat() if self.password_reset_expires else None
            })
        
        return data
    
    @classmethod
    def find_by_email(cls, email):
        """Find user by email address."""
        return cls.query.filter_by(email=email.lower()).first()
    
    @classmethod
    def find_by_id(cls, user_id):
        """Find user by ID."""
        return cls.query.filter_by(id=user_id).first()
    
    def update_last_login(self):
        """Update the user's last login timestamp."""
        self.last_login = datetime.now(timezone.utc)
        db.session.commit()
    
    def is_subscription_active(self):
        """Check if the user's subscription is active."""
        if self.subscription_tier == 'free':
            return True
        if self.subscription_expires:
            return datetime.now(timezone.utc) < self.subscription_expires
        return False
    
    def can_access_feature(self, feature):
        """Check if user can access a specific feature based on subscription tier."""
        feature_tiers = {
            'basic_dashboard': ['free', 'pro', 'coach'],
            'manual_debt_tracking': ['free', 'pro', 'coach'],
            'bank_integration': ['pro', 'coach'],
            'automation': ['pro', 'coach'],
            'advanced_analytics': ['pro', 'coach'],
            'scenario_modeling': ['pro', 'coach'],
            'coaching_sessions': ['coach'],
            'priority_support': ['pro', 'coach']
        }
        
        allowed_tiers = feature_tiers.get(feature, [])
        return self.subscription_tier in allowed_tiers and self.is_subscription_active()
