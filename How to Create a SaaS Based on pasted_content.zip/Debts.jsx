import React from 'react'
import { CreditCard, Plus } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const Debts = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Debts</h1>
          <p className="text-gray-600">Manage and track all your debts</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Debt
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CreditCard className="mr-2 h-5 w-5" />
            Your Debts
          </CardTitle>
          <CardDescription>
            Track and optimize your debt payoff strategy
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <CreditCard className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">No debts added yet</h3>
            <p className="mt-2 text-gray-600">Get started by adding your first debt</p>
            <Button className="mt-4">
              <Plus className="mr-2 h-4 w-4" />
              Add Your First Debt
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Debts

