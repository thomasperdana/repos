import React from 'react'
import { BarChart3, Plus } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const Scenarios = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Financial Scenarios</h1>
          <p className="text-gray-600">Compare different debt payoff strategies</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Create Scenario
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="mr-2 h-5 w-5" />
            Scenario Analysis
          </CardTitle>
          <CardDescription>
            Model different financial strategies and compare outcomes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <BarChart3 className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">No scenarios created</h3>
            <p className="mt-2 text-gray-600">Create scenarios to compare different strategies</p>
            <Button className="mt-4">
              <Plus className="mr-2 h-4 w-4" />
              Create Your First Scenario
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Scenarios

