from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models import db, User, BankAccount

bank_accounts_bp = Blueprint('bank_accounts', __name__)

@bank_accounts_bp.route('/', methods=['GET'])
@jwt_required()
def get_bank_accounts():
    """Get all user's bank accounts."""
    try:
        current_user_id = get_jwt_identity()
        account_type = request.args.get('type')
        active_only = request.args.get('active', 'true').lower() == 'true'
        
        accounts = BankAccount.get_user_accounts(current_user_id, account_type, active_only)
        
        return jsonify({
            'success': True,
            'data': {
                'accounts': [account.to_dict() for account in accounts],
                'total_count': len(accounts)
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred retrieving bank accounts'
            }
        }), 500

@bank_accounts_bp.route('/', methods=['POST'])
@jwt_required()
def create_bank_account():
    """Add a new bank account."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        account = BankAccount(
            user_id=current_user_id,
            account_name=data['account_name'],
            account_type=data['account_type'],
            institution_name=data.get('institution_name'),
            current_balance=data.get('current_balance', 0),
            credit_limit=data.get('credit_limit'),
            interest_rate=data.get('interest_rate'),
            is_primary=data.get('is_primary', False)
        )
        
        db.session.add(account)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Bank account added successfully',
            'data': account.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred adding bank account'
            }
        }), 500

