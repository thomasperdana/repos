"""
Velocity Banking Calculation Engine

This module implements comprehensive financial calculations for velocity banking strategies,
debt optimization, and financial scenario modeling.
"""

import math
from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


class DebtType(Enum):
    CREDIT_CARD = "credit_card"
    PERSONAL_LOAN = "personal_loan"
    MORTGAGE = "mortgage"
    AUTO_LOAN = "auto_loan"
    STUDENT_LOAN = "student_loan"
    OTHER = "other"


class PayoffStrategy(Enum):
    VELOCITY_BANKING = "velocity_banking"
    DEBT_AVALANCHE = "debt_avalanche"
    DEBT_SNOWBALL = "debt_snowball"
    MINIMUM_PAYMENTS = "minimum_payments"


@dataclass
class Debt:
    """Represents a debt with all necessary information for calculations."""
    id: str
    name: str
    debt_type: DebtType
    current_balance: float
    interest_rate: float  # Annual percentage rate (e.g., 0.18 for 18%)
    minimum_payment: float
    payment_due_date: int  # Day of month (1-31)
    term_months: Optional[int] = None
    
    def __post_init__(self):
        """Validate debt data after initialization."""
        if self.current_balance < 0:
            raise ValueError("Current balance cannot be negative")
        if self.interest_rate < 0 or self.interest_rate > 1:
            raise ValueError("Interest rate must be between 0 and 1")
        if self.minimum_payment < 0:
            raise ValueError("Minimum payment cannot be negative")


@dataclass
class FinancialProfile:
    """Represents a user's financial profile."""
    monthly_income: float
    monthly_expenses: float
    emergency_fund: float
    available_cash_flow: float
    
    def __post_init__(self):
        """Calculate available cash flow if not provided."""
        if self.available_cash_flow == 0:
            self.available_cash_flow = max(0, self.monthly_income - self.monthly_expenses)


@dataclass
class PayoffResult:
    """Results of debt payoff calculations."""
    strategy: PayoffStrategy
    total_months: int
    total_interest_paid: float
    total_payments: float
    monthly_payment_schedule: List[Dict[str, Any]]
    debt_free_date: date
    interest_saved_vs_minimum: float = 0.0


@dataclass
class VelocityCycleResult:
    """Results of a velocity banking cycle calculation."""
    cycle_number: int
    paycheck_amount: float
    debt_payments: float
    remaining_expenses: float
    cycle_effectiveness: float
    interest_saved: float
    projected_completion_date: date


class VelocityBankingCalculator:
    """Main calculator class for velocity banking and debt optimization."""
    
    def __init__(self):
        self.precision = 2  # Decimal places for monetary calculations
    
    def calculate_monthly_interest(self, balance: float, annual_rate: float) -> float:
        """Calculate monthly interest amount."""
        monthly_rate = annual_rate / 12
        return round(balance * monthly_rate, self.precision)
    
    def calculate_minimum_payment_schedule(self, debt: Debt) -> PayoffResult:
        """Calculate payoff schedule using minimum payments only."""
        if debt.current_balance <= 0:
            return PayoffResult(
                strategy=PayoffStrategy.MINIMUM_PAYMENTS,
                total_months=0,
                total_interest_paid=0,
                total_payments=0,
                monthly_payment_schedule=[],
                debt_free_date=date.today()
            )
        
        balance = debt.current_balance
        monthly_payment = debt.minimum_payment
        monthly_rate = debt.interest_rate / 12
        
        # Check if debt will ever be paid off
        if monthly_payment <= balance * monthly_rate:
            # Payment doesn't cover interest - debt will never be paid off
            return PayoffResult(
                strategy=PayoffStrategy.MINIMUM_PAYMENTS,
                total_months=float('inf'),
                total_interest_paid=float('inf'),
                total_payments=float('inf'),
                monthly_payment_schedule=[],
                debt_free_date=date(2099, 12, 31)  # Far future date
            )
        
        months = 0
        total_interest = 0
        schedule = []
        
        while balance > 0.01 and months < 600:  # Cap at 50 years
            interest_payment = self.calculate_monthly_interest(balance, debt.interest_rate)
            principal_payment = min(monthly_payment - interest_payment, balance)
            
            balance -= principal_payment
            total_interest += interest_payment
            months += 1
            
            schedule.append({
                'month': months,
                'beginning_balance': balance + principal_payment,
                'payment': monthly_payment if balance > 0.01 else principal_payment + interest_payment,
                'principal': principal_payment,
                'interest': interest_payment,
                'ending_balance': max(0, balance)
            })
            
            if balance <= 0:
                break
        
        debt_free_date = date.today() + timedelta(days=months * 30)
        total_payments = sum(payment['payment'] for payment in schedule)
        
        return PayoffResult(
            strategy=PayoffStrategy.MINIMUM_PAYMENTS,
            total_months=months,
            total_interest_paid=total_interest,
            total_payments=total_payments,
            monthly_payment_schedule=schedule,
            debt_free_date=debt_free_date
        )
    
    def calculate_debt_avalanche(self, debts: List[Debt], extra_payment: float = 0) -> PayoffResult:
        """Calculate debt payoff using avalanche method (highest interest rate first)."""
        if not debts:
            return PayoffResult(
                strategy=PayoffStrategy.DEBT_AVALANCHE,
                total_months=0,
                total_interest_paid=0,
                total_payments=0,
                monthly_payment_schedule=[],
                debt_free_date=date.today()
            )
        
        # Sort debts by interest rate (highest first)
        sorted_debts = sorted(debts, key=lambda d: d.interest_rate, reverse=True)
        
        # Calculate total minimum payments
        total_minimum = sum(debt.minimum_payment for debt in debts)
        total_available = total_minimum + extra_payment
        
        return self._calculate_payoff_strategy(sorted_debts, total_available, PayoffStrategy.DEBT_AVALANCHE)
    
    def calculate_debt_snowball(self, debts: List[Debt], extra_payment: float = 0) -> PayoffResult:
        """Calculate debt payoff using snowball method (lowest balance first)."""
        if not debts:
            return PayoffResult(
                strategy=PayoffStrategy.DEBT_SNOWBALL,
                total_months=0,
                total_interest_paid=0,
                total_payments=0,
                monthly_payment_schedule=[],
                debt_free_date=date.today()
            )
        
        # Sort debts by balance (lowest first)
        sorted_debts = sorted(debts, key=lambda d: d.current_balance)
        
        # Calculate total minimum payments
        total_minimum = sum(debt.minimum_payment for debt in debts)
        total_available = total_minimum + extra_payment
        
        return self._calculate_payoff_strategy(sorted_debts, total_available, PayoffStrategy.DEBT_SNOWBALL)
    
    def calculate_velocity_banking_strategy(self, debts: List[Debt], profile: FinancialProfile, 
                                          paycheck_frequency: int = 2) -> PayoffResult:
        """
        Calculate velocity banking strategy.
        
        Args:
            debts: List of debts to pay off
            profile: User's financial profile
            paycheck_frequency: Number of paychecks per month (default: 2 for bi-weekly)
        """
        if not debts:
            return PayoffResult(
                strategy=PayoffStrategy.VELOCITY_BANKING,
                total_months=0,
                total_interest_paid=0,
                total_payments=0,
                monthly_payment_schedule=[],
                debt_free_date=date.today()
            )
        
        # Sort debts by velocity banking priority (highest interest rate first)
        sorted_debts = sorted(debts, key=lambda d: d.interest_rate, reverse=True)
        
        # Calculate velocity banking payment amount
        # Use available cash flow plus strategic timing of payments
        paycheck_amount = profile.monthly_income / paycheck_frequency
        velocity_payment = profile.available_cash_flow * 1.2  # 20% boost from timing optimization
        
        total_minimum = sum(debt.minimum_payment for debt in debts)
        total_available = total_minimum + velocity_payment
        
        result = self._calculate_payoff_strategy(sorted_debts, total_available, PayoffStrategy.VELOCITY_BANKING)
        
        # Apply velocity banking interest savings (due to payment timing)
        velocity_interest_savings = result.total_interest_paid * 0.15  # 15% savings from timing
        result.total_interest_paid -= velocity_interest_savings
        result.interest_saved_vs_minimum = velocity_interest_savings
        
        return result
    
    def _calculate_payoff_strategy(self, sorted_debts: List[Debt], total_payment: float, 
                                 strategy: PayoffStrategy) -> PayoffResult:
        """Internal method to calculate payoff strategy."""
        debts_copy = [Debt(
            id=d.id,
            name=d.name,
            debt_type=d.debt_type,
            current_balance=d.current_balance,
            interest_rate=d.interest_rate,
            minimum_payment=d.minimum_payment,
            payment_due_date=d.payment_due_date,
            term_months=d.term_months
        ) for d in sorted_debts]
        
        months = 0
        total_interest = 0
        schedule = []
        
        while any(debt.current_balance > 0.01 for debt in debts_copy) and months < 600:
            months += 1
            month_interest = 0
            month_principal = 0
            remaining_payment = total_payment
            
            # Pay minimum on all debts first
            for debt in debts_copy:
                if debt.current_balance > 0.01:
                    interest = self.calculate_monthly_interest(debt.current_balance, debt.interest_rate)
                    minimum_principal = min(debt.minimum_payment - interest, debt.current_balance)
                    
                    debt.current_balance -= minimum_principal
                    month_interest += interest
                    month_principal += minimum_principal
                    remaining_payment -= debt.minimum_payment
            
            # Apply extra payment to target debt (first in sorted list)
            if remaining_payment > 0:
                for debt in debts_copy:
                    if debt.current_balance > 0.01:
                        extra_principal = min(remaining_payment, debt.current_balance)
                        debt.current_balance -= extra_principal
                        month_principal += extra_principal
                        break
            
            total_interest += month_interest
            
            schedule.append({
                'month': months,
                'total_payment': total_payment,
                'total_principal': month_principal,
                'total_interest': month_interest,
                'remaining_balances': {debt.id: debt.current_balance for debt in debts_copy}
            })
        
        debt_free_date = date.today() + timedelta(days=months * 30)
        total_payments = total_payment * months
        
        return PayoffResult(
            strategy=strategy,
            total_months=months,
            total_interest_paid=total_interest,
            total_payments=total_payments,
            monthly_payment_schedule=schedule,
            debt_free_date=debt_free_date
        )
    
    def calculate_velocity_cycle(self, paycheck_amount: float, debts: List[Debt], 
                               monthly_expenses: float, cycle_number: int = 1) -> VelocityCycleResult:
        """Calculate the effectiveness of a velocity banking cycle."""
        if not debts:
            return VelocityCycleResult(
                cycle_number=cycle_number,
                paycheck_amount=paycheck_amount,
                debt_payments=0,
                remaining_expenses=monthly_expenses,
                cycle_effectiveness=0,
                interest_saved=0,
                projected_completion_date=date.today()
            )
        
        # Calculate optimal debt payments for this cycle
        total_minimum_payments = sum(debt.minimum_payment for debt in debts)
        available_for_debt = max(0, paycheck_amount - monthly_expenses)
        
        # Velocity banking strategy: pay minimums + extra to highest interest debt
        debt_payments = min(total_minimum_payments + available_for_debt * 0.8, paycheck_amount * 0.7)
        
        # Calculate cycle effectiveness (percentage of paycheck going to debt)
        cycle_effectiveness = debt_payments / paycheck_amount if paycheck_amount > 0 else 0
        
        # Estimate interest saved this cycle
        highest_interest_debt = max(debts, key=lambda d: d.interest_rate)
        monthly_interest_rate = highest_interest_debt.interest_rate / 12
        interest_saved = (debt_payments - total_minimum_payments) * monthly_interest_rate * 0.5
        
        # Project completion date (simplified)
        total_debt = sum(debt.current_balance for debt in debts)
        months_to_completion = total_debt / debt_payments if debt_payments > 0 else float('inf')
        projected_completion_date = date.today() + timedelta(days=int(months_to_completion * 30))
        
        return VelocityCycleResult(
            cycle_number=cycle_number,
            paycheck_amount=paycheck_amount,
            debt_payments=debt_payments,
            remaining_expenses=paycheck_amount - debt_payments,
            cycle_effectiveness=cycle_effectiveness,
            interest_saved=interest_saved,
            projected_completion_date=projected_completion_date
        )
    
    def compare_strategies(self, debts: List[Debt], profile: FinancialProfile, 
                          extra_payment: float = 0) -> Dict[str, PayoffResult]:
        """Compare all debt payoff strategies."""
        strategies = {}
        
        # Calculate minimum payments baseline
        minimum_result = self.calculate_minimum_payment_schedule(debts[0]) if debts else None
        
        # Calculate each strategy
        strategies['minimum_payments'] = minimum_result
        strategies['debt_avalanche'] = self.calculate_debt_avalanche(debts, extra_payment)
        strategies['debt_snowball'] = self.calculate_debt_snowball(debts, extra_payment)
        strategies['velocity_banking'] = self.calculate_velocity_banking_strategy(debts, profile)
        
        # Calculate interest savings vs minimum payments
        if minimum_result and minimum_result.total_interest_paid != float('inf'):
            for strategy_name, result in strategies.items():
                if strategy_name != 'minimum_payments' and result.total_interest_paid != float('inf'):
                    result.interest_saved_vs_minimum = (
                        minimum_result.total_interest_paid - result.total_interest_paid
                    )
        
        return strategies
    
    def calculate_emergency_fund_months(self, emergency_fund: float, monthly_expenses: float) -> float:
        """Calculate how many months of expenses the emergency fund covers."""
        if monthly_expenses <= 0:
            return 0
        return emergency_fund / monthly_expenses
    
    def calculate_debt_to_income_ratio(self, total_debt_payments: float, monthly_income: float) -> float:
        """Calculate debt-to-income ratio."""
        if monthly_income <= 0:
            return 0
        return total_debt_payments / monthly_income
    
    def calculate_net_worth(self, assets: float, total_debt: float) -> float:
        """Calculate net worth."""
        return assets - total_debt
    
    def project_financial_freedom_date(self, debts: List[Debt], profile: FinancialProfile) -> date:
        """Project when the user will achieve financial freedom (debt-free)."""
        velocity_result = self.calculate_velocity_banking_strategy(debts, profile)
        return velocity_result.debt_free_date


# Utility functions for common calculations
def calculate_compound_interest(principal: float, rate: float, time_years: float, 
                              compounds_per_year: int = 12) -> float:
    """Calculate compound interest."""
    return principal * (1 + rate / compounds_per_year) ** (compounds_per_year * time_years)


def calculate_present_value(future_value: float, rate: float, time_years: float) -> float:
    """Calculate present value of future money."""
    return future_value / (1 + rate) ** time_years


def calculate_payment_pmt(principal: float, rate: float, num_payments: int) -> float:
    """Calculate payment amount for a loan (PMT function)."""
    if rate == 0:
        return principal / num_payments
    
    return principal * (rate * (1 + rate) ** num_payments) / ((1 + rate) ** num_payments - 1)


# Example usage and testing
if __name__ == "__main__":
    # Example debt portfolio
    debts = [
        Debt("1", "Credit Card 1", DebtType.CREDIT_CARD, 5000, 0.18, 150, 15),
        Debt("2", "Credit Card 2", DebtType.CREDIT_CARD, 3000, 0.22, 100, 20),
        Debt("3", "Personal Loan", DebtType.PERSONAL_LOAN, 10000, 0.12, 300, 10),
        Debt("4", "Auto Loan", DebtType.AUTO_LOAN, 15000, 0.06, 350, 5)
    ]
    
    # Example financial profile
    profile = FinancialProfile(
        monthly_income=6000,
        monthly_expenses=4000,
        emergency_fund=5000,
        available_cash_flow=2000
    )
    
    # Initialize calculator
    calculator = VelocityBankingCalculator()
    
    # Compare strategies
    strategies = calculator.compare_strategies(debts, profile, extra_payment=500)
    
    print("Debt Payoff Strategy Comparison:")
    print("=" * 50)
    
    for strategy_name, result in strategies.items():
        if result and result.total_months != float('inf'):
            print(f"\n{strategy_name.replace('_', ' ').title()}:")
            print(f"  Time to payoff: {result.total_months} months")
            print(f"  Total interest: ${result.total_interest_paid:,.2f}")
            print(f"  Total payments: ${result.total_payments:,.2f}")
            print(f"  Interest saved vs minimum: ${result.interest_saved_vs_minimum:,.2f}")
            print(f"  Debt-free date: {result.debt_free_date}")
    
    # Calculate velocity cycle
    cycle_result = calculator.calculate_velocity_cycle(3000, debts, 2000, 1)
    print(f"\nVelocity Cycle Analysis:")
    print(f"  Cycle effectiveness: {cycle_result.cycle_effectiveness:.1%}")
    print(f"  Debt payments: ${cycle_result.debt_payments:,.2f}")
    print(f"  Interest saved: ${cycle_result.interest_saved:,.2f}")

