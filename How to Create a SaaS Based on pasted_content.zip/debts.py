from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models import db, User, Debt

debts_bp = Blueprint('debts', __name__)

@debts_bp.route('/', methods=['GET'])
@jwt_required()
def get_debts():
    """Get all user's debts."""
    try:
        current_user_id = get_jwt_identity()
        debt_type = request.args.get('type')
        active_only = request.args.get('active', 'true').lower() == 'true'
        
        debts = Debt.get_user_debts(current_user_id, active_only, debt_type)
        total_balance = Debt.calculate_total_debt(current_user_id, active_only)
        total_minimum_payment = Debt.calculate_total_minimum_payments(current_user_id, active_only)
        
        return jsonify({
            'success': True,
            'data': {
                'debts': [debt.to_dict() for debt in debts],
                'total_count': len(debts),
                'total_balance': float(total_balance),
                'total_minimum_payment': float(total_minimum_payment)
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred retrieving debts'
            }
        }), 500

@debts_bp.route('/', methods=['POST'])
@jwt_required()
def create_debt():
    """Add a new debt."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        debt = Debt(
            user_id=current_user_id,
            debt_name=data['debt_name'],
            debt_type=data['debt_type'],
            original_balance=data['original_balance'],
            current_balance=data['current_balance'],
            interest_rate=data['interest_rate'],
            minimum_payment=data['minimum_payment'],
            payment_due_date=data.get('payment_due_date'),
            term_months=data.get('term_months'),
            notes=data.get('notes')
        )
        
        db.session.add(debt)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Debt added successfully',
            'data': debt.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred adding debt'
            }
        }), 500

