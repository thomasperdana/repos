# Database Schema Design - Velocity Banking SaaS

## Overview

This document outlines the complete database schema for the Velocity Banking SaaS application. The schema is designed to support user management, financial data tracking, debt optimization, velocity banking cycles, and comprehensive financial analytics.

## Database Technology

**Primary Database:** PostgreSQL 15+
- Excellent support for complex queries and JSON data types
- Robust transaction handling for financial data
- Advanced indexing capabilities for performance
- Strong consistency and ACID compliance

**Caching Layer:** Redis 7+
- Session management and user authentication tokens
- Caching of frequently accessed financial calculations
- Real-time data for dashboard updates
- Background job queue management

## Core Tables

### 1. Users Table

The users table stores fundamental user account information and authentication credentials.

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    verification_token VARCHAR(255),
    password_reset_token VARCHAR(255),
    password_reset_expires TIMESTAMP WITH TIME ZONE,
    subscription_tier VARCHAR(20) DEFAULT 'free',
    subscription_expires TIMESTAMP WITH TIME ZONE,
    timezone VARCHAR(50) DEFAULT 'UTC',
    preferences JSONB DEFAULT '{}'
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_verification_token ON users(verification_token);
CREATE INDEX idx_users_password_reset_token ON users(password_reset_token);
```

### 2. Financial Profiles Table

Stores comprehensive financial information for each user including income, employment, and financial goals.

```sql
CREATE TABLE financial_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    annual_income DECIMAL(12,2),
    monthly_income DECIMAL(12,2),
    employment_status VARCHAR(50),
    employer_name VARCHAR(200),
    employment_start_date DATE,
    financial_goals TEXT,
    risk_tolerance VARCHAR(20) DEFAULT 'moderate',
    emergency_fund_target DECIMAL(12,2),
    current_emergency_fund DECIMAL(12,2),
    net_worth DECIMAL(12,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_financial_profiles_user_id ON financial_profiles(user_id);
```

### 3. Bank Accounts Table

Manages banking relationships and account information for secure integration.

```sql
CREATE TABLE bank_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    account_name VARCHAR(200) NOT NULL,
    account_type VARCHAR(50) NOT NULL, -- checking, savings, credit_line, credit_card
    institution_name VARCHAR(200),
    account_number_encrypted TEXT, -- Encrypted account number
    routing_number_encrypted TEXT, -- Encrypted routing number
    current_balance DECIMAL(12,2) DEFAULT 0.00,
    available_balance DECIMAL(12,2) DEFAULT 0.00,
    credit_limit DECIMAL(12,2), -- For credit accounts
    interest_rate DECIMAL(5,4), -- Annual percentage rate
    minimum_payment DECIMAL(10,2), -- For credit accounts
    payment_due_date INTEGER, -- Day of month (1-31)
    is_primary BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    plaid_account_id VARCHAR(255), -- External integration ID
    plaid_access_token_encrypted TEXT, -- Encrypted access token
    last_sync TIMESTAMP WITH TIME ZONE,
    sync_status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bank_accounts_user_id ON bank_accounts(user_id);
CREATE INDEX idx_bank_accounts_plaid_id ON bank_accounts(plaid_account_id);
CREATE INDEX idx_bank_accounts_type ON bank_accounts(account_type);
```

### 4. Debts Table

Comprehensive debt tracking including all types of debt obligations.

```sql
CREATE TABLE debts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bank_account_id UUID REFERENCES bank_accounts(id) ON DELETE SET NULL,
    debt_name VARCHAR(200) NOT NULL,
    debt_type VARCHAR(50) NOT NULL, -- credit_card, personal_loan, mortgage, auto_loan, student_loan, other
    original_balance DECIMAL(12,2) NOT NULL,
    current_balance DECIMAL(12,2) NOT NULL,
    interest_rate DECIMAL(5,4) NOT NULL,
    minimum_payment DECIMAL(10,2) NOT NULL,
    payment_due_date INTEGER, -- Day of month (1-31)
    term_months INTEGER, -- Original loan term
    remaining_months INTEGER, -- Calculated remaining months
    is_active BOOLEAN DEFAULT true,
    priority_order INTEGER DEFAULT 0, -- User-defined priority
    optimization_order INTEGER, -- System-calculated optimal order
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    payoff_target_date DATE,
    notes TEXT
);

CREATE INDEX idx_debts_user_id ON debts(user_id);
CREATE INDEX idx_debts_bank_account_id ON debts(bank_account_id);
CREATE INDEX idx_debts_type ON debts(debt_type);
CREATE INDEX idx_debts_priority ON debts(priority_order);
```

### 5. Transactions Table

Detailed transaction history for all financial activities.

```sql
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bank_account_id UUID REFERENCES bank_accounts(id) ON DELETE SET NULL,
    debt_id UUID REFERENCES debts(id) ON DELETE SET NULL,
    velocity_cycle_id UUID REFERENCES velocity_cycles(id) ON DELETE SET NULL,
    transaction_date DATE NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    transaction_type VARCHAR(50) NOT NULL, -- income, expense, debt_payment, transfer, interest
    category VARCHAR(100),
    subcategory VARCHAR(100),
    description TEXT,
    merchant_name VARCHAR(200),
    is_recurring BOOLEAN DEFAULT false,
    is_automated BOOLEAN DEFAULT false,
    plaid_transaction_id VARCHAR(255), -- External integration ID
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_bank_account_id ON transactions(bank_account_id);
CREATE INDEX idx_transactions_debt_id ON transactions(debt_id);
CREATE INDEX idx_transactions_date ON transactions(transaction_date);
CREATE INDEX idx_transactions_type ON transactions(transaction_type);
CREATE INDEX idx_transactions_plaid_id ON transactions(plaid_transaction_id);
```

### 6. Velocity Cycles Table

Tracks individual velocity banking cycles and their effectiveness.

```sql
CREATE TABLE velocity_cycles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    cycle_number INTEGER NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    paycheck_amount DECIMAL(12,2) NOT NULL,
    total_debt_payments DECIMAL(12,2) DEFAULT 0.00,
    total_expenses DECIMAL(12,2) DEFAULT 0.00,
    interest_saved DECIMAL(10,2) DEFAULT 0.00,
    cycle_effectiveness DECIMAL(5,4), -- Percentage effectiveness
    status VARCHAR(20) DEFAULT 'active', -- active, completed, cancelled
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_velocity_cycles_user_id ON velocity_cycles(user_id);
CREATE INDEX idx_velocity_cycles_status ON velocity_cycles(status);
CREATE INDEX idx_velocity_cycles_date ON velocity_cycles(start_date);
```

### 7. Debt Payments Table

Detailed tracking of all debt payments within velocity cycles.

```sql
CREATE TABLE debt_payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    debt_id UUID NOT NULL REFERENCES debts(id) ON DELETE CASCADE,
    velocity_cycle_id UUID REFERENCES velocity_cycles(id) ON DELETE SET NULL,
    payment_date DATE NOT NULL,
    payment_amount DECIMAL(12,2) NOT NULL,
    principal_amount DECIMAL(12,2) NOT NULL,
    interest_amount DECIMAL(12,2) NOT NULL,
    remaining_balance DECIMAL(12,2) NOT NULL,
    payment_type VARCHAR(50) DEFAULT 'regular', -- regular, extra, minimum, payoff
    is_automated BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_debt_payments_user_id ON debt_payments(user_id);
CREATE INDEX idx_debt_payments_debt_id ON debt_payments(debt_id);
CREATE INDEX idx_debt_payments_cycle_id ON debt_payments(velocity_cycle_id);
CREATE INDEX idx_debt_payments_date ON debt_payments(payment_date);
```

### 8. Financial Scenarios Table

Stores scenario modeling data for different financial strategies.

```sql
CREATE TABLE financial_scenarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    scenario_name VARCHAR(200) NOT NULL,
    scenario_type VARCHAR(50) NOT NULL, -- velocity_banking, debt_avalanche, debt_snowball, custom
    parameters JSONB NOT NULL, -- Flexible parameter storage
    projected_payoff_date DATE,
    projected_interest_saved DECIMAL(12,2),
    projected_total_payments DECIMAL(12,2),
    monthly_cash_flow DECIMAL(12,2),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_financial_scenarios_user_id ON financial_scenarios(user_id);
CREATE INDEX idx_financial_scenarios_type ON financial_scenarios(scenario_type);
```

### 9. User Sessions Table

Manages user authentication sessions and security.

```sql
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    refresh_token VARCHAR(255) UNIQUE NOT NULL,
    ip_address INET,
    user_agent TEXT,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_accessed TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true
);

CREATE INDEX idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_user_sessions_refresh_token ON user_sessions(refresh_token);
CREATE INDEX idx_user_sessions_expires ON user_sessions(expires_at);
```

### 10. Audit Logs Table

Comprehensive audit trail for security and compliance.

```sql
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_resource ON audit_logs(resource_type, resource_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);
```

## Relationships and Constraints

### Primary Relationships

1. **Users → Financial Profiles**: One-to-one relationship storing detailed financial information
2. **Users → Bank Accounts**: One-to-many relationship for multiple banking relationships
3. **Users → Debts**: One-to-many relationship for comprehensive debt tracking
4. **Users → Velocity Cycles**: One-to-many relationship tracking banking cycles
5. **Debts → Debt Payments**: One-to-many relationship for payment history
6. **Velocity Cycles → Transactions**: One-to-many relationship linking transactions to cycles

### Data Integrity Constraints

```sql
-- Ensure positive balances and amounts
ALTER TABLE debts ADD CONSTRAINT chk_debts_positive_balance 
    CHECK (current_balance >= 0 AND original_balance > 0);

ALTER TABLE bank_accounts ADD CONSTRAINT chk_bank_accounts_credit_limit 
    CHECK (credit_limit IS NULL OR credit_limit >= 0);

-- Ensure valid interest rates
ALTER TABLE debts ADD CONSTRAINT chk_debts_interest_rate 
    CHECK (interest_rate >= 0 AND interest_rate <= 1);

-- Ensure valid payment due dates
ALTER TABLE debts ADD CONSTRAINT chk_debts_payment_due_date 
    CHECK (payment_due_date >= 1 AND payment_due_date <= 31);

-- Ensure subscription tiers are valid
ALTER TABLE users ADD CONSTRAINT chk_users_subscription_tier 
    CHECK (subscription_tier IN ('free', 'pro', 'coach'));
```

## Indexes for Performance

### Query Optimization Indexes

```sql
-- Composite indexes for common queries
CREATE INDEX idx_transactions_user_date ON transactions(user_id, transaction_date DESC);
CREATE INDEX idx_debts_user_active ON debts(user_id, is_active);
CREATE INDEX idx_bank_accounts_user_type ON bank_accounts(user_id, account_type);
CREATE INDEX idx_velocity_cycles_user_status ON velocity_cycles(user_id, status);

-- Partial indexes for active records
CREATE INDEX idx_debts_active ON debts(user_id) WHERE is_active = true;
CREATE INDEX idx_bank_accounts_active ON bank_accounts(user_id) WHERE is_active = true;
CREATE INDEX idx_sessions_active ON user_sessions(user_id) WHERE is_active = true;
```

## Security Considerations

### Data Encryption

Sensitive financial data is encrypted at the application level before storage:

- Account numbers and routing numbers
- Banking access tokens
- Social security numbers (if collected)
- Credit card numbers (if stored)

### Access Control

Row-level security ensures users can only access their own data:

```sql
-- Enable row-level security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE debts ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Create policies for user data access
CREATE POLICY user_data_policy ON users FOR ALL TO app_user USING (id = current_user_id());
CREATE POLICY financial_profiles_policy ON financial_profiles FOR ALL TO app_user USING (user_id = current_user_id());
CREATE POLICY bank_accounts_policy ON bank_accounts FOR ALL TO app_user USING (user_id = current_user_id());
CREATE POLICY debts_policy ON debts FOR ALL TO app_user USING (user_id = current_user_id());
CREATE POLICY transactions_policy ON transactions FOR ALL TO app_user USING (user_id = current_user_id());
```

## Backup and Recovery

### Backup Strategy

1. **Daily automated backups** of the entire database
2. **Point-in-time recovery** capability for the last 30 days
3. **Cross-region replication** for disaster recovery
4. **Encrypted backup storage** with secure key management

### Data Retention

- **Transaction data**: Retained indefinitely for historical analysis
- **Session data**: Purged after 90 days of inactivity
- **Audit logs**: Retained for 7 years for compliance
- **Deleted user data**: Purged after 30-day grace period

## Migration Strategy

### Initial Migration

```sql
-- Create database and enable extensions
CREATE DATABASE velocity_banking;
\c velocity_banking;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create custom functions for user context
CREATE OR REPLACE FUNCTION current_user_id() RETURNS UUID AS $$
BEGIN
    RETURN current_setting('app.current_user_id', true)::UUID;
END;
$$ LANGUAGE plpgsql;
```

### Version Control

Database migrations are managed through Flask-Migrate with versioned migration files:

1. **Schema changes** tracked in migration files
2. **Data migrations** for structural changes
3. **Rollback capabilities** for safe deployments
4. **Testing migrations** in staging environment

This comprehensive database schema provides the foundation for a robust, scalable, and secure velocity banking application that can handle complex financial calculations while maintaining data integrity and user privacy.

