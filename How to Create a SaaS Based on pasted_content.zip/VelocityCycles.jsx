import React from 'react'
import { Zap, Plus } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const VelocityCycles = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Velocity Cycles</h1>
          <p className="text-gray-600">Track your velocity banking cycles and performance</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Start New Cycle
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Zap className="mr-2 h-5 w-5" />
            Your Velocity Cycles
          </CardTitle>
          <CardDescription>
            Monitor your velocity banking cycle history and effectiveness
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <Zap className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">No cycles started yet</h3>
            <p className="mt-2 text-gray-600">Begin your velocity banking journey</p>
            <Button className="mt-4">
              <Plus className="mr-2 h-4 w-4" />
              Start Your First Cycle
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default VelocityCycles

