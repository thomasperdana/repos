from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from src.models import db, Transaction

transactions_bp = Blueprint('transactions', __name__)

@transactions_bp.route('/', methods=['GET'])
@jwt_required()
def get_transactions():
    """Get user's transaction history."""
    try:
        current_user_id = get_jwt_identity()
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        transaction_type = request.args.get('type')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
        
        # Parse dates if provided
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d').date() if start_date else None
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d').date() if end_date else None
        
        transactions = Transaction.get_user_transactions(
            current_user_id, start_date_obj, end_date_obj, transaction_type, limit, offset
        )
        
        summary = Transaction.calculate_cash_flow_summary(
            current_user_id, start_date_obj, end_date_obj
        )
        
        return jsonify({
            'success': True,
            'data': {
                'transactions': [transaction.to_dict() for transaction in transactions],
                'total_count': len(transactions),
                'summary': summary
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred retrieving transactions'
            }
        }), 500

@transactions_bp.route('/', methods=['POST'])
@jwt_required()
def create_transaction():
    """Add a new transaction."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        transaction = Transaction(
            user_id=current_user_id,
            transaction_date=datetime.strptime(data['transaction_date'], '%Y-%m-%d').date(),
            amount=data['amount'],
            transaction_type=data['transaction_type'],
            category=data.get('category'),
            description=data.get('description'),
            merchant_name=data.get('merchant_name'),
            bank_account_id=data.get('bank_account_id'),
            debt_id=data.get('debt_id')
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Transaction added successfully',
            'data': transaction.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred adding transaction'
            }
        }), 500

