import uuid
from datetime import datetime, timezone, date
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Numeric, Boolean, Date
from . import db

class FinancialScenario(db.Model):
    __tablename__ = 'financial_scenarios'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    
    # Scenario information
    scenario_name = db.Column(String(200), nullable=False)
    scenario_type = db.Column(String(50), nullable=False)  # velocity_banking, debt_avalanche, debt_snowball, custom
    parameters = db.Column(db.JSON, nullable=False)  # Flexible parameter storage
    
    # Projected results
    projected_payoff_date = db.Column(Date)
    projected_interest_saved = db.Column(Numeric(12, 2))
    projected_total_payments = db.Column(Numeric(12, 2))
    monthly_cash_flow = db.Column(Numeric(12, 2))
    
    # Status
    is_active = db.Column(Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    def __repr__(self):
        return f'<FinancialScenario {self.scenario_name}>'
    
    def to_dict(self):
        """Convert financial scenario to dictionary."""
        return {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'scenario_name': self.scenario_name,
            'scenario_type': self.scenario_type,
            'parameters': self.parameters,
            'projected_payoff_date': self.projected_payoff_date.isoformat() if self.projected_payoff_date else None,
            'projected_interest_saved': float(self.projected_interest_saved) if self.projected_interest_saved else None,
            'projected_total_payments': float(self.projected_total_payments) if self.projected_total_payments else None,
            'monthly_cash_flow': float(self.monthly_cash_flow) if self.monthly_cash_flow else None,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

