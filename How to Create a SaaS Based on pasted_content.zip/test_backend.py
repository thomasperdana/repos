"""
Simple Backend Test Script

This script tests the core functionality of the velocity banking calculator
without the Flask app complexity.
"""

import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.utils.velocity_banking_calculator import (
    VelocityBankingCalculator,
    Debt,
    FinancialProfile,
    DebtType
)

def test_velocity_banking_calculator():
    """Test the velocity banking calculator functionality."""
    print("Testing Velocity Banking Calculator")
    print("=" * 40)
    
    # Create test debts
    debts = [
        Debt("1", "Credit Card 1", DebtType.CREDIT_CARD, 5000, 0.18, 150, 15),
        Debt("2", "Credit Card 2", DebtType.CREDIT_CARD, 3000, 0.22, 100, 20),
        Debt("3", "Personal Loan", DebtType.PERSONAL_LOAN, 10000, 0.12, 300, 10),
        Debt("4", "Auto Loan", DebtType.AUTO_LOAN, 15000, 0.06, 350, 5)
    ]
    
    # Create test financial profile
    profile = FinancialProfile(
        monthly_income=6000,
        monthly_expenses=4000,
        emergency_fund=5000,
        available_cash_flow=2000
    )
    
    # Initialize calculator
    calculator = VelocityBankingCalculator()
    
    # Test velocity banking strategy
    print("Testing Velocity Banking Strategy...")
    result = calculator.calculate_velocity_banking_strategy(debts, profile)
    
    print(f"✓ Total months to payoff: {result.total_months}")
    print(f"✓ Total interest paid: ${result.total_interest_paid:,.2f}")
    print(f"✓ Interest saved: ${result.interest_saved_vs_minimum:,.2f}")
    print(f"✓ Debt-free date: {result.debt_free_date}")
    
    # Test debt comparison
    print("\nTesting Strategy Comparison...")
    strategies = calculator.compare_strategies(debts, profile, extra_payment=500)
    
    for strategy_name, strategy_result in strategies.items():
        if strategy_result and strategy_result.total_months != float('inf'):
            print(f"✓ {strategy_name}: {strategy_result.total_months} months, "
                  f"${strategy_result.total_interest_paid:,.2f} interest")
    
    # Test velocity cycle
    print("\nTesting Velocity Cycle...")
    cycle_result = calculator.calculate_velocity_cycle(3000, debts, 2000, 1)
    
    print(f"✓ Cycle effectiveness: {cycle_result.cycle_effectiveness:.1%}")
    print(f"✓ Debt payments: ${cycle_result.debt_payments:,.2f}")
    print(f"✓ Interest saved: ${cycle_result.interest_saved:,.2f}")
    
    print("\n" + "=" * 40)
    print("✅ All tests passed! Backend calculations are working correctly.")
    
    return True

def test_database_connection():
    """Test database connection and sample data."""
    print("\nTesting Database Connection")
    print("=" * 40)
    
    import sqlite3
    
    db_path = 'src/velocity_banking.db'
    
    if not os.path.exists(db_path):
        print("❌ Database file not found")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Test users table
        cursor.execute("SELECT COUNT(*) FROM users")
        user_count = cursor.fetchone()[0]
        print(f"✓ Users in database: {user_count}")
        
        # Test debts table
        cursor.execute("SELECT COUNT(*) FROM debts")
        debt_count = cursor.fetchone()[0]
        print(f"✓ Debts in database: {debt_count}")
        
        # Test sample user
        cursor.execute("SELECT email, first_name, last_name FROM users WHERE email = ?", 
                      ('demo@velocitybanking.com',))
        user = cursor.fetchone()
        
        if user:
            print(f"✓ Sample user found: {user[1]} {user[2]} ({user[0]})")
        else:
            print("❌ Sample user not found")
            return False
        
        conn.close()
        
        print("✅ Database connection and data verified!")
        return True
        
    except Exception as e:
        print(f"❌ Database error: {str(e)}")
        return False

if __name__ == '__main__':
    print("Velocity Banking SaaS - Backend Testing")
    print("=" * 50)
    
    # Test calculator
    calc_success = test_velocity_banking_calculator()
    
    # Test database
    db_success = test_database_connection()
    
    print("\n" + "=" * 50)
    if calc_success and db_success:
        print("🎉 All backend tests passed! The system is ready for integration.")
    else:
        print("❌ Some tests failed. Please check the errors above.")

