from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

try:
    from services.calculation_service import calculation_service
except ImportError:
    from src.services.calculation_service import calculation_service

calculations_bp = Blueprint('calculations', __name__)

@calculations_bp.route('/debt-optimization', methods=['POST'])
@jwt_required()
def calculate_debt_optimization():
    """Calculate optimal debt payoff strategy."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json() or {}
        
        strategy = data.get('strategy', 'velocity_banking')
        extra_payment = float(data.get('extra_payment_amount', 0))
        
        result = calculation_service.calculate_debt_optimization(
            current_user_id, strategy, extra_payment
        )
        
        if 'error' in result:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'CALCULATION_ERROR',
                    'message': result['error']
                }
            }), 400
        
        return jsonify({
            'success': True,
            'data': result
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred calculating debt optimization'
            }
        }), 500

@calculations_bp.route('/scenario-comparison', methods=['POST'])
@jwt_required()
def compare_scenarios():
    """Compare different financial scenarios."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json() or {}
        
        extra_payment = float(data.get('extra_payment_amount', 0))
        
        result = calculation_service.compare_debt_strategies(current_user_id, extra_payment)
        
        if 'error' in result:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'CALCULATION_ERROR',
                    'message': result['error']
                }
            }), 400
        
        return jsonify({
            'success': True,
            'data': result
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred comparing scenarios'
            }
        }), 500

@calculations_bp.route('/velocity-cycle', methods=['POST'])
@jwt_required()
def calculate_velocity_cycle():
    """Calculate velocity banking cycle effectiveness."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json() or {}
        
        paycheck_amount = float(data.get('paycheck_amount', 0))
        cycle_number = int(data.get('cycle_number', 1))
        
        if paycheck_amount <= 0:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'VALIDATION_ERROR',
                    'message': 'Paycheck amount must be greater than 0'
                }
            }), 400
        
        result = calculation_service.calculate_velocity_cycle_effectiveness(
            current_user_id, paycheck_amount, cycle_number
        )
        
        if 'error' in result:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'CALCULATION_ERROR',
                    'message': result['error']
                }
            }), 400
        
        return jsonify({
            'success': True,
            'data': result
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred calculating velocity cycle'
            }
        }), 500

@calculations_bp.route('/financial-metrics', methods=['GET'])
@jwt_required()
def get_financial_metrics():
    """Get comprehensive financial metrics for the user."""
    try:
        current_user_id = get_jwt_identity()
        
        result = calculation_service.calculate_financial_metrics(current_user_id)
        
        if 'error' in result:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'CALCULATION_ERROR',
                    'message': result['error']
                }
            }), 400
        
        return jsonify({
            'success': True,
            'data': result
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred calculating financial metrics'
            }
        }), 500

@calculations_bp.route('/extra-payment-simulation', methods=['POST'])
@jwt_required()
def simulate_extra_payments():
    """Simulate the impact of different extra payment amounts."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json() or {}
        
        # Default simulation amounts
        amounts = data.get('amounts', [0, 100, 250, 500, 1000])
        
        result = calculation_service.simulate_extra_payment_impact(current_user_id, amounts)
        
        if 'error' in result:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'CALCULATION_ERROR',
                    'message': result['error']
                }
            }), 400
        
        return jsonify({
            'success': True,
            'data': result
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred simulating extra payments'
            }
        }), 500

