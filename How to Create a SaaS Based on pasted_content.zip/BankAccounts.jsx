import React from 'react'
import { Building2, Plus } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const BankAccounts = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Bank Accounts</h1>
          <p className="text-gray-600">Connect and manage your bank accounts</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Account
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Building2 className="mr-2 h-5 w-5" />
            Connected Accounts
          </CardTitle>
          <CardDescription>
            Manage your connected bank accounts for velocity banking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <Building2 className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">No accounts connected</h3>
            <p className="mt-2 text-gray-600">Connect your bank accounts to get started</p>
            <Button className="mt-4">
              <Plus className="mr-2 h-4 w-4" />
              Connect Your First Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default BankAccounts

