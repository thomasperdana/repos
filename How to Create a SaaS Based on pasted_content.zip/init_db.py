"""
Database Initialization Script

This script initializes the database with all required tables and sample data.
"""

import os
import sys
from datetime import datetime, timezone, date
from decimal import Decimal

# Add the src directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from main import create_app
from models import db, User, FinancialProfile, BankAccount, Debt, Transaction, VelocityCycle


def create_tables():
    """Create all database tables."""
    print("Creating database tables...")
    db.create_all()
    print("✓ Database tables created successfully")


def create_sample_user():
    """Create a sample user for testing."""
    print("Creating sample user...")
    
    # Check if sample user already exists
    existing_user = User.find_by_email('demo@velocitybanking.com')
    if existing_user:
        print("✓ Sample user already exists")
        return existing_user
    
    # Create sample user
    user = User(
        email='demo@velocitybanking.com',
        first_name='Demo',
        last_name='User',
        phone='+1 (555) 123-4567',
        date_of_birth=date(1990, 1, 1),
        subscription_tier='premium',
        is_email_verified=True
    )
    user.set_password('DemoPassword123!')
    
    db.session.add(user)
    db.session.commit()
    
    print("✓ Sample user created: demo@velocitybanking.com / DemoPassword123!")
    return user


def create_sample_financial_profile(user):
    """Create a sample financial profile."""
    print("Creating sample financial profile...")
    
    if user.financial_profile:
        print("✓ Financial profile already exists")
        return user.financial_profile
    
    profile = FinancialProfile(
        user_id=user.id,
        annual_income=Decimal('72000.00'),
        monthly_income=Decimal('6000.00'),
        employment_status='full_time',
        employer_name='Tech Company Inc.',
        employment_start_date=date(2020, 1, 15),
        financial_goals=['debt_freedom', 'emergency_fund', 'retirement'],
        risk_tolerance='moderate',
        emergency_fund_target=Decimal('15000.00'),
        current_emergency_fund=Decimal('4000.00'),
        net_worth=Decimal('45000.00')
    )
    
    db.session.add(profile)
    db.session.commit()
    
    print("✓ Sample financial profile created")
    return profile


def create_sample_bank_accounts(user):
    """Create sample bank accounts."""
    print("Creating sample bank accounts...")
    
    existing_accounts = BankAccount.get_user_accounts(user.id)
    if existing_accounts:
        print("✓ Bank accounts already exist")
        return existing_accounts
    
    accounts = [
        BankAccount(
            user_id=user.id,
            account_name='Primary Checking',
            account_type='checking',
            institution_name='First National Bank',
            current_balance=Decimal('2500.00'),
            is_primary=True
        ),
        BankAccount(
            user_id=user.id,
            account_name='Savings Account',
            account_type='savings',
            institution_name='First National Bank',
            current_balance=Decimal('4000.00'),
            interest_rate=Decimal('0.015')
        ),
        BankAccount(
            user_id=user.id,
            account_name='Credit Card',
            account_type='credit',
            institution_name='Chase Bank',
            current_balance=Decimal('-5000.00'),
            credit_limit=Decimal('10000.00'),
            interest_rate=Decimal('0.18')
        )
    ]
    
    for account in accounts:
        db.session.add(account)
    
    db.session.commit()
    
    print("✓ Sample bank accounts created")
    return accounts


def create_sample_debts(user):
    """Create sample debts."""
    print("Creating sample debts...")
    
    existing_debts = Debt.get_user_debts(user.id)
    if existing_debts:
        print("✓ Debts already exist")
        return existing_debts
    
    debts = [
        Debt(
            user_id=user.id,
            debt_name='Chase Freedom Credit Card',
            debt_type='credit_card',
            original_balance=Decimal('5000.00'),
            current_balance=Decimal('5000.00'),
            interest_rate=Decimal('0.18'),
            minimum_payment=Decimal('150.00'),
            payment_due_date=15,
            priority_order=1,
            notes='High interest rate - priority for payoff'
        ),
        Debt(
            user_id=user.id,
            debt_name='Discover Card',
            debt_type='credit_card',
            original_balance=Decimal('3000.00'),
            current_balance=Decimal('3000.00'),
            interest_rate=Decimal('0.22'),
            minimum_payment=Decimal('100.00'),
            payment_due_date=20,
            priority_order=2,
            notes='Highest interest rate'
        ),
        Debt(
            user_id=user.id,
            debt_name='Personal Loan',
            debt_type='personal_loan',
            original_balance=Decimal('10000.00'),
            current_balance=Decimal('10000.00'),
            interest_rate=Decimal('0.12'),
            minimum_payment=Decimal('300.00'),
            payment_due_date=5,
            term_months=36,
            priority_order=3,
            notes='Fixed term loan'
        ),
        Debt(
            user_id=user.id,
            debt_name='Honda Civic Auto Loan',
            debt_type='auto_loan',
            original_balance=Decimal('15000.00'),
            current_balance=Decimal('15000.00'),
            interest_rate=Decimal('0.06'),
            minimum_payment=Decimal('350.00'),
            payment_due_date=10,
            term_months=48,
            priority_order=4,
            notes='Low interest rate'
        )
    ]
    
    for debt in debts:
        db.session.add(debt)
    
    db.session.commit()
    
    print("✓ Sample debts created")
    return debts


def create_sample_velocity_cycle(user):
    """Create a sample velocity cycle."""
    print("Creating sample velocity cycle...")
    
    existing_cycle = VelocityCycle.get_current_cycle(user.id)
    if existing_cycle:
        print("✓ Velocity cycle already exists")
        return existing_cycle
    
    cycle = VelocityCycle.create_new_cycle(
        user_id=user.id,
        paycheck_amount=Decimal('3000.00'),
        start_date=date.today(),
        notes='First velocity banking cycle'
    )
    
    # Add some sample data to the cycle
    cycle.total_debt_payments = Decimal('1200.00')
    cycle.total_expenses = Decimal('1500.00')
    cycle.calculate_cycle_effectiveness()
    
    db.session.commit()
    
    print("✓ Sample velocity cycle created")
    return cycle


def create_sample_transactions(user, debts):
    """Create sample transactions."""
    print("Creating sample transactions...")
    
    existing_transactions = Transaction.get_user_transactions(user.id, limit=1)
    if existing_transactions:
        print("✓ Transactions already exist")
        return existing_transactions
    
    transactions = [
        Transaction(
            user_id=user.id,
            transaction_date=date.today(),
            amount=Decimal('3000.00'),
            transaction_type='income',
            category='salary',
            description='Bi-weekly paycheck',
            merchant_name='Tech Company Inc.'
        ),
        Transaction(
            user_id=user.id,
            debt_id=debts[0].id,
            transaction_date=date.today(),
            amount=Decimal('-200.00'),
            transaction_type='debt_payment',
            category='debt_payment',
            description='Credit card payment',
            merchant_name='Chase Bank'
        ),
        Transaction(
            user_id=user.id,
            transaction_date=date.today(),
            amount=Decimal('-1200.00'),
            transaction_type='expense',
            category='rent',
            description='Monthly rent payment',
            merchant_name='Property Management Co.'
        ),
        Transaction(
            user_id=user.id,
            transaction_date=date.today(),
            amount=Decimal('-400.00'),
            transaction_type='expense',
            category='groceries',
            description='Weekly grocery shopping',
            merchant_name='Whole Foods'
        )
    ]
    
    for transaction in transactions:
        db.session.add(transaction)
    
    db.session.commit()
    
    print("✓ Sample transactions created")
    return transactions


def initialize_database():
    """Initialize the complete database with sample data."""
    print("Initializing Velocity Banking Database")
    print("=" * 50)
    
    try:
        # Create tables
        create_tables()
        
        # Create sample data
        user = create_sample_user()
        profile = create_sample_financial_profile(user)
        accounts = create_sample_bank_accounts(user)
        debts = create_sample_debts(user)
        cycle = create_sample_velocity_cycle(user)
        transactions = create_sample_transactions(user, debts)
        
        print("\n" + "=" * 50)
        print("✅ Database initialization completed successfully!")
        print("\nSample Login Credentials:")
        print("Email: demo@velocitybanking.com")
        print("Password: DemoPassword123!")
        print("\nYou can now start the application and log in with these credentials.")
        
    except Exception as e:
        print(f"\n❌ Error during database initialization: {str(e)}")
        db.session.rollback()
        raise


if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        initialize_database()

