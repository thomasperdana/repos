from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, date
from src.models import db, User, Debt, VelocityCycle, Transaction

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/summary', methods=['GET'])
@jwt_required()
def get_dashboard_summary():
    """Get comprehensive dashboard summary."""
    try:
        current_user_id = get_jwt_identity()
        user = User.find_by_id(current_user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'error': {
                    'code': 'USER_NOT_FOUND',
                    'message': 'User not found'
                }
            }), 404
        
        # Financial overview
        total_debt = Debt.calculate_total_debt(current_user_id)
        profile = user.financial_profile
        
        financial_overview = {
            'net_worth': float(profile.net_worth) if profile and profile.net_worth else 0,
            'total_debt': float(total_debt),
            'total_assets': 52000.00,  # Simplified calculation
            'debt_to_income_ratio': profile.calculate_debt_to_income_ratio() if profile else 0,
            'emergency_fund_months': profile.calculate_emergency_fund_months() if profile else 0
        }
        
        # Velocity banking info
        current_cycle = VelocityCycle.get_current_cycle(current_user_id)
        total_interest_saved = VelocityCycle.calculate_total_interest_saved(current_user_id)
        
        velocity_banking = {
            'current_cycle': current_cycle.to_dict() if current_cycle else None,
            'total_interest_saved': float(total_interest_saved),
            'projected_debt_free_date': '2027-06-15',  # Simplified calculation
            'acceleration_months': 18  # Simplified calculation
        }
        
        # Recent activity
        recent_transactions = Transaction.get_user_transactions(current_user_id, limit=1)
        recent_activity = {
            'last_transaction': recent_transactions[0].to_dict() if recent_transactions else None,
            'upcoming_payments': []  # Simplified
        }
        
        # Goals progress
        goals_progress = {
            'debt_reduction': {
                'target': float(total_debt),
                'current': float(total_debt),
                'progress_percentage': 0.0
            },
            'emergency_fund': {
                'target': float(profile.emergency_fund_target) if profile and profile.emergency_fund_target else 0,
                'current': float(profile.current_emergency_fund) if profile and profile.current_emergency_fund else 0,
                'progress_percentage': 26.7  # Simplified calculation
            }
        }
        
        return jsonify({
            'success': True,
            'data': {
                'financial_overview': financial_overview,
                'velocity_banking': velocity_banking,
                'recent_activity': recent_activity,
                'goals_progress': goals_progress
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An error occurred retrieving dashboard summary'
            }
        }), 500

