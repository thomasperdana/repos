"""
Calculation Service

This service provides high-level financial calculation functions for the API endpoints.
It integrates the velocity banking calculator with the database models.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime, date

try:
    from models import User, Debt, FinancialProfile, VelocityCycle, Transaction
    from utils.velocity_banking_calculator import (
        VelocityBankingCalculator,
        Debt as CalcDebt,
        FinancialProfile as CalcProfile,
        DebtType,
        PayoffStrategy
    )
except ImportError:
    from src.models import User, Debt, FinancialProfile, VelocityCycle, Transaction
    from src.utils.velocity_banking_calculator import (
        VelocityBankingCalculator,
        Debt as CalcDebt,
        FinancialProfile as CalcProfile,
        DebtType,
        PayoffStrategy
    )


class CalculationService:
    """Service class for financial calculations."""
    
    def __init__(self):
        self.calculator = VelocityBankingCalculator()
    
    def _convert_debt_to_calc_debt(self, debt: Debt) -> CalcDebt:
        """Convert database Debt model to calculator Debt object."""
        debt_type_mapping = {
            'credit_card': DebtType.CREDIT_CARD,
            'personal_loan': DebtType.PERSONAL_LOAN,
            'mortgage': DebtType.MORTGAGE,
            'auto_loan': DebtType.AUTO_LOAN,
            'student_loan': DebtType.STUDENT_LOAN,
            'other': DebtType.OTHER
        }
        
        return CalcDebt(
            id=str(debt.id),
            name=debt.debt_name,
            debt_type=debt_type_mapping.get(debt.debt_type, DebtType.OTHER),
            current_balance=float(debt.current_balance),
            interest_rate=float(debt.interest_rate),
            minimum_payment=float(debt.minimum_payment),
            payment_due_date=debt.payment_due_date or 1,
            term_months=debt.term_months
        )
    
    def _convert_profile_to_calc_profile(self, profile: FinancialProfile) -> CalcProfile:
        """Convert database FinancialProfile to calculator FinancialProfile."""
        monthly_income = float(profile.monthly_income) if profile.monthly_income else 0
        monthly_expenses = monthly_income * 0.7  # Estimate if not provided
        emergency_fund = float(profile.current_emergency_fund) if profile.current_emergency_fund else 0
        available_cash_flow = monthly_income - monthly_expenses
        
        return CalcProfile(
            monthly_income=monthly_income,
            monthly_expenses=monthly_expenses,
            emergency_fund=emergency_fund,
            available_cash_flow=available_cash_flow
        )
    
    def calculate_debt_optimization(self, user_id: str, strategy: str = 'velocity_banking', 
                                  extra_payment: float = 0) -> Dict[str, Any]:
        """Calculate optimal debt payoff strategy for a user."""
        try:
            # Get user's debts
            debts = Debt.get_user_debts(user_id, active_only=True)
            if not debts:
                return {
                    'strategy': strategy,
                    'total_interest_saved': 0,
                    'time_saved_months': 0,
                    'projected_payoff_date': None,
                    'debt_sequence': [],
                    'error': 'No active debts found'
                }
            
            # Convert to calculator objects
            calc_debts = [self._convert_debt_to_calc_debt(debt) for debt in debts]
            
            # Get user's financial profile
            user = User.find_by_id(user_id)
            if not user or not user.financial_profile:
                # Create default profile
                calc_profile = CalcProfile(
                    monthly_income=5000,
                    monthly_expenses=3500,
                    emergency_fund=1000,
                    available_cash_flow=1500
                )
            else:
                calc_profile = self._convert_profile_to_calc_profile(user.financial_profile)
            
            # Calculate based on strategy
            if strategy == 'velocity_banking':
                result = self.calculator.calculate_velocity_banking_strategy(calc_debts, calc_profile)
            elif strategy == 'debt_avalanche':
                result = self.calculator.calculate_debt_avalanche(calc_debts, extra_payment)
            elif strategy == 'debt_snowball':
                result = self.calculator.calculate_debt_snowball(calc_debts, extra_payment)
            else:
                result = self.calculator.calculate_velocity_banking_strategy(calc_debts, calc_profile)
            
            # Create debt sequence
            debt_sequence = []
            for i, debt in enumerate(calc_debts):
                debt_sequence.append({
                    'debt_id': debt.id,
                    'debt_name': debt.name,
                    'payoff_order': i + 1,
                    'current_balance': debt.current_balance,
                    'interest_rate': debt.interest_rate,
                    'minimum_payment': debt.minimum_payment
                })
            
            return {
                'strategy': strategy,
                'total_interest_saved': result.interest_saved_vs_minimum,
                'time_saved_months': max(0, 60 - result.total_months),  # Assume 60 months baseline
                'projected_payoff_date': result.debt_free_date.isoformat(),
                'total_months': result.total_months,
                'total_interest_paid': result.total_interest_paid,
                'total_payments': result.total_payments,
                'debt_sequence': debt_sequence
            }
            
        except Exception as e:
            return {
                'strategy': strategy,
                'total_interest_saved': 0,
                'time_saved_months': 0,
                'projected_payoff_date': None,
                'debt_sequence': [],
                'error': str(e)
            }
    
    def compare_debt_strategies(self, user_id: str, extra_payment: float = 0) -> Dict[str, Any]:
        """Compare all debt payoff strategies for a user."""
        try:
            # Get user's debts and profile
            debts = Debt.get_user_debts(user_id, active_only=True)
            if not debts:
                return {'error': 'No active debts found'}
            
            calc_debts = [self._convert_debt_to_calc_debt(debt) for debt in debts]
            
            user = User.find_by_id(user_id)
            if user and user.financial_profile:
                calc_profile = self._convert_profile_to_calc_profile(user.financial_profile)
            else:
                calc_profile = CalcProfile(5000, 3500, 1000, 1500)
            
            # Compare all strategies
            strategies = self.calculator.compare_strategies(calc_debts, calc_profile, extra_payment)
            
            comparison = {}
            for strategy_name, result in strategies.items():
                if result and result.total_months != float('inf'):
                    comparison[strategy_name] = {
                        'total_months': result.total_months,
                        'total_interest': result.total_interest_paid,
                        'total_payments': result.total_payments,
                        'debt_free_date': result.debt_free_date.isoformat(),
                        'interest_saved_vs_minimum': result.interest_saved_vs_minimum
                    }
            
            # Determine best strategy (lowest total interest)
            best_strategy = min(comparison.keys(), 
                              key=lambda k: comparison[k]['total_interest']) if comparison else None
            
            return {
                'comparison': comparison,
                'best_strategy': best_strategy,
                'total_debt': sum(debt.current_balance for debt in debts)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def calculate_velocity_cycle_effectiveness(self, user_id: str, paycheck_amount: float, 
                                             cycle_number: int = 1) -> Dict[str, Any]:
        """Calculate the effectiveness of a velocity banking cycle."""
        try:
            # Get user's debts
            debts = Debt.get_user_debts(user_id, active_only=True)
            calc_debts = [self._convert_debt_to_calc_debt(debt) for debt in debts]
            
            # Estimate monthly expenses (could be from user profile)
            user = User.find_by_id(user_id)
            if user and user.financial_profile:
                monthly_expenses = paycheck_amount * 0.6  # Conservative estimate
            else:
                monthly_expenses = paycheck_amount * 0.7  # Default estimate
            
            # Calculate cycle
            cycle_result = self.calculator.calculate_velocity_cycle(
                paycheck_amount, calc_debts, monthly_expenses, cycle_number
            )
            
            return {
                'cycle_number': cycle_result.cycle_number,
                'paycheck_amount': cycle_result.paycheck_amount,
                'debt_payments': cycle_result.debt_payments,
                'remaining_expenses': cycle_result.remaining_expenses,
                'cycle_effectiveness': cycle_result.cycle_effectiveness,
                'interest_saved': cycle_result.interest_saved,
                'projected_completion_date': cycle_result.projected_completion_date.isoformat()
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def calculate_financial_metrics(self, user_id: str) -> Dict[str, Any]:
        """Calculate comprehensive financial metrics for a user."""
        try:
            user = User.find_by_id(user_id)
            if not user:
                return {'error': 'User not found'}
            
            # Get debts and calculate totals
            debts = Debt.get_user_debts(user_id, active_only=True)
            total_debt = sum(float(debt.current_balance) for debt in debts)
            total_minimum_payments = sum(float(debt.minimum_payment) for debt in debts)
            
            # Get financial profile
            profile = user.financial_profile
            monthly_income = float(profile.monthly_income) if profile and profile.monthly_income else 0
            emergency_fund = float(profile.current_emergency_fund) if profile and profile.current_emergency_fund else 0
            
            # Calculate metrics
            debt_to_income_ratio = self.calculator.calculate_debt_to_income_ratio(
                total_minimum_payments, monthly_income
            )
            
            emergency_fund_months = self.calculator.calculate_emergency_fund_months(
                emergency_fund, monthly_income * 0.7  # Estimated expenses
            )
            
            # Estimate net worth (simplified)
            estimated_assets = monthly_income * 12 * 1.5  # Rough estimate
            net_worth = self.calculator.calculate_net_worth(estimated_assets, total_debt)
            
            # Project financial freedom
            calc_debts = [self._convert_debt_to_calc_debt(debt) for debt in debts]
            calc_profile = CalcProfile(monthly_income, monthly_income * 0.7, emergency_fund, monthly_income * 0.3)
            
            financial_freedom_date = self.calculator.project_financial_freedom_date(calc_debts, calc_profile)
            
            return {
                'total_debt': total_debt,
                'total_minimum_payments': total_minimum_payments,
                'monthly_income': monthly_income,
                'debt_to_income_ratio': debt_to_income_ratio,
                'emergency_fund': emergency_fund,
                'emergency_fund_months': emergency_fund_months,
                'estimated_net_worth': net_worth,
                'financial_freedom_date': financial_freedom_date.isoformat(),
                'debt_count': len(debts)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def simulate_extra_payment_impact(self, user_id: str, extra_payment_amounts: List[float]) -> Dict[str, Any]:
        """Simulate the impact of different extra payment amounts."""
        try:
            results = {}
            
            for amount in extra_payment_amounts:
                optimization_result = self.calculate_debt_optimization(
                    user_id, 'velocity_banking', amount
                )
                
                results[f'extra_${int(amount)}'] = {
                    'extra_payment': amount,
                    'total_months': optimization_result.get('total_months', 0),
                    'total_interest_saved': optimization_result.get('total_interest_saved', 0),
                    'projected_payoff_date': optimization_result.get('projected_payoff_date')
                }
            
            return {
                'simulations': results,
                'recommendation': self._get_extra_payment_recommendation(results)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _get_extra_payment_recommendation(self, simulation_results: Dict[str, Any]) -> str:
        """Get recommendation based on extra payment simulations."""
        if not simulation_results:
            return "Unable to provide recommendation"
        
        # Find the sweet spot (best interest savings per dollar)
        best_efficiency = 0
        best_amount = 0
        
        for key, result in simulation_results.items():
            extra_payment = result.get('extra_payment', 0)
            interest_saved = result.get('total_interest_saved', 0)
            
            if extra_payment > 0:
                efficiency = interest_saved / extra_payment
                if efficiency > best_efficiency:
                    best_efficiency = efficiency
                    best_amount = extra_payment
        
        if best_amount > 0:
            return f"Recommended extra payment: ${best_amount:.0f}/month for optimal interest savings"
        else:
            return "Focus on minimum payments and building emergency fund first"


# Singleton instance
calculation_service = CalculationService()

