import uuid
from datetime import datetime, timezone, date
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Text, Numeric, Integer, Date
from . import db

class VelocityCycle(db.Model):
    __tablename__ = 'velocity_cycles'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    
    # Cycle information
    cycle_number = db.Column(Integer, nullable=False)
    start_date = db.Column(Date, nullable=False)
    end_date = db.Column(Date)
    
    # Financial amounts
    paycheck_amount = db.Column(Numeric(12, 2), nullable=False)
    total_debt_payments = db.Column(Numeric(12, 2), default=0.00)
    total_expenses = db.Column(Numeric(12, 2), default=0.00)
    interest_saved = db.Column(Numeric(10, 2), default=0.00)
    
    # Performance metrics
    cycle_effectiveness = db.Column(Numeric(5, 4))  # Percentage effectiveness (0-1)
    
    # Status and notes
    status = db.Column(String(20), default='active')  # active, completed, cancelled
    notes = db.Column(Text)
    
    # Timestamps
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    transactions = db.relationship('Transaction', backref='velocity_cycle')
    debt_payments = db.relationship('DebtPayment', backref='velocity_cycle')
    
    def __repr__(self):
        return f'<VelocityCycle {self.cycle_number} - {self.status}>'
    
    def to_dict(self):
        """Convert velocity cycle to dictionary."""
        return {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'cycle_number': self.cycle_number,
            'start_date': self.start_date.isoformat(),
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'paycheck_amount': float(self.paycheck_amount),
            'total_debt_payments': float(self.total_debt_payments),
            'total_expenses': float(self.total_expenses),
            'interest_saved': float(self.interest_saved),
            'cycle_effectiveness': float(self.cycle_effectiveness) if self.cycle_effectiveness else None,
            'status': self.status,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def calculate_cycle_effectiveness(self):
        """Calculate the effectiveness of this velocity cycle."""
        if float(self.paycheck_amount) == 0:
            return 0
        
        # Effectiveness = (Debt Payments / Paycheck Amount) * efficiency_factor
        debt_payment_ratio = float(self.total_debt_payments) / float(self.paycheck_amount)
        
        # Efficiency factor based on expense ratio (lower expenses = higher efficiency)
        expense_ratio = float(self.total_expenses) / float(self.paycheck_amount)
        efficiency_factor = max(0.1, 1 - expense_ratio)  # Minimum 10% efficiency
        
        effectiveness = debt_payment_ratio * efficiency_factor
        self.cycle_effectiveness = min(1.0, effectiveness)  # Cap at 100%
        
        db.session.commit()
        return float(self.cycle_effectiveness)
    
    def calculate_interest_saved(self):
        """Calculate interest saved during this cycle."""
        # This would involve complex calculations comparing to minimum payment scenario
        # For now, we'll use a simplified calculation
        total_extra_payments = max(0, float(self.total_debt_payments) - self.get_minimum_payments_for_cycle())
        
        # Estimate interest saved as 1.5% of extra payments (monthly interest rate approximation)
        estimated_interest_saved = total_extra_payments * 0.015
        
        self.interest_saved = estimated_interest_saved
        db.session.commit()
        return float(self.interest_saved)
    
    def get_minimum_payments_for_cycle(self):
        """Get the total minimum payments for all debts during this cycle."""
        from .debt import Debt
        debts = Debt.get_user_debts(self.user_id, active_only=True)
        return sum(float(debt.minimum_payment) for debt in debts)
    
    def complete_cycle(self, end_date=None):
        """Complete the velocity cycle and calculate final metrics."""
        if end_date is None:
            end_date = date.today()
        
        self.end_date = end_date
        self.status = 'completed'
        
        # Calculate final metrics
        self.calculate_cycle_effectiveness()
        self.calculate_interest_saved()
        
        db.session.commit()
    
    def add_transaction(self, transaction):
        """Add a transaction to this cycle and update totals."""
        transaction.velocity_cycle_id = self.id
        
        if transaction.transaction_type == 'debt_payment':
            self.total_debt_payments += abs(float(transaction.amount))
        elif transaction.transaction_type == 'expense':
            self.total_expenses += abs(float(transaction.amount))
        
        db.session.commit()
    
    @classmethod
    def get_user_cycles(cls, user_id, status=None, limit=20, offset=0):
        """Get user's velocity cycles with optional filtering."""
        query = cls.query.filter_by(user_id=user_id)
        
        if status:
            query = query.filter_by(status=status)
        
        return query.order_by(cls.cycle_number.desc()).offset(offset).limit(limit).all()
    
    @classmethod
    def get_current_cycle(cls, user_id):
        """Get the user's current active velocity cycle."""
        return cls.query.filter_by(user_id=user_id, status='active').first()
    
    @classmethod
    def create_new_cycle(cls, user_id, paycheck_amount, start_date=None, notes=None):
        """Create a new velocity cycle for the user."""
        if start_date is None:
            start_date = date.today()
        
        # Get the next cycle number
        last_cycle = cls.query.filter_by(user_id=user_id).order_by(cls.cycle_number.desc()).first()
        cycle_number = (last_cycle.cycle_number + 1) if last_cycle else 1
        
        # Complete any existing active cycles
        active_cycle = cls.get_current_cycle(user_id)
        if active_cycle:
            active_cycle.complete_cycle()
        
        # Create new cycle
        new_cycle = cls(
            user_id=user_id,
            cycle_number=cycle_number,
            start_date=start_date,
            paycheck_amount=paycheck_amount,
            notes=notes
        )
        
        db.session.add(new_cycle)
        db.session.commit()
        
        return new_cycle
    
    @classmethod
    def calculate_total_interest_saved(cls, user_id):
        """Calculate total interest saved across all completed cycles."""
        completed_cycles = cls.query.filter_by(user_id=user_id, status='completed').all()
        return sum(float(cycle.interest_saved) for cycle in completed_cycles)

