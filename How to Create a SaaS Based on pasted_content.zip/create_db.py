"""
Standalone Database Creation Script

This script creates the database and tables without complex imports.
"""

import sqlite3
import os
from datetime import date

# Database file path
DB_PATH = 'src/velocity_banking.db'

def create_database():
    """Create the SQLite database and all tables."""
    
    # Remove existing database
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print("Removed existing database")
    
    # Create database connection
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("Creating database tables...")
    
    # Users table
    cursor.execute('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email VARCHAR(120) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            phone VARCHAR(20),
            date_of_birth DATE,
            subscription_tier VARCHAR(20) DEFAULT 'free',
            is_email_verified BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Financial profiles table
    cursor.execute('''
        CREATE TABLE financial_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            annual_income DECIMAL(12,2),
            monthly_income DECIMAL(12,2),
            employment_status VARCHAR(50),
            employer_name VARCHAR(100),
            employment_start_date DATE,
            financial_goals TEXT,
            risk_tolerance VARCHAR(20),
            emergency_fund_target DECIMAL(12,2),
            current_emergency_fund DECIMAL(12,2),
            net_worth DECIMAL(12,2),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Bank accounts table
    cursor.execute('''
        CREATE TABLE bank_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            account_name VARCHAR(100) NOT NULL,
            account_type VARCHAR(20) NOT NULL,
            institution_name VARCHAR(100),
            account_number_encrypted VARCHAR(255),
            routing_number_encrypted VARCHAR(255),
            current_balance DECIMAL(12,2) DEFAULT 0.00,
            available_balance DECIMAL(12,2),
            credit_limit DECIMAL(12,2),
            interest_rate DECIMAL(5,4),
            is_primary BOOLEAN DEFAULT FALSE,
            is_active BOOLEAN DEFAULT TRUE,
            last_sync_date TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Debts table
    cursor.execute('''
        CREATE TABLE debts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            debt_name VARCHAR(100) NOT NULL,
            debt_type VARCHAR(50) NOT NULL,
            original_balance DECIMAL(12,2) NOT NULL,
            current_balance DECIMAL(12,2) NOT NULL,
            interest_rate DECIMAL(5,4) NOT NULL,
            minimum_payment DECIMAL(10,2) NOT NULL,
            payment_due_date INTEGER,
            term_months INTEGER,
            priority_order INTEGER,
            is_active BOOLEAN DEFAULT TRUE,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Velocity cycles table
    cursor.execute('''
        CREATE TABLE velocity_cycles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            cycle_number INTEGER NOT NULL,
            paycheck_amount DECIMAL(10,2) NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE,
            total_debt_payments DECIMAL(10,2) DEFAULT 0.00,
            total_expenses DECIMAL(10,2) DEFAULT 0.00,
            cycle_effectiveness DECIMAL(5,4),
            is_active BOOLEAN DEFAULT TRUE,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Transactions table
    cursor.execute('''
        CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            bank_account_id INTEGER,
            debt_id INTEGER,
            velocity_cycle_id INTEGER,
            transaction_date DATE NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            transaction_type VARCHAR(50) NOT NULL,
            category VARCHAR(50),
            description TEXT,
            merchant_name VARCHAR(100),
            is_recurring BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (bank_account_id) REFERENCES bank_accounts (id),
            FOREIGN KEY (debt_id) REFERENCES debts (id),
            FOREIGN KEY (velocity_cycle_id) REFERENCES velocity_cycles (id)
        )
    ''')
    
    # User sessions table
    cursor.execute('''
        CREATE TABLE user_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            session_token VARCHAR(255) UNIQUE NOT NULL,
            expires_at TIMESTAMP NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Audit logs table
    cursor.execute('''
        CREATE TABLE audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action VARCHAR(100) NOT NULL,
            resource_type VARCHAR(50),
            resource_id INTEGER,
            old_values TEXT,
            new_values TEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    print("✓ Database tables created successfully")
    
    # Create sample user
    print("Creating sample user...")
    cursor.execute('''
        INSERT INTO users (email, password_hash, first_name, last_name, phone, subscription_tier, is_email_verified)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', ('demo@velocitybanking.com', 'pbkdf2:sha256:600000$demo$hash', 'Demo', 'User', '+1 (555) 123-4567', 'premium', True))
    
    user_id = cursor.lastrowid
    
    # Create sample financial profile
    print("Creating sample financial profile...")
    cursor.execute('''
        INSERT INTO financial_profiles (user_id, annual_income, monthly_income, employment_status, 
                                      employer_name, emergency_fund_target, current_emergency_fund, net_worth)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (user_id, 72000.00, 6000.00, 'full_time', 'Tech Company Inc.', 15000.00, 4000.00, 45000.00))
    
    # Create sample bank accounts
    print("Creating sample bank accounts...")
    bank_accounts = [
        (user_id, 'Primary Checking', 'checking', 'First National Bank', 2500.00, True),
        (user_id, 'Savings Account', 'savings', 'First National Bank', 4000.00, False),
        (user_id, 'Credit Card', 'credit', 'Chase Bank', -5000.00, False)
    ]
    
    cursor.executemany('''
        INSERT INTO bank_accounts (user_id, account_name, account_type, institution_name, current_balance, is_primary)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', bank_accounts)
    
    # Create sample debts
    print("Creating sample debts...")
    debts = [
        (user_id, 'Chase Freedom Credit Card', 'credit_card', 5000.00, 5000.00, 0.18, 150.00, 15, 1),
        (user_id, 'Discover Card', 'credit_card', 3000.00, 3000.00, 0.22, 100.00, 20, 2),
        (user_id, 'Personal Loan', 'personal_loan', 10000.00, 10000.00, 0.12, 300.00, 5, 3),
        (user_id, 'Honda Civic Auto Loan', 'auto_loan', 15000.00, 15000.00, 0.06, 350.00, 10, 4)
    ]
    
    cursor.executemany('''
        INSERT INTO debts (user_id, debt_name, debt_type, original_balance, current_balance, 
                          interest_rate, minimum_payment, payment_due_date, priority_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', debts)
    
    # Create sample velocity cycle
    print("Creating sample velocity cycle...")
    cursor.execute('''
        INSERT INTO velocity_cycles (user_id, cycle_number, paycheck_amount, start_date, 
                                   total_debt_payments, total_expenses, cycle_effectiveness)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (user_id, 1, 3000.00, date.today().isoformat(), 1200.00, 1500.00, 0.567))
    
    # Create sample transactions
    print("Creating sample transactions...")
    transactions = [
        (user_id, date.today().isoformat(), 3000.00, 'income', 'salary', 'Bi-weekly paycheck', 'Tech Company Inc.'),
        (user_id, date.today().isoformat(), -200.00, 'debt_payment', 'debt_payment', 'Credit card payment', 'Chase Bank'),
        (user_id, date.today().isoformat(), -1200.00, 'expense', 'rent', 'Monthly rent payment', 'Property Management Co.'),
        (user_id, date.today().isoformat(), -400.00, 'expense', 'groceries', 'Weekly grocery shopping', 'Whole Foods')
    ]
    
    cursor.executemany('''
        INSERT INTO transactions (user_id, transaction_date, amount, transaction_type, 
                                category, description, merchant_name)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', transactions)
    
    # Commit changes
    conn.commit()
    conn.close()
    
    print("\n" + "=" * 50)
    print("✅ Database created successfully!")
    print("\nSample Login Credentials:")
    print("Email: demo@velocitybanking.com")
    print("Password: DemoPassword123!")
    print("\nDatabase file: " + DB_PATH)


if __name__ == '__main__':
    create_database()

