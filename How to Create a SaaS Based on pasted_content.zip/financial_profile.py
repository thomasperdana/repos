import uuid
from datetime import datetime, timezone
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Text, Numeric, Date
from . import db

class FinancialProfile(db.Model):
    __tablename__ = 'financial_profiles'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    
    # Income information
    annual_income = db.Column(Numeric(12, 2))
    monthly_income = db.Column(Numeric(12, 2))
    
    # Employment information
    employment_status = db.Column(String(50))  # full_time, part_time, self_employed, unemployed, retired
    employer_name = db.Column(String(200))
    employment_start_date = db.Column(Date)
    
    # Financial goals and preferences
    financial_goals = db.Column(Text)
    risk_tolerance = db.Column(String(20), default='moderate')  # conservative, moderate, aggressive
    
    # Emergency fund
    emergency_fund_target = db.Column(Numeric(12, 2))
    current_emergency_fund = db.Column(Numeric(12, 2))
    
    # Net worth tracking
    net_worth = db.Column(Numeric(12, 2))
    
    # Timestamps
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    def __repr__(self):
        return f'<FinancialProfile {self.user_id}>'
    
    def to_dict(self):
        """Convert financial profile to dictionary."""
        return {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'annual_income': float(self.annual_income) if self.annual_income else None,
            'monthly_income': float(self.monthly_income) if self.monthly_income else None,
            'employment_status': self.employment_status,
            'employer_name': self.employer_name,
            'employment_start_date': self.employment_start_date.isoformat() if self.employment_start_date else None,
            'financial_goals': self.financial_goals,
            'risk_tolerance': self.risk_tolerance,
            'emergency_fund_target': float(self.emergency_fund_target) if self.emergency_fund_target else None,
            'current_emergency_fund': float(self.current_emergency_fund) if self.current_emergency_fund else None,
            'net_worth': float(self.net_worth) if self.net_worth else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def calculate_debt_to_income_ratio(self):
        """Calculate debt-to-income ratio based on user's debts."""
        if not self.monthly_income:
            return None
        
        total_monthly_debt_payments = sum(
            float(debt.minimum_payment) for debt in self.user.debts if debt.is_active
        )
        
        return total_monthly_debt_payments / float(self.monthly_income) if self.monthly_income > 0 else 0
    
    def calculate_emergency_fund_months(self):
        """Calculate how many months of expenses the emergency fund covers."""
        if not self.current_emergency_fund or not self.monthly_income:
            return 0
        
        # Estimate monthly expenses as 70% of monthly income
        estimated_monthly_expenses = float(self.monthly_income) * 0.7
        return float(self.current_emergency_fund) / estimated_monthly_expenses if estimated_monthly_expenses > 0 else 0
    
    def update_net_worth(self):
        """Calculate and update net worth based on assets and debts."""
        # Calculate total debt
        total_debt = sum(
            float(debt.current_balance) for debt in self.user.debts if debt.is_active
        )
        
        # Calculate total assets (bank account balances + emergency fund)
        total_assets = sum(
            float(account.current_balance) for account in self.user.bank_accounts if account.is_active
        )
        
        self.net_worth = total_assets - total_debt
        db.session.commit()
        
        return float(self.net_worth)

