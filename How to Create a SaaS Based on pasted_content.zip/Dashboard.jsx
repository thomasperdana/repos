import React, { useState, useEffect } from 'react'
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Calendar, 
  Zap,
  CreditCard,
  Target,
  Clock
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Button } from '@/components/ui/button'
import { useAuth } from '../contexts/AuthContext'

const Dashboard = () => {
  const { apiCall } = useAuth()
  const [dashboardData, setDashboardData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    const result = await apiCall('/dashboard/summary')
    if (result.success) {
      setDashboardData(result.data)
    }
    setLoading(false)
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  const mockData = {
    financial_overview: {
      net_worth: 45000,
      total_debt: 27500,
      total_assets: 72500,
      debt_to_income_ratio: 0.35,
      emergency_fund_months: 2.5
    },
    velocity_banking: {
      current_cycle: {
        cycle_number: 3,
        paycheck_amount: 5000,
        total_debt_payments: 3200,
        cycle_effectiveness: 0.85
      },
      total_interest_saved: 4750,
      projected_debt_free_date: '2027-06-15',
      acceleration_months: 18
    },
    goals_progress: {
      debt_reduction: {
        target: 27500,
        current: 27500,
        progress_percentage: 0
      },
      emergency_fund: {
        target: 15000,
        current: 4000,
        progress_percentage: 26.7
      }
    }
  }

  const data = dashboardData || mockData

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Welcome back! Here's your financial overview.</p>
        </div>
        <Button>
          <Zap className="mr-2 h-4 w-4" />
          Start New Cycle
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Net Worth</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${data.financial_overview.net_worth.toLocaleString()}
                </p>
              </div>
              <div className="p-2 bg-green-100 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="mt-2 flex items-center text-sm">
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-green-600">+12.5%</span>
              <span className="text-gray-500 ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Debt</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${data.financial_overview.total_debt.toLocaleString()}
                </p>
              </div>
              <div className="p-2 bg-red-100 rounded-lg">
                <CreditCard className="h-6 w-6 text-red-600" />
              </div>
            </div>
            <div className="mt-2 flex items-center text-sm">
              <TrendingDown className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-green-600">-8.3%</span>
              <span className="text-gray-500 ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Interest Saved</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${data.velocity_banking.total_interest_saved.toLocaleString()}
                </p>
              </div>
              <div className="p-2 bg-blue-100 rounded-lg">
                <DollarSign className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-2 flex items-center text-sm">
              <span className="text-blue-600">Velocity Banking</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Debt Free Date</p>
                <p className="text-2xl font-bold text-gray-900">Jun 2027</p>
              </div>
              <div className="p-2 bg-purple-100 rounded-lg">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-2 flex items-center text-sm">
              <Clock className="h-4 w-4 text-purple-500 mr-1" />
              <span className="text-purple-600">{data.velocity_banking.acceleration_months} months faster</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Current Velocity Cycle */}
      {data.velocity_banking.current_cycle && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="mr-2 h-5 w-5 text-blue-600" />
              Current Velocity Cycle #{data.velocity_banking.current_cycle.cycle_number}
            </CardTitle>
            <CardDescription>
              Track your current velocity banking cycle performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <p className="text-sm font-medium text-gray-600">Paycheck Amount</p>
                <p className="text-xl font-bold text-gray-900">
                  ${data.velocity_banking.current_cycle.paycheck_amount.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">Debt Payments</p>
                <p className="text-xl font-bold text-gray-900">
                  ${data.velocity_banking.current_cycle.total_debt_payments.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">Cycle Effectiveness</p>
                <p className="text-xl font-bold text-gray-900">
                  {(data.velocity_banking.current_cycle.cycle_effectiveness * 100).toFixed(1)}%
                </p>
                <Progress 
                  value={data.velocity_banking.current_cycle.cycle_effectiveness * 100} 
                  className="mt-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Goals Progress */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="mr-2 h-5 w-5 text-red-600" />
              Debt Reduction Goal
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{data.goals_progress.debt_reduction.progress_percentage.toFixed(1)}%</span>
              </div>
              <Progress value={data.goals_progress.debt_reduction.progress_percentage} />
              <div className="flex justify-between text-sm text-gray-600">
                <span>Current: ${data.goals_progress.debt_reduction.current.toLocaleString()}</span>
                <span>Target: $0</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="mr-2 h-5 w-5 text-green-600" />
              Emergency Fund Goal
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{data.goals_progress.emergency_fund.progress_percentage.toFixed(1)}%</span>
              </div>
              <Progress value={data.goals_progress.emergency_fund.progress_percentage} />
              <div className="flex justify-between text-sm text-gray-600">
                <span>Current: ${data.goals_progress.emergency_fund.current.toLocaleString()}</span>
                <span>Target: ${data.goals_progress.emergency_fund.target.toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Common tasks to manage your velocity banking strategy
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col">
              <CreditCard className="h-6 w-6 mb-2" />
              Add Debt
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <DollarSign className="h-6 w-6 mb-2" />
              Record Payment
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <Zap className="h-6 w-6 mb-2" />
              New Cycle
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <TrendingUp className="h-6 w-6 mb-2" />
              View Scenarios
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard

