import uuid
from datetime import datetime, timezone, date
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy import String, DateTime, Numeric, Boolean, Date
from . import db

class DebtPayment(db.Model):
    __tablename__ = 'debt_payments'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    debt_id = db.Column(UUID(as_uuid=True), db.ForeignKey('debts.id'), nullable=False)
    velocity_cycle_id = db.Column(UUID(as_uuid=True), db.ForeignKey('velocity_cycles.id'))
    
    # Payment details
    payment_date = db.Column(Date, nullable=False)
    payment_amount = db.Column(Numeric(12, 2), nullable=False)
    principal_amount = db.Column(Numeric(12, 2), nullable=False)
    interest_amount = db.Column(Numeric(12, 2), nullable=False)
    remaining_balance = db.Column(Numeric(12, 2), nullable=False)
    
    # Payment type and automation
    payment_type = db.Column(String(50), default='regular')  # regular, extra, minimum, payoff
    is_automated = db.Column(Boolean, default=False)
    
    # Timestamp
    created_at = db.Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    
    def __repr__(self):
        return f'<DebtPayment {self.payment_amount} to {self.debt_id}>'
    
    def to_dict(self):
        """Convert debt payment to dictionary."""
        return {
            'id': str(self.id),
            'user_id': str(self.user_id),
            'debt_id': str(self.debt_id),
            'velocity_cycle_id': str(self.velocity_cycle_id) if self.velocity_cycle_id else None,
            'payment_date': self.payment_date.isoformat(),
            'payment_amount': float(self.payment_amount),
            'principal_amount': float(self.principal_amount),
            'interest_amount': float(self.interest_amount),
            'remaining_balance': float(self.remaining_balance),
            'payment_type': self.payment_type,
            'is_automated': self.is_automated,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

