# API Specification - Velocity Banking SaaS

## Overview

This document defines the complete REST API specification for the Velocity Banking SaaS application. The API follows RESTful principles with consistent response formats, comprehensive error handling, and robust authentication mechanisms.

## Base Configuration

**Base URL:** `https://api.velocitybanking.com/v1`  
**Authentication:** JWT Bearer tokens  
**Content Type:** `application/json`  
**API Version:** v1  

## Authentication Endpoints

### POST /auth/register

Register a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "first_name": "John",
  "last_name": "Doe",
  "phone": "+1234567890",
  "date_of_birth": "1990-01-15"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "user_id": "123e4567-e89b-12d3-a456-426614174000",
    "email": "user@example.com",
    "verification_required": true
  }
}
```

### POST /auth/login

Authenticate user and receive access tokens.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_in": 3600,
    "user": {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "email": "user@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "subscription_tier": "free"
    }
  }
}
```

### POST /auth/refresh

Refresh access token using refresh token.

**Request Body:**
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_in": 3600
  }
}
```

### POST /auth/logout

Invalidate user session and tokens.

**Headers:** `Authorization: Bearer <access_token>`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### POST /auth/forgot-password

Request password reset email.

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Password reset email sent"
}
```

### POST /auth/reset-password

Reset password using reset token.

**Request Body:**
```json
{
  "token": "reset_token_here",
  "new_password": "NewSecurePassword123!"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Password reset successfully"
}
```

## User Management Endpoints

### GET /users/profile

Get current user profile information.

**Headers:** `Authorization: Bearer <access_token>`

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "phone": "+1234567890",
    "date_of_birth": "1990-01-15",
    "subscription_tier": "free",
    "created_at": "2025-01-15T10:30:00Z",
    "preferences": {
      "timezone": "America/New_York",
      "currency": "USD",
      "notifications": {
        "email": true,
        "push": false
      }
    }
  }
}
```

### PUT /users/profile

Update user profile information.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "first_name": "John",
  "last_name": "Smith",
  "phone": "+1234567890",
  "preferences": {
    "timezone": "America/Los_Angeles",
    "currency": "USD"
  }
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Profile updated successfully",
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Smith",
    "updated_at": "2025-07-29T15:45:00Z"
  }
}
```

## Financial Profile Endpoints

### GET /financial-profile

Get user's financial profile.

**Headers:** `Authorization: Bearer <access_token>`

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "456e7890-e89b-12d3-a456-426614174001",
    "annual_income": 75000.00,
    "monthly_income": 6250.00,
    "employment_status": "full_time",
    "employer_name": "Tech Corp Inc",
    "financial_goals": "Become debt-free in 3 years",
    "risk_tolerance": "moderate",
    "emergency_fund_target": 18750.00,
    "current_emergency_fund": 5000.00,
    "net_worth": 25000.00,
    "created_at": "2025-01-15T10:30:00Z",
    "updated_at": "2025-07-29T15:45:00Z"
  }
}
```

### PUT /financial-profile

Update financial profile information.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "annual_income": 80000.00,
  "monthly_income": 6666.67,
  "employment_status": "full_time",
  "employer_name": "New Tech Corp",
  "financial_goals": "Become debt-free in 2.5 years",
  "risk_tolerance": "aggressive",
  "emergency_fund_target": 20000.00,
  "current_emergency_fund": 7500.00
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Financial profile updated successfully",
  "data": {
    "id": "456e7890-e89b-12d3-a456-426614174001",
    "updated_at": "2025-07-29T16:00:00Z"
  }
}
```

## Bank Account Endpoints

### GET /bank-accounts

Get all user's bank accounts.

**Headers:** `Authorization: Bearer <access_token>`

**Query Parameters:**
- `type` (optional): Filter by account type (checking, savings, credit_line, credit_card)
- `active` (optional): Filter by active status (true/false)

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "accounts": [
      {
        "id": "789e0123-e89b-12d3-a456-426614174002",
        "account_name": "Primary Checking",
        "account_type": "checking",
        "institution_name": "First National Bank",
        "current_balance": 2500.00,
        "available_balance": 2500.00,
        "is_primary": true,
        "is_active": true,
        "last_sync": "2025-07-29T08:00:00Z",
        "created_at": "2025-01-15T10:30:00Z"
      },
      {
        "id": "890e1234-e89b-12d3-a456-426614174003",
        "account_name": "HELOC",
        "account_type": "credit_line",
        "institution_name": "Credit Union",
        "current_balance": 15000.00,
        "available_balance": 35000.00,
        "credit_limit": 50000.00,
        "interest_rate": 0.0575,
        "is_primary": false,
        "is_active": true,
        "last_sync": "2025-07-29T08:00:00Z"
      }
    ],
    "total_count": 2
  }
}
```

### POST /bank-accounts

Add a new bank account.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "account_name": "Savings Account",
  "account_type": "savings",
  "institution_name": "Online Bank",
  "current_balance": 10000.00,
  "interest_rate": 0.045,
  "is_primary": false
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Bank account added successfully",
  "data": {
    "id": "901e2345-e89b-12d3-a456-426614174004",
    "account_name": "Savings Account",
    "account_type": "savings",
    "created_at": "2025-07-29T16:15:00Z"
  }
}
```

### PUT /bank-accounts/{account_id}

Update bank account information.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "account_name": "Updated Savings",
  "current_balance": 12000.00,
  "is_primary": false
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Bank account updated successfully",
  "data": {
    "id": "901e2345-e89b-12d3-a456-426614174004",
    "updated_at": "2025-07-29T16:30:00Z"
  }
}
```

### DELETE /bank-accounts/{account_id}

Delete a bank account.

**Headers:** `Authorization: Bearer <access_token>`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Bank account deleted successfully"
}
```

## Debt Management Endpoints

### GET /debts

Get all user's debts.

**Headers:** `Authorization: Bearer <access_token>`

**Query Parameters:**
- `type` (optional): Filter by debt type
- `active` (optional): Filter by active status
- `sort` (optional): Sort by priority, balance, interest_rate, or payoff_date

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "debts": [
      {
        "id": "012e3456-e89b-12d3-a456-426614174005",
        "debt_name": "Credit Card 1",
        "debt_type": "credit_card",
        "original_balance": 10000.00,
        "current_balance": 8500.00,
        "interest_rate": 0.1899,
        "minimum_payment": 250.00,
        "payment_due_date": 15,
        "priority_order": 1,
        "optimization_order": 1,
        "payoff_target_date": "2026-03-15",
        "is_active": true,
        "created_at": "2025-01-15T10:30:00Z"
      },
      {
        "id": "123e4567-e89b-12d3-a456-426614174006",
        "debt_name": "Auto Loan",
        "debt_type": "auto_loan",
        "original_balance": 25000.00,
        "current_balance": 18500.00,
        "interest_rate": 0.0425,
        "minimum_payment": 450.00,
        "payment_due_date": 1,
        "term_months": 60,
        "remaining_months": 42,
        "priority_order": 2,
        "optimization_order": 2,
        "is_active": true
      }
    ],
    "total_count": 2,
    "total_balance": 27000.00,
    "total_minimum_payment": 700.00
  }
}
```

### POST /debts

Add a new debt.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "debt_name": "Personal Loan",
  "debt_type": "personal_loan",
  "original_balance": 15000.00,
  "current_balance": 15000.00,
  "interest_rate": 0.0875,
  "minimum_payment": 300.00,
  "payment_due_date": 20,
  "term_months": 60,
  "notes": "Debt consolidation loan"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Debt added successfully",
  "data": {
    "id": "234e5678-e89b-12d3-a456-426614174007",
    "debt_name": "Personal Loan",
    "created_at": "2025-07-29T16:45:00Z"
  }
}
```

### PUT /debts/{debt_id}

Update debt information.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "current_balance": 14500.00,
  "minimum_payment": 280.00,
  "priority_order": 1
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Debt updated successfully",
  "data": {
    "id": "234e5678-e89b-12d3-a456-426614174007",
    "updated_at": "2025-07-29T17:00:00Z"
  }
}
```

### DELETE /debts/{debt_id}

Delete a debt.

**Headers:** `Authorization: Bearer <access_token>`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Debt deleted successfully"
}
```

## Velocity Banking Endpoints

### GET /velocity-cycles

Get user's velocity banking cycles.

**Headers:** `Authorization: Bearer <access_token>`

**Query Parameters:**
- `status` (optional): Filter by status (active, completed, cancelled)
- `limit` (optional): Number of results to return (default: 20)
- `offset` (optional): Number of results to skip (default: 0)

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "cycles": [
      {
        "id": "345e6789-e89b-12d3-a456-426614174008",
        "cycle_number": 15,
        "start_date": "2025-07-15",
        "end_date": "2025-07-29",
        "paycheck_amount": 4500.00,
        "total_debt_payments": 3200.00,
        "total_expenses": 1800.00,
        "interest_saved": 125.50,
        "cycle_effectiveness": 0.8756,
        "status": "completed",
        "created_at": "2025-07-15T09:00:00Z"
      },
      {
        "id": "456e7890-e89b-12d3-a456-426614174009",
        "cycle_number": 16,
        "start_date": "2025-07-29",
        "paycheck_amount": 4500.00,
        "total_debt_payments": 1500.00,
        "total_expenses": 800.00,
        "status": "active",
        "created_at": "2025-07-29T09:00:00Z"
      }
    ],
    "total_count": 16,
    "total_interest_saved": 1875.25
  }
}
```

### POST /velocity-cycles

Start a new velocity banking cycle.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "paycheck_amount": 4500.00,
  "start_date": "2025-07-29",
  "notes": "Bi-weekly paycheck cycle"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Velocity cycle started successfully",
  "data": {
    "id": "567e8901-e89b-12d3-a456-426614174010",
    "cycle_number": 17,
    "start_date": "2025-07-29",
    "status": "active",
    "created_at": "2025-07-29T17:15:00Z"
  }
}
```

### PUT /velocity-cycles/{cycle_id}/complete

Complete a velocity banking cycle.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "end_date": "2025-08-12",
  "total_expenses": 1950.00,
  "notes": "Cycle completed successfully"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Velocity cycle completed successfully",
  "data": {
    "id": "567e8901-e89b-12d3-a456-426614174010",
    "status": "completed",
    "cycle_effectiveness": 0.8923,
    "interest_saved": 142.75,
    "updated_at": "2025-08-12T18:00:00Z"
  }
}
```

## Financial Calculations Endpoints

### POST /calculations/debt-optimization

Calculate optimal debt payoff strategy.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "strategy": "velocity_banking",
  "extra_payment_amount": 1000.00,
  "target_payoff_date": "2027-12-31"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "strategy": "velocity_banking",
    "total_interest_saved": 12450.00,
    "time_saved_months": 18,
    "projected_payoff_date": "2027-06-15",
    "debt_sequence": [
      {
        "debt_id": "012e3456-e89b-12d3-a456-426614174005",
        "debt_name": "Credit Card 1",
        "payoff_order": 1,
        "projected_payoff_date": "2026-03-15",
        "total_payments": 9125.50
      },
      {
        "debt_id": "123e4567-e89b-12d3-a456-426614174006",
        "debt_name": "Auto Loan",
        "payoff_order": 2,
        "projected_payoff_date": "2027-06-15",
        "total_payments": 19875.25
      }
    ]
  }
}
```

### POST /calculations/scenario-comparison

Compare different financial scenarios.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "scenarios": [
    {
      "name": "Velocity Banking",
      "strategy": "velocity_banking",
      "extra_payment": 1000.00
    },
    {
      "name": "Debt Avalanche",
      "strategy": "debt_avalanche",
      "extra_payment": 1000.00
    },
    {
      "name": "Minimum Payments",
      "strategy": "minimum_only",
      "extra_payment": 0.00
    }
  ]
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "comparison": [
      {
        "scenario_name": "Velocity Banking",
        "total_interest": 8750.00,
        "total_payments": 35750.00,
        "payoff_date": "2027-06-15",
        "time_to_freedom_months": 30,
        "monthly_cash_flow": 2800.00
      },
      {
        "scenario_name": "Debt Avalanche",
        "total_interest": 9850.00,
        "total_payments": 36850.00,
        "payoff_date": "2027-09-15",
        "time_to_freedom_months": 33,
        "monthly_cash_flow": 2800.00
      },
      {
        "scenario_name": "Minimum Payments",
        "total_interest": 21200.00,
        "total_payments": 48200.00,
        "payoff_date": "2032-03-15",
        "time_to_freedom_months": 81,
        "monthly_cash_flow": 3500.00
      }
    ],
    "best_scenario": "Velocity Banking",
    "savings_vs_minimum": 12450.00
  }
}
```

## Transaction Endpoints

### GET /transactions

Get user's transaction history.

**Headers:** `Authorization: Bearer <access_token>`

**Query Parameters:**
- `start_date` (optional): Filter transactions from date (YYYY-MM-DD)
- `end_date` (optional): Filter transactions to date (YYYY-MM-DD)
- `type` (optional): Filter by transaction type
- `category` (optional): Filter by category
- `limit` (optional): Number of results (default: 50)
- `offset` (optional): Number of results to skip (default: 0)

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": "678e9012-e89b-12d3-a456-426614174011",
        "transaction_date": "2025-07-29",
        "amount": 4500.00,
        "transaction_type": "income",
        "category": "salary",
        "description": "Bi-weekly paycheck",
        "merchant_name": "Tech Corp Inc",
        "is_recurring": true,
        "created_at": "2025-07-29T09:00:00Z"
      },
      {
        "id": "789e0123-e89b-12d3-a456-426614174012",
        "transaction_date": "2025-07-28",
        "amount": -250.00,
        "transaction_type": "debt_payment",
        "category": "credit_card",
        "description": "Credit card payment",
        "debt_id": "012e3456-e89b-12d3-a456-426614174005",
        "is_automated": true,
        "created_at": "2025-07-28T15:30:00Z"
      }
    ],
    "total_count": 156,
    "summary": {
      "total_income": 9000.00,
      "total_expenses": -3250.00,
      "total_debt_payments": -1500.00,
      "net_cash_flow": 4250.00
    }
  }
}
```

### POST /transactions

Add a new transaction.

**Headers:** `Authorization: Bearer <access_token>`

**Request Body:**
```json
{
  "transaction_date": "2025-07-29",
  "amount": -85.50,
  "transaction_type": "expense",
  "category": "groceries",
  "description": "Weekly grocery shopping",
  "merchant_name": "SuperMarket Plus",
  "bank_account_id": "789e0123-e89b-12d3-a456-426614174002"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Transaction added successfully",
  "data": {
    "id": "890e1234-e89b-12d3-a456-426614174013",
    "transaction_date": "2025-07-29",
    "amount": -85.50,
    "created_at": "2025-07-29T18:00:00Z"
  }
}
```

## Dashboard Endpoints

### GET /dashboard/summary

Get comprehensive dashboard summary.

**Headers:** `Authorization: Bearer <access_token>`

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "financial_overview": {
      "net_worth": 25000.00,
      "total_debt": 27000.00,
      "total_assets": 52000.00,
      "debt_to_income_ratio": 0.36,
      "emergency_fund_months": 2.4
    },
    "velocity_banking": {
      "current_cycle": {
        "id": "567e8901-e89b-12d3-a456-426614174010",
        "cycle_number": 17,
        "progress_percentage": 65.5,
        "days_remaining": 8,
        "projected_interest_saved": 135.25
      },
      "total_interest_saved": 1875.25,
      "projected_debt_free_date": "2027-06-15",
      "acceleration_months": 18
    },
    "recent_activity": {
      "last_transaction": {
        "date": "2025-07-29",
        "amount": 4500.00,
        "type": "income",
        "description": "Bi-weekly paycheck"
      },
      "upcoming_payments": [
        {
          "debt_name": "Credit Card 1",
          "amount": 250.00,
          "due_date": "2025-08-15"
        }
      ]
    },
    "goals_progress": {
      "debt_reduction": {
        "target": 27000.00,
        "current": 27000.00,
        "progress_percentage": 0.0
      },
      "emergency_fund": {
        "target": 18750.00,
        "current": 5000.00,
        "progress_percentage": 26.7
      }
    }
  }
}
```

## Error Responses

All endpoints return consistent error responses with appropriate HTTP status codes.

### 400 Bad Request
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "email": ["Invalid email format"],
      "password": ["Password must be at least 8 characters"]
    }
  }
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Invalid or expired authentication token"
  }
}
```

### 403 Forbidden
```json
{
  "success": false,
  "error": {
    "code": "FORBIDDEN",
    "message": "Insufficient permissions to access this resource"
  }
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Requested resource not found"
  }
}
```

### 429 Too Many Requests
```json
{
  "success": false,
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Too many requests. Please try again later.",
    "retry_after": 60
  }
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": {
    "code": "INTERNAL_ERROR",
    "message": "An unexpected error occurred. Please try again later.",
    "request_id": "req_123456789"
  }
}
```

## Rate Limiting

API endpoints are protected with rate limiting to ensure fair usage and system stability:

- **Authentication endpoints:** 5 requests per minute per IP
- **Data modification endpoints:** 60 requests per minute per user
- **Data retrieval endpoints:** 120 requests per minute per user
- **Calculation endpoints:** 30 requests per minute per user

Rate limit headers are included in all responses:
```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1627846261
```

## Pagination

List endpoints support pagination with consistent parameters:

**Query Parameters:**
- `limit`: Number of items per page (default: 20, max: 100)
- `offset`: Number of items to skip (default: 0)

**Response Format:**
```json
{
  "success": true,
  "data": {
    "items": [...],
    "pagination": {
      "total_count": 156,
      "limit": 20,
      "offset": 0,
      "has_next": true,
      "has_previous": false
    }
  }
}
```

This comprehensive API specification provides the foundation for building a robust and scalable velocity banking application with clear, consistent, and well-documented endpoints for all core functionality.

