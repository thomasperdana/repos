import os
import sys
from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from datetime import timedelta

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from models import db
    from routes.auth import auth_bp
    from routes.user import user_bp
    from routes.financial_profile import financial_profile_bp
    from routes.bank_accounts import bank_accounts_bp
    from routes.debts import debts_bp
    from routes.velocity_cycles import velocity_cycles_bp
    from routes.transactions import transactions_bp
    from routes.calculations import calculations_bp
    from routes.dashboard import dashboard_bp
except ImportError:
    # Fallback for when running from different directory
    from src.models import db
    from src.routes.auth import auth_bp
    from src.routes.user import user_bp
    from src.routes.financial_profile import financial_profile_bp
    from src.routes.bank_accounts import bank_accounts_bp
    from src.routes.debts import debts_bp
    from src.routes.velocity_cycles import velocity_cycles_bp
    from src.routes.transactions import transactions_bp
    from src.routes.calculations import calculations_bp
    from src.routes.dashboard import dashboard_bp


def create_app():
    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'velocity-banking-secret-key-2024')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///velocity_banking.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'jwt-velocity-banking-secret-2024')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
    app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)
    
    # Initialize extensions
    db.init_app(app)
    CORS(app, origins="*", supports_credentials=True)
    jwt = JWTManager(app)
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(user_bp, url_prefix='/api/users')
    app.register_blueprint(financial_profile_bp, url_prefix='/api/financial-profile')
    app.register_blueprint(bank_accounts_bp, url_prefix='/api/bank-accounts')
    app.register_blueprint(debts_bp, url_prefix='/api/debts')
    app.register_blueprint(velocity_cycles_bp, url_prefix='/api/velocity-cycles')
    app.register_blueprint(transactions_bp, url_prefix='/api/transactions')
    app.register_blueprint(calculations_bp, url_prefix='/api/calculations')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    
    # Health check endpoint
    @app.route('/api/health')
    def health_check():
        return jsonify({
            'status': 'healthy',
            'service': 'velocity-banking-api',
            'version': '1.0.0'
        })
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            'success': False,
            'error': {
                'code': 'NOT_FOUND',
                'message': 'The requested resource was not found'
            }
        }), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({
            'success': False,
            'error': {
                'code': 'INTERNAL_ERROR',
                'message': 'An internal server error occurred'
            }
        }), 500
    
    # JWT error handlers
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return jsonify({
            'success': False,
            'error': {
                'code': 'TOKEN_EXPIRED',
                'message': 'The token has expired'
            }
        }), 401
    
    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return jsonify({
            'success': False,
            'error': {
                'code': 'INVALID_TOKEN',
                'message': 'The token is invalid'
            }
        }), 401
    
    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return jsonify({
            'success': False,
            'error': {
                'code': 'TOKEN_REQUIRED',
                'message': 'A valid token is required'
            }
        }), 401
    
    return app


if __name__ == '__main__':
    app = create_app()
    
    # Create tables if they don't exist
    with app.app_context():
        db.create_all()
    
    # Run the application
    app.run(host='0.0.0.0', port=5000, debug=True)

