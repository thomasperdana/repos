-- Schema for the voice‑AI marketing & sales loop.

-- Leads table: stores raw lead information captured from the landing page.
create table if not exists public.leads (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  email text not null,
  phone text not null,
  status text not null default 'new',
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Customers table: stores paying customers who have completed checkout.
create table if not exists public.customers (
  id uuid primary key default uuid_generate_v4(),
  lead_id uuid references public.leads(id) on delete set null,
  email text not null,
  stripe_customer_id text,
  subscription_plan text,
  status text not null default 'pending',
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Enable real‑time notifications on leads insertions.  Supabase will send
-- webhook events to configured webhooks when new rows are inserted.  You can
-- register these webhooks in the Supabase dashboard.