import { serve } from 'https://deno.land/std/http/server.ts';
import { Stripe } from 'https://esm.sh/stripe@12.6.0?target=deno';

/**
 * Supabase Edge function to handle Stripe webhook events.  The function verifies
 * the signature of incoming events and updates the `customers` table based on
 * successful payments.  Configure your Stripe webhook to send the events
 * `checkout.session.completed`, `invoice.payment_succeeded` and related events.
 */
serve(async (req) => {
  const body = await req.text();
  const signature = req.headers.get('stripe-signature');
  const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');
  const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
  if (!signature || !webhookSecret || !stripeSecretKey) {
    return new Response('Missing Stripe configuration', { status: 500 });
  }
  const stripe = new Stripe(stripeSecretKey, { apiVersion: '2023-10-16' });
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return new Response('Invalid signature', { status: 400 });
  }

  // Supabase admin client (service key is available in environment variables)
  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !supabaseServiceKey) {
    console.error('Missing Supabase service credentials');
    return new Response('Server misconfiguration', { status: 500 });
  }
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      const customerEmail = session.customer_details?.email;
      const customerId = session.customer as string;
      if (customerEmail) {
        // Find existing lead and insert/update customer record
        const { data: lead } = await supabase
          .from('leads')
          .select('id')
          .eq('email', customerEmail)
          .limit(1)
          .maybeSingle();
        let leadId: string | null = null;
        if (lead) leadId = lead.id;
        await supabase.from('customers').upsert({
          email: customerEmail,
          lead_id: leadId,
          stripe_customer_id: customerId,
          status: 'paid',
        }, { onConflict: 'email' });
      }
      break;
    }
    case 'invoice.payment_succeeded': {
      const invoice = event.data.object as Stripe.Invoice;
      const customerId = invoice.customer as string;
      // Update customer status to active
      await supabase
        .from('customers')
        .update({ status: 'active' })
        .eq('stripe_customer_id', customerId);
      break;
    }
    default:
      // Ignore other events
      break;
  }
  return new Response('Webhook processed', { status: 200 });
});

// Import Supabase client for Deno
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.42.0';