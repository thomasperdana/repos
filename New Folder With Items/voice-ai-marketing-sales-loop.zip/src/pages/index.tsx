import { useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import supabase from '../lib/supabaseClient';

export default function Home() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const { error: insertError } = await supabase.from('leads').insert({
        name,
        email,
        phone,
        status: 'new',
      });
      if (insertError) throw insertError;
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <>
      <Head>
        <title>Voice AI Agent – Automated Marketing & Sales Loop</title>
        <meta name="description" content="Promote and sell your voice AI agent with an automated marketing and sales loop built on Supabase, Go High Level, n8n and Stripe." />
      </Head>
      <main className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-4">Voice AI Agent</h1>
        <p className="text-center max-w-2xl mb-8 text-gray-700">
          Grow your business with an intelligent voice agent.  This demo showcases a fully automated marketing & sales loop that captures leads, nurtures them and collects payments with minimal manual effort.
        </p>
        {!submitted ? (
          <form onSubmit={handleSubmit} className="bg-white shadow-md rounded p-6 w-full max-w-md">
            <h2 className="text-2xl font-semibold mb-4">Get early access</h2>
            <div className="mb-4">
              <label htmlFor="name" className="block text-gray-700 text-sm font-bold mb-2">Name</label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-700 text-sm font-bold mb-2">Email</label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="phone" className="block text-gray-700 text-sm font-bold mb-2">Phone</label>
              <input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            </div>
            {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
            <button type="submit" className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full">
              Register
            </button>
          </form>
        ) : (
          <div className="bg-white shadow-md rounded p-6 w-full max-w-md text-center">
            <h2 className="text-2xl font-semibold mb-2">Thank you!</h2>
            <p className="mb-4">Your details have been received.  We’ll be in touch with a personal demo shortly.</p>
            <p>
              Ready to purchase?  <Link href="/api/checkout"><a className="text-blue-600 underline">Proceed to checkout</a></Link>
            </p>
          </div>
        )}
      </main>
    </>
  );
}