import Link from 'next/link';

export default function Success() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-green-50 p-4">
      <div className="bg-white p-6 rounded shadow-md text-center">
        <h1 className="text-3xl font-bold mb-2">Payment Successful</h1>
        <p className="mb-4">Thank you for purchasing the Voice AI Agent!  Your order is confirmed.</p>
        <Link href="/dashboard">
          <a className="text-blue-600 underline">Go to your dashboard</a>
        </Link>
      </div>
    </main>
  );
}