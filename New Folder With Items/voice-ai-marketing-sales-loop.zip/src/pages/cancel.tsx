import Link from 'next/link';

export default function Cancel() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-red-50 p-4">
      <div className="bg-white p-6 rounded shadow-md text-center">
        <h1 className="text-3xl font-bold mb-2">Payment Cancelled</h1>
        <p className="mb-4">Your payment was cancelled.  You can try again any time.</p>
        <Link href="/">
          <a className="text-blue-600 underline">Return to home</a>
        </Link>
      </div>
    </main>
  );
}