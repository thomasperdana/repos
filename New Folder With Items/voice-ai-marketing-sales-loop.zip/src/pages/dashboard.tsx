import { useEffect, useState } from 'react';
import { useUser, useSupabaseClient } from '@supabase/auth-helpers-react';
import supabase from '../lib/supabaseClient';
import Link from 'next/link';

export default function Dashboard() {
  const user = useUser();
  const supabaseClient = useSupabaseClient();
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    if (user) {
      // Fetch additional profile data if needed
      const loadProfile = async () => {
        const { data, error } = await supabaseClient
          .from('customers')
          .select('*')
          .eq('email', user.email)
          .single();
        if (!error) setProfile(data);
      };
      loadProfile();
    }
  }, [user, supabaseClient]);

  if (!user) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
        <div className="bg-white p-6 rounded shadow-md text-center">
          <h1 className="text-3xl font-bold mb-2">Please sign in</h1>
          <Link href="/">
            <a className="text-blue-600 underline">Return to home</a>
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-start bg-gray-50 p-4">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-2xl">
        <h1 className="text-2xl font-bold mb-4">Welcome, {user.email}</h1>
        {profile ? (
          <>
            <p>Status: {profile.status}</p>
            <p>Subscription: {profile.subscription_plan || 'N/A'}</p>
          </>
        ) : (
          <p>We are preparing your account details.  Please check back later.</p>
        )}
      </div>
    </main>
  );
}