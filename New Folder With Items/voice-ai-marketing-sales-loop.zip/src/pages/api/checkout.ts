import type { NextApiRequest, NextApiResponse } from 'next';
import { stripe } from '../../lib/stripe';

/**
 * API route that creates a Stripe Checkout session for the voice AI agent.
 * Expects a POST request containing a `priceId` (the Stripe price identifier).
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const { priceId } = req.body;
  if (!priceId) {
    return res.status(400).json({ error: 'Missing priceId' });
  }
  try {
    const host = process.env.APP_URL || 'http://localhost:3000';
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${host}/success`,
      cancel_url: `${host}/cancel`,
    });
    return res.status(200).json({ url: session.url });
  } catch (err: any) {
    console.error('Error creating checkout session:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}