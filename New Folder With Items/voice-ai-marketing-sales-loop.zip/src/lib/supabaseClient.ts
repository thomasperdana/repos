import { createBrowserSupabaseClient } from '@supabase/auth-helpers-nextjs';

/**
 * Initializes a Supabase client for use in the browser.  The helper automatically
 * picks up `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` from
 * environment variables and handles authentication state, including cookies
 * when using Next.js API routes.
 */
export const supabase = createBrowserSupabaseClient();

export default supabase;