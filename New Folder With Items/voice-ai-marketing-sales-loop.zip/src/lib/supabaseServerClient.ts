import { createClient } from '@supabase/supabase-js';

// Create a Supabase client on the server.  We read the URL and service key
// from environment variables.  In production, store your service key securely
// and do not expose it to the client.
const supabaseServer = () => {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!url || !key) {
    throw new Error('Missing SUPABASE_URL or service key in environment variables');
  }
  return createClient(url, key);
};

export default supabaseServer;