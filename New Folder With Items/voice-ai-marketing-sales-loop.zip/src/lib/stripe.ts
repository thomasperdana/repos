import Stripe from 'stripe';

// Initialize a Stripe client using the secret key.  This module is only imported
// in API routes running on the server, so the secret key is never exposed to the client.
const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
if (!stripeSecretKey) {
  throw new Error('Missing STRIPE_SECRET_KEY environment variable');
}

export const stripe = new Stripe(stripeSecretKey, {
  apiVersion: '2023-10-16',
});