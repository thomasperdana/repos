# Voice‑AI Marketing & Sales Loop

This repository provides a reference implementation of an automated marketing and sales loop built around a **voice‑enabled AI agent**.  The goal of the project is to demonstrate how to orchestrate leads, video creatives, payments and customer management using a modern tool‑chain that includes **Supabase**, **Go High Level**, **n8n**, **Wan 2.2**, **Next.js**, **Stripe** and **Cloudflare**.

## Overview

The automation begins when a visitor arrives on the landing page.  Prospects can:

* **Sign up or inquire via the Next.js front end** – registration is powered by Supabase Auth, which provides secure authentication and session management.  Basic details such as name, email and phone are collected and written to the `leads` table in Supabase.
* **Book a demo or purchase the voice AI agent** – integration with Stripe allows prospects to complete a checkout flow.  When a payment succeeds, a webhook updates Supabase and synchronises customer status in Go High Level.
* **Receive timely follow‑ups** – an n8n workflow listens for new rows in Supabase and uses the Go High Level API to upsert contacts, add them to a pipeline and send emails/SMS.  Additional workflows can trigger Wan 2.2 (via Replicate) to generate video creatives for marketing campaigns.

Automation is orchestrated using **n8n**.  As the HighLevel/Supabase integration page explains, you can create a new workflow in the n8n interface, pick a trigger (an app event, a schedule, a webhook call, another workflow or a manual trigger) and build the sequence of actions【398120233545847†L68-L72】.  Custom integrations are built by selecting nodes for HighLevel and Supabase or by using the HTTP Request node, which lets you query any REST API【398120233545847†L79-L82】.  HighLevel is a complete sales and marketing platform that lets agencies generate leads, build websites and surveys, and run marketing automations【398120233545847†L154-L167】.  Supabase, meanwhile, provides an open‑source backend with PostgreSQL database storage and simple authentication services【398120233545847†L166-L168】.  n8n bridges these services so data flows seamlessly.

### Repository structure

```
voice-ai-marketing-sales-loop/
├── README.md                   – you are here
├── package.json                – dependencies and scripts for the Next.js app
├── next.config.js              – Next.js configuration (optional)
├── .env.example                – environment variable template
├── src/
│   ├── pages/
│   │   ├── _app.tsx            – global providers
│   │   ├── index.tsx           – landing page with signup form
│   │   ├── dashboard.tsx       – simple authenticated dashboard
│   │   ├── api/
│   │   │   └── checkout.ts     – API route creating Stripe checkout sessions
│   │   ├── success.tsx         – Stripe checkout success page
│   │   └── cancel.tsx          – Stripe checkout cancel page
│   └── lib/
│       ├── supabaseClient.ts   – helper for initializing the Supabase client
│       └── stripe.ts           – helper for initializing the Stripe client
├── supabase/
│   ├── schema.sql              – database schema for leads and customers
│   └── functions/
│       └── stripe-webhook/
│           └── index.ts        – Supabase Edge function handling Stripe webhooks
├── n8n/
│   ├── new-lead-workflow.json  – n8n workflow: creates HighLevel contact on new lead
│   └── payment-workflow.json   – n8n workflow: updates HighLevel on payment
└── LICENSE
```

## Getting started

1. **Clone the repository** and install dependencies:
   ```bash
   git clone https://github.com/your-org/voice-ai-marketing-sales-loop.git
   cd voice-ai-marketing-sales-loop
   npm install
   ```

2. **Copy the `.env.example` file to `.env.local`** and fill in the environment variables.  You will need credentials for Supabase, Stripe, Go High Level and Replicate (for the Wan 2.2 integration).  See comments in the example file for details.

3. **Initialize your Supabase project**.  Create a new project in the Supabase dashboard and run the SQL in `supabase/schema.sql` to create the required tables.  Supabase offers generous free tier limits and includes a PostgreSQL database along with built‑in authentication【398120233545847†L166-L168】.  For more details on creating a project, follow the steps described in the Next.js/Supabase/Stripe tutorial: sign up at supabase.com, create an organization and project, choose the free plan and wait for provisioning【355707446821983†L181-L199】.

4. **Deploy the Stripe webhook function**.  Use the Supabase CLI to deploy `supabase/functions/stripe-webhook` as an Edge function.  This function verifies incoming Stripe events and updates the `customers` table accordingly.  Configure a webhook in your Stripe dashboard pointing to the function’s URL and add the webhook secret to your `.env.local` file.  For guidance on setting up API keys and webhooks, refer to the integration guide that describes copying your publishable and secret keys and adding the webhook endpoint【355707446821983†L232-L270】.

5. **Import the n8n workflows**.  Export the JSON files in `n8n/` into your n8n instance.  Adjust credentials in the credentials manager and set the webhook URLs or Supabase triggers accordingly.  These workflows automate contact creation in Go High Level when a new lead is inserted and update the contact status on successful payment.

6. **Run the Next.js app locally**:
   ```bash
   npm run dev
   ```
   Visit `http://localhost:3000` to open your landing page.  New signups will be stored in Supabase and will trigger the n8n automation.  After checkout, your Stripe success page will update the customer status.

## How it works

### Landing page and Supabase

The `index.tsx` page offers a simple landing page with a hero section, a feature list and a registration form.  When a user submits their details, the page calls Supabase to create a new row in the `leads` table.  Supabase’s realtime features can notify external services about this insertion via webhooks.  This triggers the n8n workflow to upsert the lead into Go High Level.

### Stripe integration

Stripe is used to handle payments.  The `/api/checkout.ts` API route creates a checkout session using your secret key and returns the URL.  A success page confirms the purchase and can offer next steps (e.g. onboarding instructions).  A cancel page provides a fallback if the user abandons checkout.  The Supabase Edge function `stripe-webhook` listens for events such as `checkout.session.completed` or `invoice.payment_succeeded` and updates your database.  The Next.js, Supabase and Stripe integration pattern follows the steps described in the Tempo tutorial: select Next.js as your framework, choose Supabase for database/auth and Stripe for payments; Supabase provides pre‑built authentication flows while Stripe handles subscription billing and offers a webhook integration for event handling【355707446821983†L147-L160】.

### n8n workflows

Two sample n8n workflows are included:

* **New Lead Workflow (`n8n/new-lead-workflow.json`)** – Triggered by a Supabase webhook (or via the HTTP Request node), this flow extracts lead details and sends an HTTP POST request to the Go High Level API to create or update a contact.  HighLevel’s supported actions include creating contacts, opportunities and tasks【398120233545847†L84-L124】.  After creation, the workflow can send a welcome email or SMS using HighLevel’s automation tools.

* **Payment Workflow (`n8n/payment-workflow.json`)** – Triggered after Stripe webhook events update Supabase, this flow checks the customer’s payment status.  If payment is successful, it updates the contact in Go High Level to move them to the next pipeline stage.  It can also trigger additional automations such as sending onboarding emails or generating a personalised video using Wan 2.2.

### Wan 2.2 integration

Wan 2.2 is a state‑of‑the‑art video generation model.  The included n8n workflow demonstrates how to call the model via the Replicate API: the workflow handles authentication, parameter configuration and error handling to automatically generate marketing videos【948556516769745†L65-L75】.  This allows you to create high‑quality visuals for campaigns without manual intervention【948556516769745†L80-L86】.

## License

This project is released under the MIT license.