/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  reactStrictMode: true,
  // Allow loading images from external domains (e.g. if Wan 2.2 returns videos hosted elsewhere)
  images: {
    domains: ['images.unsplash.com', 'n8niostorageaccount.blob.core.windows.net'],
  },
};

module.exports = nextConfig;