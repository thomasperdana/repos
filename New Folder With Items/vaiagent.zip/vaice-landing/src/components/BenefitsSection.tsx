import React from 'react';
import { Clock, MessageCircle, Calendar, CheckCircle, Globe, Zap } from 'lucide-react';

interface BenefitCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const BenefitCard: React.FC<BenefitCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 hover:bg-gray-700/50 transition-all duration-300 transform hover:scale-105 hover:shadow-xl hover:shadow-emerald-500/10">
      <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-br from-emerald-500 to-blue-500 rounded-lg mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-white mb-3">{title}</h3>
      <p className="text-gray-300 leading-relaxed">{description}</p>
    </div>
  );
};

const BenefitsSection: React.FC = () => {
  const benefits = [
    {
      icon: <Clock className="w-6 h-6 text-white" />,
      title: '24/7 Availability',
      description: 'Your AI agent never sleeps. Accept appointments around the clock, even outside business hours, ensuring you never miss a potential booking.'
    },
    {
      icon: <MessageCircle className="w-6 h-6 text-white" />,
      title: 'Natural Conversations',
      description: 'Advanced AI understands context, handles complex requests, and speaks naturally with your customers, creating genuine human-like interactions.'
    },
    {
      icon: <Globe className="w-6 h-6 text-white" />,
      title: 'Multi-Service Support',
      description: 'Perfect for healthcare, beauty salons, consulting, restaurants, and any service-based business that relies on appointments.'
    },
    {
      icon: <CheckCircle className="w-6 h-6 text-white" />,
      title: 'Instant Confirmation',
      description: 'Customers receive immediate booking confirmations with all details, reducing no-shows and improving customer satisfaction.'
    },
    {
      icon: <Zap className="w-6 h-6 text-white" />,
      title: 'No Hold Times',
      description: 'Eliminate frustrating phone menus and hold times. Customers connect instantly and get their appointments scheduled in seconds.'
    },
    {
      icon: <Calendar className="w-6 h-6 text-white" />,
      title: 'Smart Scheduling',
      description: 'Intelligent calendar integration automatically finds the best available slots and handles rescheduling with ease.'
    }
  ];

  return (
    <section id="benefits" className="py-20 bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Making Voice AI
            <span className="block bg-gradient-to-r from-emerald-400 to-blue-500 bg-clip-text text-transparent">
              Simple and Accessible
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Discover how Vaice transforms the way your business handles appointments, 
            creating seamless experiences for both you and your customers.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {benefits.map((benefit, index) => (
            <BenefitCard
              key={index}
              icon={benefit.icon}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
        
        <div className="text-center mt-16">
          <div className="inline-flex items-center space-x-2 bg-emerald-500/10 px-6 py-3 rounded-full border border-emerald-500/20">
            <CheckCircle className="w-5 h-5 text-emerald-400" />
            <span className="text-emerald-400 font-medium">Trusted by thousands of businesses worldwide</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;