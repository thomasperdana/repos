import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-gray-900/95 backdrop-blur-sm border-b border-gray-800">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center">
          {/* Logo */}
          <div className="text-2xl font-bold text-white">
            Vaice
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;