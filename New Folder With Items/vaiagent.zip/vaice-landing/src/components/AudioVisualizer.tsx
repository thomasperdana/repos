import React, { useEffect, useState } from 'react';

interface AudioVisualizerProps {
  audioData: number[];
  isActive: boolean;
}

const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ audioData, isActive }) => {
  const [animationHeights, setAnimationHeights] = useState<number[]>(new Array(32).fill(15));
  
  const colors = [
    'from-purple-500 to-purple-600',
    'from-blue-500 to-blue-600',
    'from-emerald-500 to-emerald-600',
    'from-yellow-500 to-yellow-600',
    'from-orange-500 to-orange-600',
    'from-pink-500 to-pink-600',
    'from-indigo-500 to-indigo-600',
    'from-teal-500 to-teal-600'
  ];

  // Create continuous animation effect when not recording
  useEffect(() => {
    if (!isActive) {
      const interval = setInterval(() => {
        setAnimationHeights(prevHeights => {
          return prevHeights.map((_, index) => {
            // Each bar has its own animation cycle with different speeds
            const time = Date.now() / 1000;
            const speed = 0.5 + (index * 0.1); // Different speeds for each bar
            const baseHeight = 10 + Math.sin(time * speed + index) * 20; // Adjusted for smaller container
            const variation = Math.sin(time * speed * 1.5 + index * 0.5) * 12; // Adjusted variation
            return Math.max(baseHeight + variation, 6); // Minimum height 6px
          });
        });
      }, 100); // Update every 100ms for smooth animation
      
      return () => clearInterval(interval);
    }
  }, [isActive]);

  const getBarHeight = (value: number, index: number) => {
    if (isActive) {
      return Math.max(value * 120 + 15, 6); // Use real audio data when recording - adjusted for smaller container
    }
    return animationHeights[index]; // Use animated heights when not recording
  };

  return (
    <div className="flex items-end justify-center space-x-2 md:space-x-3 h-32 md:h-40 p-4">
      {audioData.map((value, index) => {
        const height = getBarHeight(value, index);
        const colorClass = colors[index % colors.length];
        
        return (
          <div
            key={index}
            className={`w-2 md:w-3 rounded-t-full bg-gradient-to-t ${colorClass} shadow-lg`}
            style={{
              height: `${height}px`,
              filter: isActive ? 'brightness(1.2)' : 'brightness(0.9)',
              boxShadow: isActive 
                ? `0 0 20px rgba(${index % 2 === 0 ? '16, 185, 129' : '59, 130, 246'}, 0.4)` 
                : `0 0 10px rgba(${index % 2 === 0 ? '16, 185, 129' : '59, 130, 246'}, 0.2)`,
              transition: isActive ? 'height 0.1s linear' : 'height 0.3s ease-in-out'
            }}
          />
        );
      })}
    </div>
  );
};

export default AudioVisualizer;