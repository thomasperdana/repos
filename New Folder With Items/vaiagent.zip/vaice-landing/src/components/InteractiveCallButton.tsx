import React from 'react';
import { Mic, MicOff } from 'lucide-react';

interface InteractiveCallButtonProps {
  isRecording: boolean;
  onClick: () => void;
  callStatus: 'idle' | 'connecting' | 'connected' | 'ended';
}

const InteractiveCallButton: React.FC<InteractiveCallButtonProps> = ({ 
  isRecording, 
  onClick, 
  callStatus 
}) => {
  const getButtonText = () => {
    if (callStatus === 'connecting') return 'Connecting...';
    if (isRecording || callStatus === 'connected') return 'End call';
    return 'Test Restaurant Booking Flow Now';
  };

  const getButtonStyles = () => {
    if (callStatus === 'connecting') {
      return {
        backgroundColor: 'rgb(249, 115, 22)', // orange-500
        boxShadow: '0 4px 14px 0 rgba(249, 115, 22, 0.4)'
      };
    }
    if (isRecording || callStatus === 'connected') {
      return {
        backgroundColor: 'rgb(239, 68, 68)', // red-500
        boxShadow: '0 4px 14px 0 rgba(239, 68, 68, 0.4)'
      };
    }
    return {
      backgroundColor: 'rgb(16, 185, 129)', // emerald-500
      boxShadow: '0 4px 14px 0 rgba(16, 185, 129, 0.3)'
    };
  };

  return (
    <button
      onClick={onClick}
      className={`
        relative px-8 py-4 md:px-12 md:py-6 rounded-lg font-semibold text-white
        text-lg md:text-xl transition-all duration-300 transform hover:scale-105
        focus:outline-none focus:ring-4 focus:ring-white/20
        flex items-center justify-center space-x-3 min-w-[280px] md:min-w-[320px]
      `}
      style={getButtonStyles()}
      disabled={false}
      aria-label={isRecording || callStatus === 'connected' ? 'End VAPI call' : 'Start VAPI call'}
      aria-pressed={isRecording || callStatus === 'connected'}
    >
      <div className="flex items-center space-x-3">
        {(isRecording || callStatus === 'connected') ? (
          <MicOff className="w-6 h-6" />
        ) : callStatus === 'connecting' ? (
          <div className="w-6 h-6 animate-spin rounded-full border-2 border-white border-t-transparent" />
        ) : (
          <Mic className="w-6 h-6" />
        )}
        <span>{getButtonText()}</span>
      </div>
    </button>
  );
};

export default InteractiveCallButton;