import React, { useState, useEffect, useRef } from 'react';
import Vapi from '@vapi-ai/web';
import AudioVisualizer from './AudioVisualizer';
import InteractiveCallButton from './InteractiveCallButton';

// VAPI Configuration
const VAPI_PUBLIC_API_KEY = '4eac8e19-3e9f-4974-aa8a-42043d5b85ea';
const VAPI_ASSISTANT_ID = '5845d09e-3472-4550-94da-0cb758a14eba';

const HeroSection: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [audioData, setAudioData] = useState<number[]>(new Array(32).fill(0));
  const [callStatus, setCallStatus] = useState<'idle' | 'connecting' | 'connected' | 'ended'>('idle');
  const vapiRef = useRef<any>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Initialize VAPI
  useEffect(() => {
    vapiRef.current = new Vapi(VAPI_PUBLIC_API_KEY);
    
    // Set up VAPI event listeners
    vapiRef.current.on('call-start', () => {
      console.log('VAPI call started');
      setIsRecording(true);
      setCallStatus('connected');
      startVisualization();
    });
    
    vapiRef.current.on('call-end', () => {
      console.log('VAPI call ended');
      setIsRecording(false);
      setCallStatus('ended');
      stopVisualization();
      // Reset to idle state after a brief moment
      setTimeout(() => setCallStatus('idle'), 1000);
    });
    
    vapiRef.current.on('message', (message: any) => {
      if (message.type === 'transcript') {
        console.log(`${message.role}: ${message.transcript}`);
      }
    });
    
    vapiRef.current.on('error', (error: any) => {
      console.error('VAPI error:', error);
      setIsRecording(false);
      setCallStatus('idle');
      stopVisualization();
    });
    
    return () => {
      if (vapiRef.current) {
        vapiRef.current.stop();
      }
    };
  }, []);

  const startVisualization = () => {
    // Create animated visualization during VAPI call
    const animate = () => {
      if (!isRecording) return;
      
      // Generate animated audio data for visualization
      const simulatedData = new Array(32).fill(0).map(() => Math.random() * 0.8 + 0.2);
      setAudioData(simulatedData);
      
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    
    animate();
  };

  const stopVisualization = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setAudioData(new Array(32).fill(0));
  };

  const handleButtonClick = async () => {
    if (isRecording || callStatus === 'connected') {
      // End the VAPI call
      vapiRef.current?.stop();
    } else {
      // Start the VAPI call
      try {
        setCallStatus('connecting');
        await vapiRef.current?.start(VAPI_ASSISTANT_ID);
      } catch (error) {
        console.error('Failed to start VAPI call:', error);
        setCallStatus('idle');
      }
    }
  };

  const getStatusMessage = () => {
    switch (callStatus) {
      case 'connecting':
        return 'Connecting to AI agent...';
      case 'connected':
        return '🎤 Connected! Speak with your AI booking agent';
      case 'ended':
        return 'Call ended. Thank you for trying Vaice!';
      default:
        return null;
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-32 pb-16 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="h-full w-full bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1),transparent_50%)]" />
        <div 
          className="absolute inset-0 opacity-30" 
          style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)',
            backgroundSize: '20px 20px'
          }}
        />
      </div>
      
      <div className="container mx-auto px-6 text-center relative z-10">
        {/* Hero Content */}
        <div className="max-w-4xl mx-auto mb-8">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight mt-16 md:mt-20">
            Voice AI Agents for
            <span className="block bg-gradient-to-r from-emerald-400 to-blue-500 bg-clip-text text-transparent">
              Appointment Bookings
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
            Transform your business with intelligent voice agents that book appointments 24/7, 
            providing natural conversations and instant confirmations.
          </p>
          
          {/* Interactive Call Button */}
          <div className="mb-8 flex justify-center">
            <InteractiveCallButton 
              isRecording={isRecording || callStatus === 'connected'}
              onClick={handleButtonClick}
              callStatus={callStatus}
            />
          </div>
          
          {/* Status Messages */}
          {getStatusMessage() && (
            <div className={`text-sm mb-6 animate-pulse ${
              callStatus === 'connected' ? 'text-emerald-400' : 
              callStatus === 'connecting' ? 'text-yellow-400' : 
              'text-blue-400'
            }`}>
              {getStatusMessage()}
            </div>
          )}
          
          {/* Audio Visualizer - NOW IN HERO SECTION */}
          <div className="max-w-5xl mx-auto mt-6">
            <AudioVisualizer audioData={audioData} isActive={isRecording} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;