# Genesis Bible Study Platform

A beautiful and modern web-based platform for in-depth King James Version (KJV) Bible study on the book of Genesis, enhanced with Google Gemini AI integration for comprehensive biblical analysis and interactive learning experiences.

![Genesis Study Platform](https://img.shields.io/badge/Bible_Study-Genesis-gold?style=for-the-badge&logo=book&logoColor=white)
![KJV](https://img.shields.io/badge/Version-King_James-blue?style=for-the-badge)
![AI Powered](https://img.shields.io/badge/AI-Google_Gemini-green?style=for-the-badge&logo=google&logoColor=white)

## 🌟 Features

### ✅ Currently Implemented

#### 📖 **Complete Bible Study Platform**
- **Modern Web Interface**: Beautiful, responsive design with Tailwind CSS and custom styling
- **Full Navigation**: Seamless chapter-by-chapter navigation through all 50 Genesis chapters
- **KJV Text Display**: Complete King James Version text with verse-by-verse breakdown
- **Mobile Responsive**: Optimized for desktop, tablet, and mobile devices

#### 🤖 **AI-Powered Insights**
- **Google Gemini Integration**: Advanced AI analysis for theological insights
- **Contextual Analysis**: Chapter-specific biblical interpretation and commentary
- **Interactive Q&A**: Ask AI questions about specific verses or theological concepts
- **Enhanced Study**: Deep theological analysis, historical context, and practical applications

#### 🛠️ **Interactive Study Tools**
- **Advanced Search**: Multi-option search with text, reference, and theme filters
- **Verse Bookmarking**: Save and organize favorite verses with color coding
- **Personal Notes**: Create, edit, and manage study notes with timestamps
- **Cross-References**: Automatic and AI-enhanced biblical cross-references
- **Study Timeline**: Visual chronology of Genesis events
- **Book Outline**: Comprehensive structural overview of Genesis

#### 💾 **Data Management**
- **Progress Tracking**: Monitor reading progress across all chapters
- **Note Storage**: Persistent storage using modern browser technology
- **Study Sessions**: Track study time and session goals
- **User Preferences**: Customizable settings and display options

#### 🔧 **Advanced Features**
- **Search Highlighting**: Visual emphasis on search results
- **Theme-Based Study**: Organize content by theological themes
- **Study Questions**: AI-generated chapter-specific study questions
- **Commentary System**: Detailed verse-by-verse commentary via AI
- **Relevance Scoring**: Intelligent search result ranking

### 🚧 Features in Development

#### 📚 **Enhanced Content**
- **Complete Genesis Text**: Full implementation of all 50 chapters (currently chapters 1-3 complete)
- **Hebrew Word Study**: Original language analysis and meanings
- **Historical Maps**: Interactive biblical geography
- **Archaeological Insights**: Historical context and discoveries

#### 🎯 **Advanced Study Aids**
- **Comparison Tools**: Side-by-side verse comparisons
- **Translation Comparison**: Multiple version comparisons
- **Concordance**: Comprehensive word concordance for Genesis
- **Study Plans**: Guided reading plans and curricula

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection for AI features
- Google Gemini API key (optional, for AI features)

### Installation
1. **Clone or Download** the project files
2. **Open `index.html`** in your web browser
3. **Configure AI Features** (optional):
   - Get a Google Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
   - Enter your API key when prompted on first use
   - API key is stored locally for security

### Quick Start Guide
1. **Navigate Chapters**: Click any chapter number (1-50) to begin reading
2. **Search Verses**: Use the search tool to find specific content
3. **Take Notes**: Click the note button to save personal insights
4. **Ask AI**: Use the AI analysis tool for deeper understanding
5. **Bookmark Verses**: Save important passages for later reference

## 📊 Database Schema

The platform uses a RESTful API with the following data structures:

### Study Notes Table
```javascript
{
  id: "text",           // Unique identifier
  user_id: "text",      // User identifier
  chapter: "number",    // Genesis chapter (1-50)
  verse: "number",      // Verse number (optional)
  note_text: "rich_text", // Note content
  note_type: "text",    // general|verse|cross_reference|commentary
  tags: "array",        // Organization tags
  created_at: "datetime",
  updated_at: "datetime"
}
```

### Bookmarks Table
```javascript
{
  id: "text",
  user_id: "text",
  chapter: "number",
  verse: "number",
  title: "text",
  description: "text",
  color: "text",        // yellow|blue|green|red|purple|orange
  created_at: "datetime"
}
```

### Reading Progress Table
```javascript
{
  id: "text",
  user_id: "text",
  chapter: "number",
  verses_read: "array",
  completion_percentage: "number",
  time_spent: "number",
  first_read_date: "datetime",
  last_read_date: "datetime",
  is_completed: "bool"
}
```

### AI Insights Table
```javascript
{
  id: "text",
  user_id: "text",
  query: "text",
  response: "rich_text",
  chapter_context: "number",
  verse_context: "number",
  insight_type: "text", // theological|historical|literary|practical|cross_reference
  created_at: "datetime",
  rating: "number"
}
```

### Study Sessions Table
```javascript
{
  id: "text",
  user_id: "text",
  start_time: "datetime",
  end_time: "datetime",
  chapters_studied: "array",
  total_verses: "number",
  notes_created: "number",
  ai_queries: "number",
  session_goals: "text"
}
```

## 🔌 API Endpoints

### RESTful Table API
All data operations use relative URLs:

- **GET** `tables/{table}` - List records with pagination
- **GET** `tables/{table}/{id}` - Get single record
- **POST** `tables/{table}` - Create new record
- **PUT** `tables/{table}/{id}` - Update complete record
- **PATCH** `tables/{table}/{id}` - Partial record update
- **DELETE** `tables/{table}/{id}` - Delete record (soft delete)

### Example Usage
```javascript
// Fetch study notes
const response = await fetch('tables/study_notes?page=1&limit=10');
const data = await response.json();

// Create new bookmark
await fetch('tables/bookmarks', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    chapter: 1,
    verse: 1,
    title: 'Creation Begins',
    color: 'gold'
  })
});
```

## 🎨 Design & Architecture

### Technology Stack
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Tailwind CSS + Custom CSS
- **Icons**: Font Awesome 6
- **Fonts**: Inter (UI), Crimson Text (Bible text)
- **AI**: Google Gemini Pro API
- **Storage**: LocalStorage + RESTful API

### File Structure
```
/
├── index.html              # Main application entry point
├── css/
│   └── style.css          # Custom styles and enhancements
├── js/
│   ├── main.js           # Core application logic
│   ├── ai-integration.js  # Google Gemini AI integration
│   ├── bible-data.js     # KJV Genesis text data
│   └── study-tools.js    # Advanced study features
└── README.md             # This documentation
```

### Key Components
- **App**: Main application controller and state management
- **AIIntegration**: Google Gemini API interface and analysis
- **BiblData**: Genesis text data and search functionality  
- **StudyTools**: Advanced study aids and cross-references

## 🔧 Configuration

### AI Integration Setup
1. Obtain Google Gemini API key
2. Enter key in the application when prompted
3. Key is stored securely in browser localStorage
4. No server-side storage of API keys

### Customization Options
- **Theme Colors**: Modify CSS custom properties in `style.css`
- **Chapter Data**: Extend `bible-data.js` for additional chapters
- **AI Prompts**: Customize AI analysis prompts in `ai-integration.js`
- **Study Tools**: Add new features in `study-tools.js`

## 🔐 Security & Privacy

### Data Protection
- **Local Storage**: All personal data stored locally in browser
- **API Key Security**: Keys stored in localStorage, never transmitted to our servers
- **No User Registration**: No account creation or personal information required
- **Client-Side Processing**: All data processing happens in your browser

### Recommended Security Practices
- Keep your Google Gemini API key private
- Regularly backup your notes and bookmarks
- Use HTTPS when hosting the application
- Clear browser data to remove all stored information

## 🎯 Usage Scenarios

### Personal Bible Study
- Daily devotional reading with AI insights
- In-depth theological research and analysis
- Note-taking and progress tracking
- Cross-reference study and theme exploration

### Group Study & Teaching
- Lesson preparation with AI-generated insights
- Discussion question development
- Historical and contextual background research
- Visual aids and structural analysis

### Academic Research
- Theological analysis and commentary
- Original language insights and word studies
- Historical context and archaeological connections
- Comparative analysis and cross-referencing

## 📈 Performance & Browser Support

### Supported Browsers
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

### Performance Features
- **Lazy Loading**: Content loaded on demand
- **Caching**: Intelligent caching of AI responses
- **Responsive Design**: Optimized for all screen sizes
- **Progressive Enhancement**: Core features work without AI

## 🤝 Contributing

### Future Enhancement Opportunities
- Complete Genesis text implementation (chapters 4-50)
- Hebrew/Greek original language integration
- Audio Bible integration
- Study plan templates
- Export/import functionality
- Multi-language support

### Development Guidelines
- Follow existing code structure and patterns
- Maintain responsive design principles
- Ensure accessibility compliance
- Test across multiple browsers and devices
- Document new features thoroughly

## 📞 Support & Resources

### Getting Help
- Check browser console for error messages
- Ensure stable internet connection for AI features
- Verify Google Gemini API key is valid
- Clear browser cache if experiencing issues

### External Resources
- [Google Gemini AI Documentation](https://ai.google.dev/)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [Font Awesome Icons](https://fontawesome.com/icons)
- [KJV Bible Text](https://www.kingjamesbibleonline.org/)

## 📄 License & Credits

### Open Source Components
- **Tailwind CSS**: MIT License
- **Font Awesome**: Font Awesome Free License
- **Google Fonts**: SIL Open Font License

### Bible Text
- King James Version (KJV) text is in the public domain
- Chapter themes and cross-references compiled from public domain sources

### AI Integration
- Powered by Google Gemini Pro API
- Requires valid Google API key for full functionality
- AI responses generated dynamically based on user queries

---

**Built with ❤️ for Bible study and the glory of God**

*"Study to shew thyself approved unto God, a workman that needeth not to be ashamed, rightly dividing the word of truth."* - 2 Timothy 2:15 (KJV)