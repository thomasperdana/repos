/**
 * Google Gemini AI Integration for Genesis Bible Study
 * Note: This implementation uses a client-side approach that requires user-provided API key
 * For production use, implement server-side proxy for security
 */

const AIIntegration = {
    // Configuration
    config: {
        apiEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent',
        model: 'gemini-pro',
        maxTokens: 2048,
        temperature: 0.7
    },
    
    // API key management (stored in localStorage for demo purposes)
    apiKey: null,
    
    // Initialize AI integration
    init() {
        this.loadApiKey();
        this.setupApiKeyModal();
        console.log('AI Integration initialized');
    },
    
    // Load API key from localStorage
    loadApiKey() {
        this.apiKey = localStorage.getItem('gemini-api-key');
    },
    
    // Save API key to localStorage
    saveApiKey(key) {
        this.apiKey = key;
        localStorage.setItem('gemini-api-key', key);
    },
    
    // Setup API key input modal
    setupApiKeyModal() {
        // Check if API key is already available
        if (!this.apiKey) {
            this.showApiKeyPrompt();
        }
    },
    
    // Show API key input prompt
    showApiKeyPrompt() {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
        modal.id = 'api-key-modal';
        
        modal.innerHTML = `
            <div class="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full">
                <div class="text-center mb-6">
                    <div class="bg-gold-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                        <i class="fas fa-key text-gold-600 text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-bible-900 mb-2">Google Gemini API Key</h3>
                    <p class="text-bible-600">Enter your Google Gemini API key to enable AI-powered biblical insights.</p>
                </div>
                
                <div class="mb-6">
                    <input type="password" id="gemini-api-key" placeholder="Enter your API key..." 
                           class="w-full p-4 border-2 border-bible-200 rounded-lg focus:outline-none focus:border-gold-500 focus:ring-2 focus:ring-gold-200">
                    <div class="mt-2 text-sm text-bible-500">
                        <i class="fas fa-info-circle mr-1"></i>
                        Don't have an API key? Get one at 
                        <a href="https://makersuite.google.com/app/apikey" target="_blank" class="text-gold-600 hover:underline">Google AI Studio</a>
                    </div>
                </div>
                
                <div class="flex space-x-3">
                    <button onclick="AIIntegration.handleApiKeySubmit()" 
                            class="flex-1 bg-gold-600 text-white py-3 px-6 rounded-lg hover:bg-gold-700 transition-colors font-medium">
                        Save & Continue
                    </button>
                    <button onclick="AIIntegration.skipApiKey()" 
                            class="flex-1 bg-bible-200 text-bible-700 py-3 px-6 rounded-lg hover:bg-bible-300 transition-colors font-medium">
                        Skip for Now
                    </button>
                </div>
                
                <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-700">
                    <i class="fas fa-shield-alt mr-1"></i>
                    Your API key is stored locally in your browser and never sent to our servers.
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    },
    
    // Handle API key submission
    handleApiKeySubmit() {
        const input = document.getElementById('gemini-api-key');
        const apiKey = input?.value.trim();
        
        if (!apiKey) {
            this.showError('Please enter a valid API key');
            return;
        }
        
        // Basic validation
        if (apiKey.length < 20) {
            this.showError('API key appears to be invalid (too short)');
            return;
        }
        
        this.saveApiKey(apiKey);
        this.closeApiKeyModal();
        App.showSuccess('API key saved! You can now use AI insights.');
    },
    
    // Skip API key setup
    skipApiKey() {
        this.closeApiKeyModal();
        App.showNotification('You can add your API key later in the AI Insights section to enable AI features.');
    },
    
    // Close API key modal
    closeApiKeyModal() {
        const modal = document.getElementById('api-key-modal');
        if (modal) {
            modal.remove();
        }
    },
    
    // Main AI analysis function
    async analyzeText(query, chapterContext = null) {
        if (!this.apiKey) {
            throw new Error('API key not configured. Please add your Google Gemini API key to use AI features.');
        }
        
        try {
            // Prepare the context-aware prompt
            const prompt = this.buildPrompt(query, chapterContext);
            
            // Make API request
            const response = await this.callGeminiAPI(prompt);
            
            // Process and format the response
            const analysis = this.formatResponse(response, query);
            
            // Save to database
            await this.saveInsight(query, analysis, chapterContext);
            
            return analysis;
            
        } catch (error) {
            console.error('AI Analysis Error:', error);
            throw new Error(`AI analysis failed: ${error.message}`);
        }
    },
    
    // Build context-aware prompt for Gemini
    buildPrompt(query, chapterContext) {
        let prompt = `You are a knowledgeable biblical scholar specializing in the King James Version (KJV) of the Bible. You have deep understanding of theology, biblical history, Hebrew and Greek original languages, and Christian doctrine.

Please provide a comprehensive biblical analysis for the following query: "${query}"

`;
        
        if (chapterContext) {
            prompt += `This query is in the context of Genesis Chapter ${chapterContext}. `;
        }
        
        prompt += `Please structure your response as follows:

1. **Direct Answer**: Provide a clear, direct response to the question
2. **Biblical Context**: Explain the historical, cultural, and theological context
3. **Cross References**: Mention related verses or passages that support or expand on this topic
4. **Theological Significance**: Discuss the theological importance and implications
5. **Practical Application**: How this applies to modern Christian life and study

Guidelines:
- Use the King James Version (KJV) text when quoting scripture
- Be theologically sound and doctrinally conservative
- Provide specific verse references when possible
- Be clear and accessible for both new and experienced Bible students
- Focus specifically on the book of Genesis when relevant
- If the question is not biblically related, gently redirect to biblical themes`;
        
        return prompt;
    },
    
    // Call Google Gemini API
    async callGeminiAPI(prompt) {
        const response = await fetch(`${this.config.apiEndpoint}?key=${this.apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: prompt
                    }]
                }],
                generationConfig: {
                    temperature: this.config.temperature,
                    maxOutputTokens: this.config.maxTokens,
                    topP: 0.8,
                    topK: 10
                }
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error?.message || `HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
            throw new Error('Invalid response format from Gemini API');
        }
        
        return data.candidates[0].content.parts[0].text;
    },
    
    // Format AI response for display
    formatResponse(rawResponse, originalQuery) {
        // Convert markdown-style formatting to HTML
        let formatted = rawResponse
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code class="bg-gray-100 px-1 rounded">$1</code>')
            .replace(/\n\n/g, '</p><p class="mb-3">')
            .replace(/\n/g, '<br>');
        
        // Wrap in paragraph tags
        formatted = '<p class="mb-3">' + formatted + '</p>';
        
        // Format scripture references (basic pattern matching)
        formatted = formatted.replace(
            /([1-3]?\s?[A-Za-z]+)\s+(\d+):(\d+(?:-\d+)?)/g,
            '<span class="font-semibold text-gold-700 cursor-pointer" onclick="AIIntegration.lookupVerse(\'$1\', $2, \'$3\')" title="Click to lookup verse">$1 $2:$3</span>'
        );
        
        return {
            content: formatted,
            originalQuery: originalQuery,
            timestamp: new Date().toISOString(),
            wordCount: rawResponse.length
        };
    },
    
    // Save AI insight to database
    async saveInsight(query, analysis, chapterContext) {
        try {
            const insight = {
                query: query,
                response: analysis.content,
                chapter_context: chapterContext,
                insight_type: this.categorizeInsight(query),
                user_id: 'default_user' // In a real app, this would be the actual user ID
            };
            
            // Using the table API
            const response = await fetch('tables/ai_insights', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(insight)
            });
            
            if (!response.ok) {
                console.warn('Failed to save AI insight to database');
            }
        } catch (error) {
            console.warn('Error saving AI insight:', error);
            // Don't throw - this shouldn't break the AI functionality
        }
    },
    
    // Categorize insight type based on query
    categorizeInsight(query) {
        const lowerQuery = query.toLowerCase();
        
        if (lowerQuery.includes('history') || lowerQuery.includes('historical') || lowerQuery.includes('when') || lowerQuery.includes('time')) {
            return 'historical';
        } else if (lowerQuery.includes('meaning') || lowerQuery.includes('interpret') || lowerQuery.includes('theology') || lowerQuery.includes('doctrine')) {
            return 'theological';
        } else if (lowerQuery.includes('apply') || lowerQuery.includes('practical') || lowerQuery.includes('life') || lowerQuery.includes('today')) {
            return 'practical';
        } else if (lowerQuery.includes('literary') || lowerQuery.includes('structure') || lowerQuery.includes('style') || lowerQuery.includes('genre')) {
            return 'literary';
        } else if (lowerQuery.includes('reference') || lowerQuery.includes('related') || lowerQuery.includes('other')) {
            return 'cross_reference';
        } else {
            return 'theological'; // default
        }
    },
    
    // Lookup verse reference (placeholder for future implementation)
    lookupVerse(book, chapter, verse) {
        App.showNotification(`Looking up ${book} ${chapter}:${verse} - Feature coming soon!`);
    },
    
    // Get pre-defined study questions for each chapter
    getChapterStudyQuestions(chapter) {
        const questions = {
            1: [
                "What does the creation account in Genesis 1 reveal about God's nature?",
                "How does the phrase 'And God saw that it was good' affect our understanding of creation?",
                "What is the significance of humans being created 'in the image of God'?",
                "How does the creation account establish the pattern of work and rest?"
            ],
            2: [
                "What is the significance of God forming man from the dust of the ground?",
                "How does the Garden of Eden represent God's original design for humanity?",
                "What does 'it is not good that the man should be alone' teach us about relationships?",
                "How does the creation of woman complete God's creation design?"
            ],
            3: [
                "What was the nature of the temptation in the Garden?",
                "How did sin affect the relationship between God and humanity?",
                "What is the significance of the first messianic promise in Genesis 3:15?",
                "How do the consequences of sin still affect us today?"
            ],
            // Add more questions for other chapters as needed
        };
        
        return questions[chapter] || [
            "What are the main themes in this chapter?",
            "How does this chapter reveal God's character?",
            "What can we learn about human nature from this passage?",
            "How does this chapter connect to God's overall plan of redemption?"
        ];
    },
    
    // Generate chapter summary using AI
    async generateChapterSummary(chapter) {
        const query = `Please provide a comprehensive summary of Genesis chapter ${chapter}, including its main themes, key events, theological significance, and how it fits into the broader narrative of Genesis.`;
        
        try {
            return await this.analyzeText(query, chapter);
        } catch (error) {
            return {
                content: '<p class="text-bible-600">AI summary not available. Please add your API key to enable AI features.</p>',
                error: error.message
            };
        }
    },
    
    // Get contextual AI suggestions
    getContextualSuggestions(currentChapter) {
        const suggestions = [
            `What are the key theological themes in Genesis ${currentChapter}?`,
            `How does Genesis ${currentChapter} connect to the rest of the Bible?`,
            `What practical lessons can we learn from Genesis ${currentChapter}?`,
            `What historical context helps us understand Genesis ${currentChapter}?`
        ];
        
        return suggestions;
    },
    
    // Utility function to show errors
    showError(message) {
        if (typeof App !== 'undefined' && App.showError) {
            App.showError(message);
        } else {
            alert(message);
        }
    }
};

// Initialize AI integration when the script loads
document.addEventListener('DOMContentLoaded', () => {
    AIIntegration.init();
});

// Export for global access
window.AIIntegration = AIIntegration;