/**
 * Advanced Study Tools for Genesis Bible Study
 * Enhanced search, cross-references, commentary, and study aids
 */

const StudyTools = {
    // Initialize study tools
    init() {
        this.setupAdvancedSearch();
        this.setupCrossReferences();
        this.setupCommentaryFeatures();
        this.setupStudyAids();
        console.log('Study Tools initialized');
    },
    
    // Advanced search functionality
    setupAdvancedSearch() {
        // Enhanced search with filters and options
        this.searchOptions = {
            caseSensitive: false,
            wholeWord: false,
            searchType: 'text', // text, reference, theme
            includeContext: true
        };
        
        // Add search options UI (will be added to existing search)
        this.addAdvancedSearchUI();
    },
    
    // Add advanced search UI elements
    addAdvancedSearchUI() {
        const searchContainer = document.querySelector('.bg-gradient-to-br.from-blue-50');
        if (!searchContainer) return;
        
        const advancedOptions = document.createElement('div');
        advancedOptions.className = 'mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg';
        advancedOptions.innerHTML = `
            <div class="flex flex-wrap items-center gap-4 text-sm">
                <label class="flex items-center">
                    <input type="checkbox" id="case-sensitive" class="mr-1 rounded">
                    Case Sensitive
                </label>
                <label class="flex items-center">
                    <input type="checkbox" id="whole-word" class="mr-1 rounded">
                    Whole Word
                </label>
                <select id="search-type" class="px-2 py-1 border border-blue-300 rounded text-sm">
                    <option value="text">Text Search</option>
                    <option value="reference">Reference Search</option>
                    <option value="theme">Theme Search</option>
                </select>
            </div>
        `;
        
        const searchBtn = searchContainer.querySelector('#search-btn');
        if (searchBtn) {
            searchBtn.parentElement.appendChild(advancedOptions);
        }
        
        // Add event listeners for advanced options
        document.getElementById('case-sensitive')?.addEventListener('change', (e) => {
            this.searchOptions.caseSensitive = e.target.checked;
        });
        
        document.getElementById('whole-word')?.addEventListener('change', (e) => {
            this.searchOptions.wholeWord = e.target.checked;
        });
        
        document.getElementById('search-type')?.addEventListener('change', (e) => {
            this.searchOptions.searchType = e.target.value;
        });
    },
    
    // Enhanced search function
    performAdvancedSearch(query) {
        if (!query.trim()) return [];
        
        let results = [];
        
        switch (this.searchOptions.searchType) {
            case 'text':
                results = this.searchText(query);
                break;
            case 'reference':
                results = this.searchReferences(query);
                break;
            case 'theme':
                results = this.searchThemes(query);
                break;
        }
        
        return results;
    },
    
    // Text search with advanced options
    searchText(query) {
        const flags = this.searchOptions.caseSensitive ? 'g' : 'gi';
        let searchPattern = this.searchOptions.wholeWord ? `\\b${query}\\b` : query;
        
        try {
            const searchRegex = new RegExp(searchPattern, flags);
            const results = [];
            
            Object.values(BiblData.chapters).forEach(chapter => {
                chapter.verses.forEach(verse => {
                    if (searchRegex.test(verse.text)) {
                        results.push({
                            chapter: chapter.chapter,
                            verse: verse.number,
                            text: verse.text,
                            type: 'verse',
                            relevance: this.calculateRelevance(verse.text, query)
                        });
                    }
                });
            });
            
            // Sort by relevance
            return results.sort((a, b) => b.relevance - a.relevance);
        } catch (error) {
            console.error('Search error:', error);
            return [];
        }
    },
    
    // Calculate search relevance score
    calculateRelevance(text, query) {
        const lowerText = text.toLowerCase();
        const lowerQuery = query.toLowerCase();
        
        let score = 0;
        
        // Exact matches get highest score
        if (lowerText.includes(lowerQuery)) {
            score += 10;
        }
        
        // Count word matches
        const queryWords = lowerQuery.split(' ');
        queryWords.forEach(word => {
            const matches = (lowerText.match(new RegExp(word, 'g')) || []).length;
            score += matches * 2;
        });
        
        // Boost score for shorter verses (more focused content)
        if (text.length < 100) score += 2;
        
        return score;
    },
    
    // Search biblical references
    searchReferences(query) {
        // Parse reference formats like "1:1", "Genesis 1:1", etc.
        const refPattern = /(?:Genesis\s+)?(\d+):(\d+)(?:-(\d+))?/i;
        const match = query.match(refPattern);
        
        if (!match) return [];
        
        const chapter = parseInt(match[1]);
        const startVerse = parseInt(match[2]);
        const endVerse = match[3] ? parseInt(match[3]) : startVerse;
        
        const results = [];
        const chapterData = BiblData.getChapter(chapter);
        
        if (chapterData) {
            for (let v = startVerse; v <= endVerse; v++) {
                const verse = chapterData.verses.find(verse => verse.number === v);
                if (verse) {
                    results.push({
                        chapter: chapter,
                        verse: v,
                        text: verse.text,
                        type: 'reference',
                        relevance: 10
                    });
                }
            }
        }
        
        return results;
    },
    
    // Search by themes
    searchThemes(query) {
        const lowerQuery = query.toLowerCase();
        const results = [];
        
        // Search in theme keywords
        Object.entries(BiblData.themes).forEach(([theme, references]) => {
            if (theme.includes(lowerQuery)) {
                references.forEach(ref => {
                    const [chapter, verseRange] = ref.split(':');
                    const verses = verseRange.includes('-') ? 
                        verseRange.split('-').map(v => parseInt(v)) : 
                        [parseInt(verseRange)];
                    
                    const chapterData = BiblData.getChapter(parseInt(chapter));
                    if (chapterData) {
                        const startVerse = verses[0];
                        const endVerse = verses[1] || startVerse;
                        
                        for (let v = startVerse; v <= endVerse; v++) {
                            const verse = chapterData.verses.find(verse => verse.number === v);
                            if (verse) {
                                results.push({
                                    chapter: parseInt(chapter),
                                    verse: v,
                                    text: verse.text,
                                    type: 'theme',
                                    theme: theme,
                                    relevance: 8
                                });
                            }
                        }
                    }
                });
            }
        });
        
        return results;
    },
    
    // Cross-reference functionality
    setupCrossReferences() {
        this.crossRefCache = new Map();
    },
    
    // Get and display cross-references for a verse
    async getCrossReferences(chapter, verse) {
        const key = `${chapter}:${verse}`;
        
        // Check cache first
        if (this.crossRefCache.has(key)) {
            return this.crossRefCache.get(key);
        }
        
        // Get from Bible data
        const refs = BiblData.getCrossReferences(chapter, verse);
        
        // Enhance with AI if available
        try {
            const enhancedRefs = await this.enhanceCrossReferences(chapter, verse, refs);
            this.crossRefCache.set(key, enhancedRefs);
            return enhancedRefs;
        } catch (error) {
            console.warn('Could not enhance cross-references:', error);
            this.crossRefCache.set(key, refs);
            return refs;
        }
    },
    
    // Enhance cross-references with AI
    async enhanceCrossReferences(chapter, verse, existingRefs) {
        if (!window.AIIntegration || !AIIntegration.apiKey) {
            return existingRefs;
        }
        
        const verseText = BiblData.getVerse(chapter, verse)?.text;
        if (!verseText) return existingRefs;
        
        const query = `What are the most important cross-references and parallel passages for Genesis ${chapter}:${verse}? "${verseText}" Please provide specific verse references that relate thematically or doctrinally.`;
        
        try {
            const response = await AIIntegration.analyzeText(query, chapter);
            // Parse AI response for additional references
            const aiRefs = this.parseReferencesFromText(response.content);
            return [...existingRefs, ...aiRefs].filter((ref, index, self) => 
                self.indexOf(ref) === index
            );
        } catch (error) {
            return existingRefs;
        }
    },
    
    // Parse biblical references from text
    parseReferencesFromText(text) {
        const refPattern = /([1-3]?\s?[A-Za-z]+)\s+(\d+):(\d+(?:-\d+)?)/g;
        const references = [];
        let match;
        
        while ((match = refPattern.exec(text)) !== null) {
            references.push(`${match[1]} ${match[2]}:${match[3]}`);
        }
        
        return references;
    },
    
    // Display cross-references in UI
    displayCrossReferences(chapter, verse, references) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
        
        modal.innerHTML = `
            <div class="bg-white rounded-xl shadow-2xl p-6 max-w-2xl w-full max-h-96 overflow-y-auto">
                <div class="flex justify-between items-start mb-4">
                    <h3 class="text-xl font-bold text-bible-900">
                        Cross-References for Genesis ${chapter}:${verse}
                    </h3>
                    <button onclick="this.closest('.fixed').remove()" 
                            class="text-bible-400 hover:text-bible-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <div class="space-y-3">
                    ${references.length > 0 ? 
                        references.map(ref => `
                            <div class="p-3 bg-bible-50 rounded-lg border border-bible-200">
                                <span class="font-semibold text-gold-600">${ref}</span>
                            </div>
                        `).join('') :
                        '<p class="text-bible-600">No cross-references available for this verse.</p>'
                    }
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    },
    
    // Commentary features
    setupCommentaryFeatures() {
        this.commentaryCache = new Map();
    },
    
    // Get commentary for a verse or passage
    async getCommentary(chapter, verse = null) {
        const key = verse ? `${chapter}:${verse}` : `${chapter}`;
        
        if (this.commentaryCache.has(key)) {
            return this.commentaryCache.get(key);
        }
        
        try {
            let query;
            if (verse) {
                const verseText = BiblData.getVerse(chapter, verse)?.text;
                query = `Provide a detailed biblical commentary on Genesis ${chapter}:${verse}. "${verseText}" Include historical context, theological significance, Hebrew word meanings where relevant, and practical application.`;
            } else {
                query = `Provide a comprehensive commentary overview of Genesis chapter ${chapter}, including its main themes, structure, key theological points, and how it fits in the broader narrative of Genesis.`;
            }
            
            const commentary = await AIIntegration.analyzeText(query, chapter);
            this.commentaryCache.set(key, commentary);
            return commentary;
        } catch (error) {
            const fallback = {
                content: '<p class="text-bible-600">Commentary not available. Please add your API key to enable AI-powered commentary features.</p>',
                error: error.message
            };
            this.commentaryCache.set(key, fallback);
            return fallback;
        }
    },
    
    // Study aids and tools
    setupStudyAids() {
        this.addStudyAidsMenu();
    },
    
    // Add study aids menu
    addStudyAidsMenu() {
        // Add a study aids section to the page
        const studySection = document.getElementById('study-tools');
        if (!studySection) return;
        
        const studyAidsContainer = document.createElement('div');
        studyAidsContainer.className = 'mt-12';
        studyAidsContainer.innerHTML = `
            <h3 class="text-2xl font-bold text-bible-900 mb-6 text-center">Additional Study Aids</h3>
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <button onclick="StudyTools.showWordStudy()" 
                        class="p-4 bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-xl hover:shadow-lg transition-all">
                    <i class="fas fa-language text-purple-600 text-xl mb-2"></i>
                    <h4 class="font-semibold text-bible-900">Word Study</h4>
                    <p class="text-sm text-bible-600 mt-1">Explore Hebrew meanings</p>
                </button>
                
                <button onclick="StudyTools.showTimeline()" 
                        class="p-4 bg-gradient-to-br from-indigo-50 to-indigo-100 border border-indigo-200 rounded-xl hover:shadow-lg transition-all">
                    <i class="fas fa-clock text-indigo-600 text-xl mb-2"></i>
                    <h4 class="font-semibold text-bible-900">Timeline</h4>
                    <p class="text-sm text-bible-600 mt-1">Genesis chronology</p>
                </button>
                
                <button onclick="StudyTools.showMap()" 
                        class="p-4 bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-xl hover:shadow-lg transition-all">
                    <i class="fas fa-map text-green-600 text-xl mb-2"></i>
                    <h4 class="font-semibold text-bible-900">Maps</h4>
                    <p class="text-sm text-bible-600 mt-1">Biblical geography</p>
                </button>
                
                <button onclick="StudyTools.showOutline()" 
                        class="p-4 bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-200 rounded-xl hover:shadow-lg transition-all">
                    <i class="fas fa-list text-orange-600 text-xl mb-2"></i>
                    <h4 class="font-semibold text-bible-900">Outline</h4>
                    <p class="text-sm text-bible-600 mt-1">Book structure</p>
                </button>
            </div>
        `;
        
        studySection.appendChild(studyAidsContainer);
    },
    
    // Show word study tool
    showWordStudy() {
        App.showNotification('Word Study tool coming soon! This will provide Hebrew word analysis and meanings.');
    },
    
    // Show timeline tool
    showTimeline() {
        const modal = this.createModal('Genesis Timeline', this.generateTimeline());
        document.body.appendChild(modal);
    },
    
    // Generate Genesis timeline
    generateTimeline() {
        const timelineEvents = [
            { chapter: 1, event: "Creation of the World", period: "Beginning" },
            { chapter: 3, event: "The Fall of Man", period: "Beginning" },
            { chapter: 6-9, event: "The Great Flood", period: "Antediluvian" },
            { chapter: 11, event: "Tower of Babel", period: "Post-Flood" },
            { chapter: 12, event: "Call of Abraham", period: "Patriarchal", date: "c. 2100 BC" },
            { chapter: 21, event: "Birth of Isaac", period: "Patriarchal", date: "c. 2066 BC" },
            { chapter: 25, event: "Birth of Jacob and Esau", period: "Patriarchal", date: "c. 2006 BC" },
            { chapter: 37, event: "Joseph Sold into Egypt", period: "Patriarchal", date: "c. 1898 BC" },
            { chapter: 50, event: "Death of Joseph", period: "Patriarchal", date: "c. 1805 BC" }
        ];
        
        return `
            <div class="space-y-4">
                ${timelineEvents.map(event => `
                    <div class="flex items-start space-x-4 p-3 bg-bible-50 rounded-lg">
                        <div class="flex-shrink-0 w-16 text-center">
                            <div class="text-gold-600 font-bold">Ch. ${event.chapter}</div>
                            ${event.date ? `<div class="text-xs text-bible-500">${event.date}</div>` : ''}
                        </div>
                        <div class="flex-1">
                            <div class="font-semibold text-bible-900">${event.event}</div>
                            <div class="text-sm text-bible-600">${event.period} Period</div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },
    
    // Show map tool
    showMap() {
        App.showNotification('Biblical Maps coming soon! This will show the geography of Genesis events.');
    },
    
    // Show book outline
    showOutline() {
        const modal = this.createModal('Genesis Outline', this.generateOutline());
        document.body.appendChild(modal);
    },
    
    // Generate book outline
    generateOutline() {
        const outline = [
            {
                section: "I. Primeval History (1-11)",
                subsections: [
                    "A. Creation (1-2)",
                    "B. Fall and Its Consequences (3-5)",
                    "C. The Flood (6-9)",
                    "D. Nations and Languages (10-11)"
                ]
            },
            {
                section: "II. Patriarchal History (12-50)",
                subsections: [
                    "A. Abraham (12-25:18)",
                    "B. Isaac (25:19-26:35)",
                    "C. Jacob (27-35)",
                    "D. Joseph (36-50)"
                ]
            }
        ];
        
        return `
            <div class="space-y-6">
                ${outline.map(section => `
                    <div>
                        <h4 class="text-lg font-bold text-bible-900 mb-3">${section.section}</h4>
                        <div class="space-y-2 ml-4">
                            ${section.subsections.map(sub => `
                                <div class="text-bible-700">${sub}</div>
                            `).join('')}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },
    
    // Create modal utility
    createModal(title, content) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
        
        modal.innerHTML = `
            <div class="bg-white rounded-xl shadow-2xl p-6 max-w-4xl w-full max-h-96 overflow-y-auto">
                <div class="flex justify-between items-start mb-4">
                    <h3 class="text-xl font-bold text-bible-900">${title}</h3>
                    <button onclick="this.closest('.fixed').remove()" 
                            class="text-bible-400 hover:text-bible-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                <div>${content}</div>
            </div>
        `;
        
        return modal;
    },
    
    // Verse comparison tool
    compareVerses(verse1, verse2) {
        // Compare different translations or versions
        const comparison = {
            verse1: verse1,
            verse2: verse2,
            similarities: [],
            differences: []
        };
        
        // Simple word comparison
        const words1 = verse1.text.toLowerCase().split(' ');
        const words2 = verse2.text.toLowerCase().split(' ');
        
        words1.forEach(word => {
            if (words2.includes(word)) {
                comparison.similarities.push(word);
            }
        });
        
        return comparison;
    }
};

// Initialize study tools when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    StudyTools.init();
});

// Export for global access
window.StudyTools = StudyTools;