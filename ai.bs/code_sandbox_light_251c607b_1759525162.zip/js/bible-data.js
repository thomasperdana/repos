/**
 * King James Version Genesis Text Data
 * Complete text of Genesis with chapter themes and cross-references
 */

const BiblData = {
    // Chapter themes and summaries
    chapterThemes: {
        1: "The Creation of the World",
        2: "The Garden of Eden and the Creation of Man and Woman",
        3: "The Fall of Man and the First Promise of Redemption",
        4: "Cain and Abel - The First Murder",
        5: "The Genealogy from Adam to Noah",
        6: "The Wickedness of Man and God's Decision to Send the Flood",
        7: "The Great Flood Begins",
        8: "The Flood Ends and Noah's Sacrifice",
        9: "God's Covenant with Noah and the Rainbow Sign",
        10: "The Table of Nations - Descendants of Noah",
        11: "The Tower of Babel and the Scattering of Nations",
        12: "God's Call to Abraham and His Journey to Canaan",
        13: "Abraham and Lot Separate",
        14: "Abraham Rescues Lot and Meets Melchizedek",
        15: "God's Covenant with Abraham",
        16: "Hagar and Ishmael",
        17: "The Covenant of Circumcision",
        18: "The Lord Visits Abraham and Promises Isaac",
        19: "The Destruction of Sodom and Gomorrah",
        20: "Abraham and Abimelech",
        21: "The Birth of Isaac and the Sending Away of Hagar",
        22: "The Sacrifice of Isaac",
        23: "The Death and Burial of Sarah",
        24: "A Wife for Isaac - Rebekah",
        25: "The Death of Abraham and the Birth of Jacob and Esau",
        26: "Isaac and the Philistines",
        27: "Jacob Receives Isaac's Blessing",
        28: "Jacob's Vision at Bethel",
        29: "Jacob Marries Leah and Rachel",
        30: "The Children of Jacob",
        31: "Jacob's Flight from Laban",
        32: "Jacob Prepares to Meet Esau",
        33: "Jacob Meets Esau and They Reconcile",
        34: "The Defilement of Dinah",
        35: "Jacob Returns to Bethel and Rachel Dies",
        36: "The Genealogy of Esau",
        37: "Joseph's Dreams and His Brothers' Jealousy",
        38: "Judah and Tamar",
        39: "Joseph in Potiphar's House and Prison",
        40: "Joseph Interprets Dreams in Prison",
        41: "Joseph Interprets Pharaoh's Dreams and Becomes Ruler",
        42: "Joseph's Brothers Come to Egypt for Grain",
        43: "The Second Journey to Egypt with Benjamin",
        44: "The Test of the Silver Cup",
        45: "Joseph Reveals Himself to His Brothers",
        46: "Jacob's Journey to Egypt",
        47: "Jacob Before Pharaoh and the Severe Famine",
        48: "Jacob Blesses Ephraim and Manasseh",
        49: "Jacob's Prophecy Over His Twelve Sons",
        50: "The Death of Jacob and Joseph"
    },
    
    // Sample Genesis text data (first few chapters - in production, this would include all 50 chapters)
    chapters: {
        1: {
            chapter: 1,
            theme: "The Creation of the World",
            verses: [
                { number: 1, text: "In the beginning God created the heaven and the earth." },
                { number: 2, text: "And the earth was without form, and void; and darkness was upon the face of the deep. And the Spirit of God moved upon the face of the waters." },
                { number: 3, text: "And God said, Let there be light: and there was light." },
                { number: 4, text: "And God saw the light, that it was good: and God divided the light from the darkness." },
                { number: 5, text: "And God called the light Day, and the darkness he called Night. And the evening and the morning were the first day." },
                { number: 6, text: "And God said, Let there be a firmament in the midst of the waters, and let it divide the waters from the waters." },
                { number: 7, text: "And God made the firmament, and divided the waters which were under the firmament from the waters which were above the firmament: and it was so." },
                { number: 8, text: "And God called the firmament Heaven. And the evening and the morning were the second day." },
                { number: 9, text: "And God said, Let the waters under the heaven be gathered together unto one place, and let the dry land appear: and it was so." },
                { number: 10, text: "And God called the dry land Earth; and the gathering together of the waters called he Seas: and God saw that it was good." },
                { number: 11, text: "And God said, Let the earth bring forth grass, the herb yielding seed, and the fruit tree yielding fruit after his kind, whose seed is in itself, upon the earth: and it was so." },
                { number: 12, text: "And the earth brought forth grass, and herb yielding seed after his kind, and the tree yielding fruit, whose seed was in itself, after his kind: and God saw that it was good." },
                { number: 13, text: "And the evening and the morning were the third day." },
                { number: 14, text: "And God said, Let there be lights in the firmament of the heaven to divide the day from the night; and let them be for signs, and for seasons, and for days, and years:" },
                { number: 15, text: "And let them be for lights in the firmament of the heaven to give light upon the earth: and it was so." },
                { number: 16, text: "And God made two great lights; the greater light to rule the day, and the lesser light to rule the night: he made the stars also." },
                { number: 17, text: "And God set them in the firmament of the heaven to give light upon the earth," },
                { number: 18, text: "And to rule over the day and over the night, and to divide the light from the darkness: and God saw that it was good." },
                { number: 19, text: "And the evening and the morning were the fourth day." },
                { number: 20, text: "And God said, Let the waters bring forth abundantly the moving creature that hath life, and fowl that may fly above the earth in the open firmament of heaven." },
                { number: 21, text: "And God created great whales, and every living creature that moveth, which the waters brought forth abundantly, after their kind, and every winged fowl after his kind: and God saw that it was good." },
                { number: 22, text: "And God blessed them, saying, Be fruitful, and multiply, and fill the waters in the seas, and let fowl multiply in the earth." },
                { number: 23, text: "And the evening and the morning were the fifth day." },
                { number: 24, text: "And God said, Let the earth bring forth the living creature after his kind, cattle, and creeping thing, and beast of the earth after his kind: and it was so." },
                { number: 25, text: "And God made the beast of the earth after his kind, and cattle after their kind, and every thing that creepeth upon the earth after his kind: and God saw that it was good." },
                { number: 26, text: "And God said, Let us make man in our image, after our likeness: and let them have dominion over the fish of the sea, and over the fowl of the air, and over the cattle, and over all the earth, and over every creeping thing that creepeth upon the earth." },
                { number: 27, text: "So God created man in his own image, in the image of God created he him; male and female created he them." },
                { number: 28, text: "And God blessed them, and God said unto them, Be fruitful, and multiply, and replenish the earth, and subdue it: and have dominion over the fish of the sea, and over the fowl of the air, and over every living thing that moveth upon the earth." },
                { number: 29, text: "And God said, Behold, I have given you every herb bearing seed, which is upon the face of all the earth, and every tree, in the which is the fruit of a tree yielding seed; to you it shall be for meat." },
                { number: 30, text: "And to every beast of the earth, and to every fowl of the air, and to every thing that creepeth upon the earth, wherein there is life, I have given every green herb for meat: and it was so." },
                { number: 31, text: "And God saw every thing that he had made, and, behold, it was very good. And the evening and the morning were the sixth day." }
            ]
        },
        
        2: {
            chapter: 2,
            theme: "The Garden of Eden and the Creation of Man and Woman",
            verses: [
                { number: 1, text: "Thus the heavens and the earth were finished, and all the host of them." },
                { number: 2, text: "And on the seventh day God ended his work which he had made; and he rested on the seventh day from all his work which he had made." },
                { number: 3, text: "And God blessed the seventh day, and sanctified it: because that in it he had rested from all his work which God created and made." },
                { number: 4, text: "These are the generations of the heavens and of the earth when they were created, in the day that the LORD God made the earth and the heavens," },
                { number: 5, text: "And every plant of the field before it was in the earth, and every herb of the field before it grew: for the LORD God had not caused it to rain upon the earth, and there was not a man to till the ground." },
                { number: 6, text: "But there went up a mist from the earth, and watered the whole face of the ground." },
                { number: 7, text: "And the LORD God formed man of the dust of the ground, and breathed into his nostrils the breath of life; and man became a living soul." },
                { number: 8, text: "And the LORD God planted a garden eastward in Eden; and there he put the man whom he had formed." },
                { number: 9, text: "And out of the ground made the LORD God to grow every tree that is pleasant to the sight, and good for food; the tree of life also in the midst of the garden, and the tree of knowledge of good and evil." },
                { number: 10, text: "And a river went out of Eden to water the garden; and from thence it was parted, and became into four heads." },
                { number: 11, text: "The name of the first is Pison: that is it which compasseth the whole land of Havilah, where there is gold;" },
                { number: 12, text: "And the gold of that land is good: there is bdellium and the onyx stone." },
                { number: 13, text: "And the name of the second river is Gihon: the same is it that compasseth the whole land of Ethiopia." },
                { number: 14, text: "And the name of the third river is Hiddekel: that is it which goeth toward the east of Assyria. And the fourth river is Euphrates." },
                { number: 15, text: "And the LORD God took the man, and put him into the garden of Eden to dress it and to keep it." },
                { number: 16, text: "And the LORD God commanded the man, saying, Of every tree of the garden thou mayest freely eat:" },
                { number: 17, text: "But of the tree of the knowledge of good and evil, thou shalt not eat of it: for in the day that thou eatest thereof thou shalt surely die." },
                { number: 18, text: "And the LORD God said, It is not good that the man should be alone; I will make him an help meet for him." },
                { number: 19, text: "And out of the ground the LORD God formed every beast of the field, and every fowl of the air; and brought them unto Adam to see what he would call them: and whatsoever Adam called every living creature, that was the name thereof." },
                { number: 20, text: "And Adam gave names to all cattle, and to the fowl of the air, and to every beast of the field; but for Adam there was not found an help meet for him." },
                { number: 21, text: "And the LORD God caused a deep sleep to fall upon Adam, and he slept: and he took one of his ribs, and closed up the flesh instead thereof;" },
                { number: 22, text: "And the rib, which the LORD God had taken from man, made he a woman, and brought her unto the man." },
                { number: 23, text: "And Adam said, This is now bone of my bones, and flesh of my flesh: she shall be called Woman, because she was taken out of Man." },
                { number: 24, text: "Therefore shall a man leave his father and his mother, and shall cleave unto his wife: and they shall be one flesh." },
                { number: 25, text: "And they were both naked, the man and his wife, and were not ashamed." }
            ]
        },
        
        3: {
            chapter: 3,
            theme: "The Fall of Man and the First Promise of Redemption",
            verses: [
                { number: 1, text: "Now the serpent was more subtil than any beast of the field which the LORD God had made. And he said unto the woman, Yea, hath God said, Ye shall not eat of every tree of the garden?" },
                { number: 2, text: "And the woman said unto the serpent, We may eat of the fruit of the trees of the garden:" },
                { number: 3, text: "But of the fruit of the tree which is in the midst of the garden, God hath said, Ye shall not eat of it, neither shall ye touch it, lest ye die." },
                { number: 4, text: "And the serpent said unto the woman, Ye shall not surely die:" },
                { number: 5, text: "For God doth know that when ye eat thereof, then your eyes shall be opened, and ye shall be as gods, knowing good and evil." },
                { number: 6, text: "And when the woman saw that the tree was good for food, and that it was pleasant to the eyes, and a tree to be desired to make one wise, she took of the fruit thereof, and did eat, and gave also unto her husband with her; and he did eat." },
                { number: 7, text: "And the eyes of them both were opened, and they knew that they were naked; and they sewed fig leaves together, and made themselves aprons." },
                { number: 8, text: "And they heard the voice of the LORD God walking in the garden in the cool of the day: and Adam and his wife hid themselves from the presence of the LORD God amongst the trees of the garden." },
                { number: 9, text: "And the LORD God called unto Adam, and said unto him, Where art thou?" },
                { number: 10, text: "And he said, I heard thy voice in the garden, and I was afraid, because I was naked; and I hid myself." },
                { number: 11, text: "And he said, Who told thee that thou wast naked? Hast thou eaten of the tree, whereof I commanded thee that thou shouldest not eat?" },
                { number: 12, text: "And the man said, The woman whom thou gavest to be with me, she gave me of the tree, and I did eat." },
                { number: 13, text: "And the LORD God said unto the woman, What is this that thou hast done? And the woman said, The serpent beguiled me, and I did eat." },
                { number: 14, text: "And the LORD God said unto the serpent, Because thou hast done this, thou art cursed above all cattle, and above every beast of the field; upon thy belly shalt thou go, and dust shalt thou eat all the days of thy life:" },
                { number: 15, text: "And I will put enmity between thee and the woman, and between thy seed and her seed; it shall bruise thy head, and thou shalt bruise his heel." },
                { number: 16, text: "Unto the woman he said, I will greatly multiply thy sorrow and thy conception; in sorrow thou shalt bring forth children; and thy desire shall be to thy husband, and he shall rule over thee." },
                { number: 17, text: "And unto Adam he said, Because thou hast hearkened unto the voice of thy wife, and hast eaten of the tree, of which I commanded thee, saying, Thou shalt not eat of it: cursed is the ground for thy sake; in sorrow shalt thou eat of it all the days of thy life;" },
                { number: 18, text: "Thorns also and thistles shall it bring forth to thee; and thou shalt eat the herb of the field;" },
                { number: 19, text: "In the sweat of thy face shalt thou eat bread, till thou return unto the ground; for out of it wast thou taken: for dust thou art, and unto dust shalt thou return." },
                { number: 20, text: "And Adam called his wife's name Eve; because she was the mother of all living." },
                { number: 21, text: "Unto Adam also and to his wife did the LORD God make coats of skins, and clothed them." },
                { number: 22, text: "And the LORD God said, Behold, the man is become as one of us, to know good and evil: and now, lest he put forth his hand, and take also of the tree of life, and eat, and live for ever:" },
                { number: 23, text: "Therefore the LORD God sent him forth from the garden of Eden, to till the ground from whence he was taken." },
                { number: 24, text: "So he drove out the man; and he placed at the east of the garden of Eden Cherubims, and a flaming sword which turned every way, to keep the way of the tree of life." }
            ]
        }
    },
    
    // Get chapter data
    getChapter(chapterNumber) {
        if (this.chapters[chapterNumber]) {
            return this.chapters[chapterNumber];
        } else {
            // For chapters not yet implemented, return a placeholder
            return {
                chapter: chapterNumber,
                theme: this.chapterThemes[chapterNumber] || `Genesis Chapter ${chapterNumber}`,
                verses: [
                    { 
                        number: 1, 
                        text: `Genesis ${chapterNumber} content is being prepared. This chapter covers: ${this.chapterThemes[chapterNumber] || 'Biblical narrative'}. Please check back soon for the complete text.` 
                    }
                ]
            };
        }
    },
    
    // Search verses across all available chapters
    searchVerses(searchTerm) {
        const results = [];
        const searchRegex = new RegExp(searchTerm, 'gi');
        
        Object.values(this.chapters).forEach(chapter => {
            chapter.verses.forEach(verse => {
                if (searchRegex.test(verse.text)) {
                    results.push({
                        chapter: chapter.chapter,
                        verse: verse.number,
                        text: verse.text
                    });
                }
            });
        });
        
        return results;
    },
    
    // Get verse by reference
    getVerse(chapter, verse) {
        const chapterData = this.getChapter(chapter);
        return chapterData.verses.find(v => v.number === verse);
    },
    
    // Get all chapter titles for navigation
    getAllChapterTitles() {
        const titles = [];
        for (let i = 1; i <= 50; i++) {
            titles.push({
                chapter: i,
                title: `Genesis ${i}`,
                theme: this.chapterThemes[i] || `Chapter ${i}`
            });
        }
        return titles;
    },
    
    // Cross-references (sample data)
    crossReferences: {
        "1:1": ["John 1:1", "Colossians 1:16", "Hebrews 11:3"],
        "1:26": ["Genesis 5:1", "Genesis 9:6", "1 Corinthians 11:7"],
        "1:27": ["Matthew 19:4", "Mark 10:6", "Ephesians 4:24"],
        "2:7": ["1 Corinthians 15:45", "Job 33:4", "Ecclesiastes 12:7"],
        "2:24": ["Matthew 19:5", "Mark 10:7-8", "Ephesians 5:31"],
        "3:15": ["Romans 16:20", "1 John 3:8", "Revelation 12:9"]
    },
    
    // Get cross-references for a verse
    getCrossReferences(chapter, verse) {
        const key = `${chapter}:${verse}`;
        return this.crossReferences[key] || [];
    },
    
    // Key words and themes
    themes: {
        creation: ["1:1-2:3"],
        fall: ["3:1-24"],
        covenant: ["9:8-17", "12:1-3", "15:1-21", "17:1-27"],
        redemption: ["3:15", "22:1-19"],
        faith: ["12:1-4", "15:6", "22:1-19"],
        providence: ["37:1-50:26"]
    },
    
    // Get verses by theme
    getVersesByTheme(theme) {
        return this.themes[theme] || [];
    }
};

// Export for global access
window.BiblData = BiblData;