/**
 * Genesis Bible Study - Main JavaScript Functions
 * Interactive Bible study platform with AI integration
 */

// Global application state
const App = {
    currentChapter: 1,
    totalChapters: 50,
    searchResults: [],
    userNotes: [],
    bookmarks: [],
    readingProgress: new Set(),
    
    // Initialize the application
    init() {
        this.setupEventListeners();
        this.generateChapterNavigation();
        this.loadUserData();
        this.setupMobileMenu();
        this.loadChapter(1); // Load Genesis 1 by default
        console.log('Genesis Bible Study App initialized successfully');
    },
    
    // Set up all event listeners
    setupEventListeners() {
        // Navigation
        document.getElementById('mobile-menu-btn')?.addEventListener('click', this.toggleMobileMenu);
        
        // Search functionality
        document.getElementById('search-btn')?.addEventListener('click', this.performSearch.bind(this));
        document.getElementById('verse-search')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.performSearch();
        });
        
        // AI Analysis
        document.getElementById('ai-analyze-btn')?.addEventListener('click', this.performAIAnalysis.bind(this));
        document.getElementById('ai-query')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) this.performAIAnalysis();
        });
        
        // Notes functionality
        document.getElementById('save-note-btn')?.addEventListener('click', this.saveNote.bind(this));
        
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(link.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    },
    
    // Generate chapter navigation grid
    generateChapterNavigation() {
        const chapterGrid = document.getElementById('chapter-grid');
        if (!chapterGrid) return;
        
        for (let i = 1; i <= this.totalChapters; i++) {
            const chapterBtn = document.createElement('button');
            chapterBtn.className = 'chapter-btn';
            chapterBtn.textContent = i;
            chapterBtn.title = `Genesis Chapter ${i}`;
            chapterBtn.addEventListener('click', () => this.loadChapter(i));
            
            // Mark as completed if in reading progress
            if (this.readingProgress.has(i)) {
                chapterBtn.classList.add('completed');
            }
            
            chapterGrid.appendChild(chapterBtn);
        }
    },
    
    // Load a specific chapter
    async loadChapter(chapterNumber) {
        if (chapterNumber < 1 || chapterNumber > this.totalChapters) return;
        
        this.showLoading(true);
        this.currentChapter = chapterNumber;
        
        try {
            // Update active chapter button
            document.querySelectorAll('.chapter-btn').forEach((btn, index) => {
                btn.classList.toggle('active', index + 1 === chapterNumber);
            });
            
            // Load chapter content
            const chapterData = await BiblData.getChapter(chapterNumber);
            this.displayChapter(chapterData);
            
            // Update progress
            this.markChapterAsRead(chapterNumber);
            
            // Scroll to chapter content
            document.getElementById('chapter-content')?.scrollIntoView({ behavior: 'smooth' });
            
        } catch (error) {
            console.error('Error loading chapter:', error);
            this.showError('Failed to load chapter. Please try again.');
        } finally {
            this.showLoading(false);
        }
    },
    
    // Display chapter content
    displayChapter(chapterData) {
        const titleElement = document.getElementById('chapter-title');
        const themeElement = document.getElementById('chapter-theme');
        const textElement = document.getElementById('chapter-text');
        
        if (!titleElement || !themeElement || !textElement) return;
        
        titleElement.textContent = `Genesis Chapter ${chapterData.chapter}`;
        themeElement.textContent = chapterData.theme || '';
        
        // Build HTML for verses with interactive features
        let chapterHtml = '';
        chapterData.verses.forEach(verse => {
            chapterHtml += `
                <p class="verse-container mb-4" data-verse="${verse.number}">
                    <span class="verse-number">${verse.number}</span>
                    <span class="verse-text" onclick="App.selectVerse(${chapterData.chapter}, ${verse.number})">${verse.text}</span>
                    <span class="verse-actions ml-2 opacity-0 hover:opacity-100 transition-opacity">
                        <button onclick="App.bookmarkVerse(${chapterData.chapter}, ${verse.number})" class="text-gold-600 hover:text-gold-800" title="Bookmark verse">
                            <i class="fas fa-bookmark text-sm"></i>
                        </button>
                        <button onclick="App.addVerseNote(${chapterData.chapter}, ${verse.number})" class="text-blue-600 hover:text-blue-800 ml-1" title="Add note">
                            <i class="fas fa-sticky-note text-sm"></i>
                        </button>
                    </span>
                </p>
            `;
        });
        
        textElement.innerHTML = chapterHtml;
        
        // Add hover effects to verse containers
        document.querySelectorAll('.verse-container').forEach(container => {
            container.addEventListener('mouseenter', function() {
                this.querySelector('.verse-actions').classList.remove('opacity-0');
            });
            container.addEventListener('mouseleave', function() {
                this.querySelector('.verse-actions').classList.add('opacity-0');
            });
        });
    },
    
    // Perform verse search
    performSearch() {
        const searchInput = document.getElementById('verse-search');
        if (!searchInput) return;
        
        const query = searchInput.value.trim();
        if (!query) {
            this.showError('Please enter a search term');
            return;
        }
        
        this.showLoading(true);
        
        try {
            const results = BiblData.searchVerses(query);
            this.displaySearchResults(results);
            this.searchResults = results;
        } catch (error) {
            console.error('Search error:', error);
            this.showError('Search failed. Please try again.');
        } finally {
            this.showLoading(false);
        }
    },
    
    // Display search results
    displaySearchResults(results) {
        // Create search results modal or update results section
        let resultsHtml = '<h3 class="text-xl font-bold text-bible-900 mb-4">Search Results</h3>';
        
        if (results.length === 0) {
            resultsHtml += '<p class="text-bible-600">No verses found matching your search.</p>';
        } else {
            resultsHtml += `<p class="text-bible-600 mb-4">Found ${results.length} verse(s):</p>`;
            results.forEach(result => {
                const highlightedText = this.highlightSearchTerm(result.text, document.getElementById('verse-search').value);
                resultsHtml += `
                    <div class="bg-white border border-bible-200 rounded-lg p-4 mb-3 cursor-pointer hover:bg-bible-50 transition-colors"
                         onclick="App.loadChapter(${result.chapter}); App.highlightVerse(${result.verse})">
                        <div class="flex justify-between items-start mb-2">
                            <strong class="text-gold-600">Genesis ${result.chapter}:${result.verse}</strong>
                            <button onclick="event.stopPropagation(); App.bookmarkVerse(${result.chapter}, ${result.verse})" 
                                    class="text-bible-400 hover:text-gold-600 transition-colors">
                                <i class="fas fa-bookmark"></i>
                            </button>
                        </div>
                        <p class="text-bible-700">${highlightedText}</p>
                    </div>
                `;
            });
        }
        
        // Display in AI insights section for now
        const aiResults = document.getElementById('ai-results');
        if (aiResults) {
            aiResults.innerHTML = `<div class="search-results">${resultsHtml}</div>`;
        }
    },
    
    // Highlight search terms in text
    highlightSearchTerm(text, term) {
        if (!term) return text;
        const regex = new RegExp(`(${term})`, 'gi');
        return text.replace(regex, '<span class="search-highlight">$1</span>');
    },
    
    // Perform AI analysis
    async performAIAnalysis() {
        const queryInput = document.getElementById('ai-query');
        if (!queryInput) return;
        
        const query = queryInput.value.trim();
        if (!query) {
            this.showError('Please enter a question for AI analysis');
            return;
        }
        
        this.showLoading(true);
        
        try {
            const analysis = await AIIntegration.analyzeText(query, this.currentChapter);
            this.displayAIResults(analysis);
            queryInput.value = ''; // Clear the input
        } catch (error) {
            console.error('AI analysis error:', error);
            this.showError('AI analysis failed. Please check your internet connection and try again.');
        } finally {
            this.showLoading(false);
        }
    },
    
    // Display AI analysis results
    displayAIResults(analysis) {
        const aiResults = document.getElementById('ai-results');
        if (!aiResults) return;
        
        const resultsHtml = `
            <div class="ai-response">
                <h4><i class="fas fa-brain ai-icon"></i>AI Biblical Analysis</h4>
                <div class="ai-content">
                    ${analysis.content || analysis}
                </div>
                <div class="ai-meta mt-4 pt-4 border-t border-gold-200 text-sm text-bible-500">
                    <i class="fas fa-robot mr-1"></i>Generated by Google Gemini AI
                    ${analysis.timestamp ? ` • ${new Date(analysis.timestamp).toLocaleString()}` : ''}
                </div>
            </div>
        `;
        
        aiResults.innerHTML = resultsHtml;
    },
    
    // Save user note
    saveNote() {
        const noteInput = document.getElementById('study-note');
        if (!noteInput) return;
        
        const noteText = noteInput.value.trim();
        if (!noteText) {
            this.showError('Please enter a note');
            return;
        }
        
        const note = {
            id: Date.now(),
            text: noteText,
            chapter: this.currentChapter,
            verse: null, // Can be extended for specific verses
            timestamp: new Date().toISOString(),
            type: 'general'
        };
        
        this.userNotes.push(note);
        this.saveUserData();
        this.displayNotes();
        
        // Clear the input
        noteInput.value = '';
        
        // Show success message
        this.showSuccess('Note saved successfully!');
    },
    
    // Display user notes
    displayNotes() {
        const notesContainer = document.getElementById('notes-container');
        if (!notesContainer) return;
        
        if (this.userNotes.length === 0) {
            notesContainer.innerHTML = `
                <div class="text-center py-12">
                    <i class="fas fa-notebook text-4xl text-bible-300 mb-4"></i>
                    <p class="text-bible-500">No notes yet. Start taking notes as you study!</p>
                </div>
            `;
            return;
        }
        
        let notesHtml = '';
        this.userNotes.reverse().forEach(note => {
            notesHtml += `
                <div class="note-card" data-note-id="${note.id}">
                    <div class="note-meta">
                        <span><i class="fas fa-calendar mr-1"></i>${new Date(note.timestamp).toLocaleDateString()}</span>
                        <span><i class="fas fa-book mr-1"></i>Genesis ${note.chapter}</span>
                    </div>
                    <div class="note-content">${this.escapeHtml(note.text)}</div>
                    <div class="note-actions">
                        <button onclick="App.editNote(${note.id})" class="text-blue-600 hover:text-blue-800 text-sm">
                            <i class="fas fa-edit mr-1"></i>Edit
                        </button>
                        <button onclick="App.deleteNote(${note.id})" class="text-red-600 hover:text-red-800 text-sm">
                            <i class="fas fa-trash mr-1"></i>Delete
                        </button>
                    </div>
                </div>
            `;
        });
        
        notesContainer.innerHTML = notesHtml;
    },
    
    // Utility functions
    selectVerse(chapter, verse) {
        // Highlight selected verse
        document.querySelectorAll('.verse-selected').forEach(el => el.classList.remove('verse-selected'));
        const verseElement = document.querySelector(`[data-verse="${verse}"]`);
        if (verseElement) {
            verseElement.classList.add('verse-selected');
        }
    },
    
    bookmarkVerse(chapter, verse) {
        const bookmark = {
            id: Date.now(),
            chapter,
            verse,
            timestamp: new Date().toISOString()
        };
        
        // Check if already bookmarked
        const existing = this.bookmarks.find(b => b.chapter === chapter && b.verse === verse);
        if (existing) {
            this.showError('Verse already bookmarked');
            return;
        }
        
        this.bookmarks.push(bookmark);
        this.saveUserData();
        this.showSuccess('Verse bookmarked!');
    },
    
    addVerseNote(chapter, verse) {
        const noteText = prompt(`Add a note for Genesis ${chapter}:${verse}:`);
        if (!noteText) return;
        
        const note = {
            id: Date.now(),
            text: noteText,
            chapter,
            verse,
            timestamp: new Date().toISOString(),
            type: 'verse'
        };
        
        this.userNotes.push(note);
        this.saveUserData();
        this.showSuccess('Note added to verse!');
    },
    
    markChapterAsRead(chapter) {
        this.readingProgress.add(chapter);
        this.saveUserData();
        
        // Update chapter button appearance
        const chapterBtn = document.querySelector(`.chapter-btn:nth-child(${chapter})`);
        if (chapterBtn) {
            chapterBtn.classList.add('completed');
        }
    },
    
    // Data persistence
    saveUserData() {
        const userData = {
            notes: this.userNotes,
            bookmarks: this.bookmarks,
            progress: Array.from(this.readingProgress),
            lastChapter: this.currentChapter
        };
        localStorage.setItem('genesis-study-data', JSON.stringify(userData));
    },
    
    loadUserData() {
        try {
            const saved = localStorage.getItem('genesis-study-data');
            if (saved) {
                const userData = JSON.parse(saved);
                this.userNotes = userData.notes || [];
                this.bookmarks = userData.bookmarks || [];
                this.readingProgress = new Set(userData.progress || []);
                this.displayNotes();
            }
        } catch (error) {
            console.error('Error loading user data:', error);
        }
    },
    
    // UI utility functions
    showLoading(show) {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.classList.toggle('hidden', !show);
            overlay.classList.toggle('flex', show);
        }
    },
    
    showError(message) {
        this.showNotification(message, 'error');
    },
    
    showSuccess(message) {
        this.showNotification(message, 'success');
    },
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform ${
            type === 'error' ? 'bg-red-100 border border-red-400 text-red-700' :
            type === 'success' ? 'bg-green-100 border border-green-400 text-green-700' :
            'bg-blue-100 border border-blue-400 text-blue-700'
        }`;
        
        notification.innerHTML = `
            <div class="flex items-center">
                <i class="fas ${
                    type === 'error' ? 'fa-exclamation-circle' :
                    type === 'success' ? 'fa-check-circle' :
                    'fa-info-circle'
                } mr-2"></i>
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-lg">×</button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    },
    
    toggleMobileMenu() {
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileMenu) {
            mobileMenu.classList.toggle('hidden');
        }
    },
    
    setupMobileMenu() {
        // Close mobile menu when clicking on links
        document.querySelectorAll('#mobile-menu a').forEach(link => {
            link.addEventListener('click', () => {
                document.getElementById('mobile-menu')?.classList.add('hidden');
            });
        });
    },
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    
    // Note management
    editNote(noteId) {
        const note = this.userNotes.find(n => n.id === noteId);
        if (!note) return;
        
        const newText = prompt('Edit your note:', note.text);
        if (newText && newText !== note.text) {
            note.text = newText;
            note.timestamp = new Date().toISOString();
            this.saveUserData();
            this.displayNotes();
            this.showSuccess('Note updated!');
        }
    },
    
    deleteNote(noteId) {
        if (confirm('Are you sure you want to delete this note?')) {
            this.userNotes = this.userNotes.filter(n => n.id !== noteId);
            this.saveUserData();
            this.displayNotes();
            this.showSuccess('Note deleted!');
        }
    }
};

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

// Export for use in other files
window.App = App;